import { execBff } from '/_102020_/l2/core/bff-client.js';
export async function loadPetshopHome(params = {}) {
    return execBff('petshop.home.load', params);
}
