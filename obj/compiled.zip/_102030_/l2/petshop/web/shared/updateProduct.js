import { execBff } from '/_102020_/l2/core/bff-client.js';
export async function updatePetshopProduct(params) {
    return execBff('petshop.updateProduct', params);
}
