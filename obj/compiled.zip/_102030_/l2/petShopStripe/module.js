export const moduleGenome = {
    'web/desktop/page11': {
        designSystem: 'default',
        device: 'desktop',
        layout: 'standard',
    }
};
export const skills = {
    web: {
        sharedPath: '/_102030_/l2/petShopStripe/web/shared',
        sharedSkill: '/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts'
    }
};
export const moduleStates = {};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'petShopStripe',
    device: 'desktop',
    navigation: [],
    routes: [],
};
