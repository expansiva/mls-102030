/// <mls fileReference="_102030_/l2/petShopStripe/web/shared/homePage.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Página Inicial',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingGetCatalogHighlights: 'Carregando destaques do catálogo',
};
const message_en = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Home Page',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingGetCatalogHighlights: 'Loading catalog highlights',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PetShopStripeHomePageBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.homePage.categories',
            'ui.homePage.items',
        ];
        this.categories = [];
        this.items = [];
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.homePage.categories':
                this.categories = (value ?? []);
                break;
            case 'ui.homePage.items':
                this.items = (value ?? []);
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadGetCatalogHighlights(undefined, options);
    }
    async loadGetCatalogHighlights(params, options) {
        if (window.mls) {
            this.categories = [
                { categoryId: 'id-001', name: 'Rações', imageUrl: 'https://exemplo.com/img/cat-racoes.png' },
                { categoryId: 'id-002', name: 'Brinquedos', imageUrl: 'https://exemplo.com/img/cat-brinquedos.png' },
                { categoryId: 'id-003', name: 'Higiene', imageUrl: 'https://exemplo.com/img/cat-higiene.png' },
            ];
            setState('ui.homePage.categories', this.categories);
            this.items = [
                {
                    itemType: 'product',
                    itemId: 'id-001',
                    name: 'Ração Premium 10kg',
                    price: { amount: 199, currency: 'BRL' },
                    availabilityStatus: 'in_stock',
                    categoryIds: 'id-001',
                    imageUrl: 'https://exemplo.com/img/prod-racao-10kg.png',
                },
                {
                    itemType: 'service',
                    itemId: 'id-002',
                    name: 'Banho e Tosa',
                    price: { amount: 79, currency: 'BRL' },
                    availabilityStatus: 'available',
                    categoryIds: 'id-003',
                    imageUrl: 'https://exemplo.com/img/serv-banho-tosa.png',
                },
                {
                    itemType: 'product',
                    itemId: 'id-003',
                    name: 'Bolinha Interativa',
                    price: { amount: 29, currency: 'BRL' },
                    availabilityStatus: 'in_stock',
                    categoryIds: 'id-002',
                    imageUrl: 'https://exemplo.com/img/prod-bolinha.png',
                },
            ];
            setState('ui.homePage.items', this.items);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('petShopStripe.homePage.getCatalogHighlights', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.categories = response.data.categories;
        setState('ui.homePage.categories', this.categories);
        this.items = response.data.items;
        setState('ui.homePage.items', this.items);
        this.status = this.msg.loaded;
    }
}
__decorate([
    property()
], PetShopStripeHomePageBase.prototype, "categories", void 0);
__decorate([
    property()
], PetShopStripeHomePageBase.prototype, "items", void 0);
__decorate([
    property()
], PetShopStripeHomePageBase.prototype, "status", void 0);
