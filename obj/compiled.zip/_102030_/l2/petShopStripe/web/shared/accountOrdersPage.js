/// <mls fileReference="_102030_/l2/petShopStripe/web/shared/accountOrdersPage.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Pedidos da conta',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingGetOrderHistory: 'A carregar historico de pedidos',
    loadingGetCustomerServiceBookings: 'A carregar agendamentos de servicos',
};
const message_en = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Account orders',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingGetOrderHistory: 'Loading order history',
    loadingGetCustomerServiceBookings: 'Loading service bookings',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PetShopStripeAccountOrdersPageBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.accountOrdersPage.orders',
            'ui.accountOrdersPage.bookings',
        ];
        this.orders = [];
        this.bookings = [];
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.accountOrdersPage.orders':
                this.orders = (value ?? []);
                break;
            case 'ui.accountOrdersPage.bookings':
                this.bookings = (value ?? []);
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadGetOrderHistory(params, options);
    }
    async loadGetOrderHistory(params, options) {
        if (window.mls) {
            this.orders = [
                {
                    orderId: 'id-001',
                    orderNumber: 'ORD-1001',
                    status: 'processing',
                    paymentStatus: 'paid',
                    totalAmount: 89,
                    createdAt: '2026-06-01T10:20:00Z',
                    items: [
                        {
                            itemType: 'product',
                            itemId: 'id-001',
                            name: 'Racao premium',
                            quantity: 2,
                            unitPrice: 25,
                        },
                        {
                            itemType: 'service',
                            itemId: 'id-001',
                            name: 'Banho',
                            quantity: 1,
                            unitPrice: 39,
                        },
                    ],
                },
                {
                    orderId: 'id-001',
                    orderNumber: 'ORD-1002',
                    status: 'delivered',
                    paymentStatus: 'paid',
                    totalAmount: 49,
                    createdAt: '2026-05-20T15:05:00Z',
                    items: [
                        {
                            itemType: 'product',
                            itemId: 'id-001',
                            name: 'Coleira',
                            quantity: 1,
                            unitPrice: 49,
                        },
                    ],
                },
            ];
            setState('ui.accountOrdersPage.orders', this.orders);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('petShopStripe.accountOrdersPage.getOrderHistory', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.orders = response.data.orders;
        setState('ui.accountOrdersPage.orders', this.orders);
        this.status = this.msg.loaded;
    }
    async loadGetCustomerServiceBookings(params, options) {
        if (window.mls) {
            this.bookings = [
                {
                    serviceBookingId: 'id-001',
                    status: 'scheduled',
                    scheduledDate: '2026-06-10',
                    scheduledStartTime: '10:00',
                    scheduledEndTime: '',
                    timezone: 'America/Sao_Paulo',
                    service: { serviceId: 'id-001', name: 'Tosa' },
                    pet: { petId: 'id-001', name: 'Rex' },
                },
                {
                    serviceBookingId: 'id-001',
                    status: 'completed',
                    scheduledDate: '2026-05-28',
                    scheduledStartTime: '14:30',
                    scheduledEndTime: '15:30',
                    timezone: 'America/Sao_Paulo',
                    service: { serviceId: 'id-001', name: 'Banho' },
                    pet: { petId: 'id-001', name: 'Luna' },
                },
            ];
            setState('ui.accountOrdersPage.bookings', this.bookings);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('petShopStripe.accountOrdersPage.getCustomerServiceBookings', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.bookings = response.data.bookings;
        setState('ui.accountOrdersPage.bookings', this.bookings);
        this.status = this.msg.loaded;
    }
}
__decorate([
    property()
], PetShopStripeAccountOrdersPageBase.prototype, "orders", void 0);
__decorate([
    property()
], PetShopStripeAccountOrdersPageBase.prototype, "bookings", void 0);
__decorate([
    property()
], PetShopStripeAccountOrdersPageBase.prototype, "status", void 0);
