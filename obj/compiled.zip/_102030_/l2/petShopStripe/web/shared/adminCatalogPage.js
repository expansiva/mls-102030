/// <mls fileReference="_102030_/l2/petShopStripe/web/shared/adminCatalogPage.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Admin Catalog Page',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingGetCatalogAdminList: 'Carregando catálogo',
    couldNotManageCatalog: 'Nao foi possivel gerenciar o catálogo',
    manageCatalogLoading: 'Salvando alterações no catálogo',
};
const message_en = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Admin Catalog Page',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingGetCatalogAdminList: 'Loading catalog',
    couldNotManageCatalog: 'Could not manage catalog',
    manageCatalogLoading: 'Saving catalog changes',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PetShopStripeAdminCatalogPageBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.adminCatalogPage.items',
            'ui.adminCatalogPage.pagination',
            'ui.adminCatalogPage.manageCatalog',
        ];
        this.items = [];
        this.pagination = undefined;
        this.manageCatalogState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.adminCatalogPage.items':
                this.items = (value ?? []);
                break;
            case 'ui.adminCatalogPage.pagination':
                this.pagination = (value ?? undefined);
                break;
            case 'ui.adminCatalogPage.manageCatalog':
                this.manageCatalogState = (value ?? 'idle');
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadGetCatalogAdminList(undefined, options);
    }
    async loadGetCatalogAdminList(params, options) {
        if (window.mls) {
            this.items = [
                {
                    itemId: 'id-001',
                    itemType: 'product',
                    name: 'Banho Premium',
                    categoryId: 'id-001',
                    categoryName: 'Higiene',
                    price: 79,
                    status: 'active',
                    updatedAt: '2026-06-01T10:00:00Z',
                },
                {
                    itemId: 'id-002',
                    itemType: 'service',
                    name: 'Tosa Completa',
                    categoryId: 'id-002',
                    categoryName: 'Serviços',
                    price: 120,
                    status: 'inactive',
                    updatedAt: '2026-06-02T11:00:00Z',
                },
                {
                    itemId: 'id-003',
                    itemType: 'product',
                    name: 'Ração Premium 10kg',
                    categoryId: 'id-003',
                    categoryName: 'Alimentação',
                    price: 199,
                    status: 'active',
                    updatedAt: '2026-06-03T12:00:00Z',
                },
            ];
            this.pagination = { page: 1, pageSize: 10, totalItems: 3, totalPages: 1 };
            setState('ui.adminCatalogPage.items', this.items);
            setState('ui.adminCatalogPage.pagination', this.pagination);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('petShopStripe.adminCatalogPage.getCatalogAdminList', (params ?? {}), options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.items = response.data.items;
        this.pagination = response.data.pagination;
        setState('ui.adminCatalogPage.items', this.items);
        setState('ui.adminCatalogPage.pagination', this.pagination);
        this.status = this.msg.loaded;
    }
    async manageCatalog(params, signal) {
        if (window.mls) {
            console.log('[mls mock] petShopStripe.adminCatalogPage.manageCatalog', params);
            this.manageCatalogState = 'success';
            setState('ui.adminCatalogPage.manageCatalog', 'success');
            return;
        }
        this.manageCatalogState = 'loading';
        setState('ui.adminCatalogPage.manageCatalog', 'loading');
        try {
            const response = await execBff('petShopStripe.adminCatalogPage.manageCatalog', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.manageCatalogState = 'success';
            setState('ui.adminCatalogPage.manageCatalog', 'success');
            await this.loadGetCatalogAdminList(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.manageCatalogState = 'error';
            setState('ui.adminCatalogPage.manageCatalog', 'error');
            throw e;
        }
    }
    handleManageCatalogClick() {
        const params = {
            action: 'update',
            itemType: 'product',
            itemId: 'id-001',
            payload: {
                name: 'Ração Premium 10kg',
                description: 'Ração premium para cães adultos',
                price: 199,
                duration: 0,
                status: 'active',
                categoryId: 'id-003',
            },
        };
        void runBlockingUiAction(async (signal) => {
            await this.manageCatalog(params, signal);
        }, {
            busyLabel: this.msg.manageCatalogLoading,
            errorTitle: this.msg.couldNotManageCatalog,
            retry: () => this.manageCatalog(params),
        });
    }
}
__decorate([
    property()
], PetShopStripeAdminCatalogPageBase.prototype, "items", void 0);
__decorate([
    property()
], PetShopStripeAdminCatalogPageBase.prototype, "pagination", void 0);
__decorate([
    property()
], PetShopStripeAdminCatalogPageBase.prototype, "manageCatalogState", void 0);
__decorate([
    property()
], PetShopStripeAdminCatalogPageBase.prototype, "status", void 0);
