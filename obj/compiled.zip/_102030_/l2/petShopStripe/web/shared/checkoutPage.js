/// <mls fileReference="_102030_/l2/petShopStripe/web/shared/checkoutPage.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Checkout',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingGetCheckoutCartSummary: 'Carregando resumo do carrinho',
    couldNotCreateOrderFromCheckout: 'Nao foi possivel criar o pedido',
    createOrderFromCheckoutLoading: 'Criando pedido',
    couldNotConfirmStripePayment: 'Nao foi possivel confirmar o pagamento',
    confirmStripePaymentLoading: 'Confirmando pagamento',
};
const message_en = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Checkout',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingGetCheckoutCartSummary: 'Loading cart summary',
    couldNotCreateOrderFromCheckout: 'Could not create order',
    createOrderFromCheckoutLoading: 'Creating order',
    couldNotConfirmStripePayment: 'Could not confirm payment',
    confirmStripePaymentLoading: 'Confirming payment',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PetShopStripeCheckoutPageBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.checkoutPage.cartId',
            'ui.checkoutPage.items',
            'ui.checkoutPage.totals',
            'ui.checkoutPage.currency',
            'ui.checkoutPage.createOrderFromCheckout',
            'ui.checkoutPage.confirmStripePayment',
        ];
        this.cartId = undefined;
        this.items = [];
        this.totals = undefined;
        this.currency = undefined;
        this.createOrderFromCheckoutState = 'idle';
        this.confirmStripePaymentState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.checkoutPage.cartId':
                this.cartId = (value ?? undefined);
                break;
            case 'ui.checkoutPage.items':
                this.items = (value ?? []);
                break;
            case 'ui.checkoutPage.totals':
                this.totals = (value ?? undefined);
                break;
            case 'ui.checkoutPage.currency':
                this.currency = (value ?? undefined);
                break;
            case 'ui.checkoutPage.createOrderFromCheckout':
                this.createOrderFromCheckoutState = (value ?? 'idle');
                break;
            case 'ui.checkoutPage.confirmStripePayment':
                this.confirmStripePaymentState = (value ?? 'idle');
                break;
        }
    }
    async loadInitialData(params, options) {
        void params;
        await this.loadGetCheckoutCartSummary({ cartId: this.cartId ?? 'id-001' }, options);
    }
    async loadGetCheckoutCartSummary(params, options) {
        if (window.mls) {
            this.cartId = params?.cartId ?? 'id-001';
            this.items = [
                {
                    itemId: 'id-001',
                    itemType: 'product',
                    productId: 'id-001',
                    serviceId: 'id-001',
                    name: 'Racao Premium',
                    quantity: 2,
                    unitPrice: 25,
                    totalPrice: 50,
                },
                {
                    itemId: 'id-002',
                    itemType: 'service',
                    productId: 'id-001',
                    serviceId: 'id-002',
                    name: 'Banho e Tosa',
                    quantity: 1,
                    unitPrice: 60,
                    totalPrice: 60,
                },
            ];
            this.totals = { subtotal: 110, discount: 10, shipping: 15, total: 115 };
            this.currency = 'BRL';
            setState('ui.checkoutPage.cartId', this.cartId);
            setState('ui.checkoutPage.items', this.items);
            setState('ui.checkoutPage.totals', this.totals);
            setState('ui.checkoutPage.currency', this.currency);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('petShopStripe.checkoutPage.getCheckoutCartSummary', params ?? { cartId: this.cartId ?? '' }, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.cartId = response.data.cartId;
        this.items = response.data.items;
        this.totals = response.data.totals;
        this.currency = response.data.currency;
        setState('ui.checkoutPage.cartId', this.cartId);
        setState('ui.checkoutPage.items', this.items);
        setState('ui.checkoutPage.totals', this.totals);
        setState('ui.checkoutPage.currency', this.currency);
        this.status = this.msg.loaded;
    }
    async createOrderFromCheckout(params, signal) {
        if (window.mls) {
            console.log('[mls mock] petShopStripe.checkoutPage.createOrderFromCheckout', params);
            this.createOrderFromCheckoutState = 'success';
            setState('ui.checkoutPage.createOrderFromCheckout', 'success');
            return;
        }
        this.createOrderFromCheckoutState = 'loading';
        setState('ui.checkoutPage.createOrderFromCheckout', 'loading');
        try {
            const response = await execBff('petShopStripe.checkoutPage.createOrderFromCheckout', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.createOrderFromCheckoutState = 'success';
            setState('ui.checkoutPage.createOrderFromCheckout', 'success');
            await this.loadGetCheckoutCartSummary({ cartId: params.cartId }, { mode: 'silent', signal });
        }
        catch (e) {
            this.createOrderFromCheckoutState = 'error';
            setState('ui.checkoutPage.createOrderFromCheckout', 'error');
            throw e;
        }
    }
    handleCreateOrderFromCheckoutClick() {
        const params = {
            cartId: this.cartId ?? 'id-001',
            deliveryAddress: {
                street: 'Rua das Flores',
                number: '100',
                complement: 'Apto 12',
                district: 'Centro',
                city: 'Sao Paulo',
                state: 'SP',
                postalCode: '01000-000',
                country: 'BR',
            },
            contact: {
                name: 'Ana Silva',
                email: 'ana@exemplo.com',
                phone: '11999999999',
            },
        };
        void runBlockingUiAction(async (signal) => {
            await this.createOrderFromCheckout(params, signal);
        }, {
            busyLabel: this.msg.createOrderFromCheckoutLoading,
            errorTitle: this.msg.couldNotCreateOrderFromCheckout,
            retry: () => this.createOrderFromCheckout(params),
        });
    }
    async confirmStripePayment(params, signal) {
        if (window.mls) {
            console.log('[mls mock] petShopStripe.checkoutPage.confirmStripePayment', params);
            this.confirmStripePaymentState = 'success';
            setState('ui.checkoutPage.confirmStripePayment', 'success');
            return;
        }
        this.confirmStripePaymentState = 'loading';
        setState('ui.checkoutPage.confirmStripePayment', 'loading');
        try {
            const response = await execBff('petShopStripe.checkoutPage.confirmStripePayment', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.confirmStripePaymentState = 'success';
            setState('ui.checkoutPage.confirmStripePayment', 'success');
        }
        catch (e) {
            this.confirmStripePaymentState = 'error';
            setState('ui.checkoutPage.confirmStripePayment', 'error');
            throw e;
        }
    }
    handleConfirmStripePaymentClick() {
        const params = {
            orderId: 'id-001',
            paymentIntentId: 'id-001',
            paymentMethod: 'card',
            confirmationData: {
                clientSecret: 'id-001',
                returnUrl: 'https://exemplo.com/retorno',
            },
        };
        void runBlockingUiAction(async (signal) => {
            await this.confirmStripePayment(params, signal);
        }, {
            busyLabel: this.msg.confirmStripePaymentLoading,
            errorTitle: this.msg.couldNotConfirmStripePayment,
            retry: () => this.confirmStripePayment(params),
        });
    }
}
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "cartId", void 0);
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "items", void 0);
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "totals", void 0);
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "currency", void 0);
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "createOrderFromCheckoutState", void 0);
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "confirmStripePaymentState", void 0);
__decorate([
    property()
], PetShopStripeCheckoutPageBase.prototype, "status", void 0);
