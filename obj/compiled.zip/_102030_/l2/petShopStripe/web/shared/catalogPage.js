/// <mls fileReference="_102030_/l2/petShopStripe/web/shared/catalogPage.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Catálogo',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingGetCatalogList: 'Carregando catálogo...',
};
const message_en = {
    brand: 'Pet Shop Stripe',
    pageTitle: 'Catalog',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingGetCatalogList: 'Loading catalog...',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PetShopStripeCatalogPageBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.catalogPage.items',
            'ui.catalogPage.pagination',
        ];
        this.items = [];
        this.pagination = undefined;
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach((key) => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.catalogPage.items':
                this.items = Array.isArray(value) ? value : [];
                break;
            case 'ui.catalogPage.pagination':
                this.pagination = value ?? undefined;
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadGetCatalogList(params, options);
    }
    async loadGetCatalogList(params, options) {
        if (window.mls) {
            this.items = [
                {
                    itemId: 'id-001',
                    itemType: 'Product',
                    title: 'Ração Premium 10kg',
                    summary: 'Ração completa para cães adultos',
                    price: 120,
                    status: 'Active',
                    categoryTitle: 'Alimentação',
                },
                {
                    itemId: 'id-002',
                    itemType: 'Service',
                    title: 'Banho e Tosa',
                    summary: 'Serviço completo para higiene e estética',
                    price: 80,
                    status: 'Active',
                    categoryTitle: 'Serviços',
                },
                {
                    itemId: 'id-003',
                    itemType: 'Product',
                    title: 'Brinquedo Mordedor',
                    summary: 'Brinquedo resistente para cães',
                    price: 25,
                    status: 'Active',
                    categoryTitle: 'Brinquedos',
                },
            ];
            setState('ui.catalogPage.items', this.items);
            this.pagination = {
                page: params?.page ?? 1,
                pageSize: params?.pageSize ?? 10,
                totalItems: 42,
            };
            setState('ui.catalogPage.pagination', this.pagination);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('petShopStripe.catalogPage.getCatalogList', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.items = response.data.items;
        setState('ui.catalogPage.items', this.items);
        this.pagination = response.data.pagination;
        setState('ui.catalogPage.pagination', this.pagination);
        this.status = this.msg.loaded;
    }
}
__decorate([
    property()
], PetShopStripeCatalogPageBase.prototype, "items", void 0);
__decorate([
    property()
], PetShopStripeCatalogPageBase.prototype, "pagination", void 0);
__decorate([
    property()
], PetShopStripeCatalogPageBase.prototype, "status", void 0);
