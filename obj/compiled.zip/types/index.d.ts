declare module "_102030_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102030_/l2/petshop/index" { }
declare module "_102030_/l2/petshop/module.defs" {
    export const skill: {
        readonly moduleId: "petshop";
        readonly purpose: "Petshop client module with desktop and mobile page variations.";
        readonly pages: readonly ["home", "edit-products"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.petshop.currentSection", "ui.petshop.selectedCategory", "ui.petshop.searchQuery", "ui.petshop.editorAuthor"];
    };
}
declare module "_102030_/l2/petshop/module" {
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.petshop.currentSection";
        readonly selectedCategory: "ui.petshop.selectedCategory";
        readonly searchQuery: "ui.petshop.searchQuery";
        readonly editorAuthor: "ui.petshop.editorAuthor";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
}
declare module "_102030_/l2/petshop/shared/contracts/home" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult } from '_102030_/l1/petshop/module';
    export type PetshopHomeRequest = PetshopHomeLoadParams;
    export interface PetshopHomeResponse extends PetshopHomeLoadResult {
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
}
declare module "_102030_/l2/petshop/shared/contracts/update-product" {
    export type { PetshopUpdateProductParams, PetshopCatalogProduct } from '_102030_/l1/petshop/module';
}
declare module "_102030_/l2/petshop/shared/mock/adminMock" {
    export function getPetshopMockProducts(): any;
}
declare module "_102030_/l2/petshop/shared/mock/products" {
    import type { PetshopCatalogProduct } from '_102030_/l1/petshop/module';
    export function buildPetshopMockProducts(): PetshopCatalogProduct[];
}
declare module "_102030_/l2/petshop/web/desktop/page11/home" {
    import { LitElement } from '_102020_/l2/core/lit';
    import type { PetshopCatalogProduct } from '_102030_/l1/petshop/module';
    type PetshopSection = 'catalog' | 'edit-products';
    export class PetshopWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            items: {
                state: boolean;
            };
            topItems: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            editorAuthor: {
                state: boolean;
            };
        };
        currentSection: PetshopSection;
        items: PetshopCatalogProduct[];
        topItems: PetshopCatalogProduct[];
        status: string;
        editorAuthor: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handlePopState;
        private loadHome;
        private handleSectionClick;
        private handleEditorSubmit;
        private renderCatalog;
        private renderEditor;
        render(): any;
    }
}
declare module "_102030_/l2/petshop/web/shared/home.defs" {
    export const skill = "\n# Petshop Home Page\n\n## Purpose\n\nRender the desktop home page for the petshop module using a single aggregated\nBFF request.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `petshop.home.load`\n- The routine must return only the data the page needs:\n  - `seed`\n  - `catalog`\n  - `topProducts`\n\n## Page Behavior\n\n- Load the page with one BFF call on connect\n- Render a compact toolbar with category filters\n- Show a status line with the current page state\n- Render a \"Top products\" section\n- Render a \"Catalog\" section\n- Reload the page when the user clicks reload\n- Re-run the page load with a category filter when the user clicks a category\n\n## Important Data\n\n- Catalog item fields:\n  - `name`\n  - `category`\n  - `priceInCents`\n  - `stockStatus`\n  - `description`\n- Top product fields:\n  - `name`\n  - `category`\n  - `highlightScore`\n  - `priceInCents`\n\n## Shared Files\n\n- `web/shared/home.ts` owns the page BFF call\n- `web/shared/homeFormatters.ts` owns display formatting helpers such as\n  `formatPrice`\n\n## Layout Intent\n\n- Dense but readable business UI\n- Fast visual scan for category, stock state, and price\n- Keep the page compatible with the master shell aside/header\n- Use light DOM compatible styling\n";
}
declare module "_102030_/l2/petshop/web/shared/home" {
    import type { PetshopHomeRequest } from '_102030_/l2/petshop/shared/contracts/home';
    export function loadPetshopHome(params?: PetshopHomeRequest): Promise<any>;
}
declare module "_102030_/l2/petshop/web/shared/homeFormatters" {
    export function formatPrice(priceInCents: number): string;
}
declare module "_102030_/l2/petshop/web/shared/updateProduct" {
    import type { PetshopUpdateProductParams } from '_102030_/l2/petshop/shared/contracts/update-product';
    export function updatePetshopProduct(params: PetshopUpdateProductParams): Promise<any>;
}
