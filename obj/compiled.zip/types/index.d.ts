declare module "_102030_/l1/petShopStripe/layer_1_external/cart.defs" {
    export const cartTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "cart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "plan-table-definition:cart";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "cart";
                readonly tableName: "cart";
                readonly moduleId: "petShopStripe";
                readonly title: "Carrinho";
                readonly purpose: "Persistir o carrinho ativo do cliente para checkout.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Cart";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "cart_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do carrinho.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente dono do carrinho.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do carrinho (ativo, convertido, abandonado, expirado).";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Moeda usada para preços do carrinho.";
                }, {
                    readonly name: "items_count";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens no carrinho.";
                }, {
                    readonly name: "subtotal_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Subtotal do carrinho antes de descontos.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Desconto aplicado ao carrinho.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total do carrinho após descontos.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do carrinho.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do carrinho.";
                }, {
                    readonly name: "expires_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data de expiração do carrinho.";
                }, {
                    readonly name: "last_activity_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Última interação no carrinho.";
                }];
                readonly primaryKey: readonly ["cart_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule.persistence.excludeMdmEntities";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_cart_customer_status";
                    readonly columns: readonly ["customer_id", "status"];
                    readonly reason: "rule.index.lookupByCustomerStatus";
                }, {
                    readonly indexName: "idx_cart_updated_at";
                    readonly columns: readonly ["updated_at"];
                    readonly reason: "rule.index.sortByRecentUpdate";
                }, {
                    readonly indexName: "idx_cart_expires_at";
                    readonly columns: readonly ["expires_at"];
                    readonly reason: "rule.index.expirationCleanup";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "CartDetails";
                    readonly reason: "rule.persistence.aggregateWithChildEntities";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/cart.defs.ts";
                readonly exportName: "cartTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default cartTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "plan-table-definition:order";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "petShopStripe";
                readonly title: "Pedido";
                readonly purpose: "Registrar pedidos gerados no checkout e seu ciclo de vida.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "order_number";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Número legível do pedido para referência do cliente e admin.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente responsável pelo pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do ciclo de vida do pedido.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do pagamento associado ao pedido.";
                }, {
                    readonly name: "payment_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao pagamento horizontal.";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "BRL";
                    readonly description: "Moeda do pedido.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Valor total do pedido.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de descontos aplicados.";
                }, {
                    readonly name: "shipping_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor de entrega, quando aplicável.";
                }, {
                    readonly name: "scheduled_service_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data e hora do serviço agendado, quando aplicável.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Última atualização do pedido.";
                }, {
                    readonly name: "paid_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora da confirmação de pagamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "ruleOrderRequiresCustomer";
                }, {
                    readonly fieldName: "payment_id";
                    readonly targetEntity: "Payment";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "rulePaymentRequiredToConfirmOrder";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_customer_id_created_at";
                    readonly columns: readonly ["customer_id", "created_at"];
                    readonly unique: false;
                    readonly reason: "Busca de pedidos do cliente por período.";
                }, {
                    readonly indexName: "idx_order_status_created_at";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar pedidos por status no admin.";
                }, {
                    readonly indexName: "idx_order_paid_at";
                    readonly columns: readonly ["paid_at"];
                    readonly unique: false;
                    readonly reason: "Apuração de métricas por data de pagamento.";
                }, {
                    readonly indexName: "idx_order_scheduled_service_at";
                    readonly columns: readonly ["scheduled_service_at"];
                    readonly unique: false;
                    readonly reason: "Agenda de serviços.";
                }, {
                    readonly indexName: "idx_order_order_number";
                    readonly columns: readonly ["order_number"];
                    readonly unique: true;
                    readonly reason: "Consulta rápida por número do pedido.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderDetails";
                    readonly reason: "Armazenar itens do pedido e dados auxiliares do checkout.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["metricTableSalesOps"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "ruleOrderStatusLifecycle", "rulePaymentRequiredToConfirmOrder"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/salesOpsMetrics.defs" {
    export const salesOpsMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "salesOpsMetrics";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 53;
            readonly planId: "plan-metric-table-definition:salesOpsMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "salesOpsMetrics";
                readonly tableName: "sales_ops_metrics";
                readonly moduleId: "petShopStripe";
                readonly title: "Métricas de vendas e pagamentos";
                readonly purpose: "Agregar dados de pedidos e pagamentos para análise de receita, ticket médio, volume de pedidos e taxa de aprovação.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento agregado.";
                }, {
                    readonly name: "order_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pedido no momento do evento.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pagamento associado.";
                }, {
                    readonly name: "item_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo do item vendido (produto ou serviço).";
                }, {
                    readonly name: "order_total";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total dos pedidos.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "approved_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pagamentos aprovados.";
                }, {
                    readonly name: "canceled_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos cancelados.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderStatus";
                    readonly column: "order_status";
                    readonly type: "text";
                    readonly description: "Status do pedido no momento do evento";
                }, {
                    readonly dimensionId: "paymentStatus";
                    readonly column: "payment_status";
                    readonly type: "text";
                    readonly description: "Status do pagamento associado";
                }, {
                    readonly dimensionId: "itemType";
                    readonly column: "item_type";
                    readonly type: "text";
                    readonly description: "Tipo do item vendido (produto ou serviço)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "order_total";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total dos pedidos";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "order_total";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio dos pedidos";
                }, {
                    readonly measureId: "approvedPayments";
                    readonly column: "approved_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pagamentos aprovados";
                }, {
                    readonly measureId: "canceledOrders";
                    readonly column: "canceled_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos cancelados";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderPaid", "orderCanceled", "serviceBookingCreated", "serviceBookingConfirmed"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "90 days";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_sales_ops_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consulta temporal de métricas.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_order_status_time";
                        readonly columns: readonly ["order_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pedido e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_payment_status_time";
                        readonly columns: readonly ["payment_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pagamento e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_item_type_time";
                        readonly columns: readonly ["item_type", "event_time"];
                        readonly purpose: "Filtrar métricas por tipo de item e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseUpdateMetricsOnOrderPaid"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesOpsMetrics.defs.ts";
                readonly exportName: "salesOpsMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesOpsMetricsMetricTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/serviceBooking.defs" {
    export const serviceBookingTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "serviceBooking";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "plan-table-definition:serviceBooking";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "serviceBooking";
                readonly tableName: "service_booking";
                readonly moduleId: "petShopStripe";
                readonly title: "Agendamento de serviço";
                readonly purpose: "Controlar reservas de data e horário para serviços do pet shop.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ServiceBooking";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "service_booking_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do agendamento de serviço.";
                }, {
                    readonly name: "service_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Serviço reservado no agendamento.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente que realizou o agendamento.";
                }, {
                    readonly name: "pet_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pet associado ao serviço.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido associado ao agendamento.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do agendamento (ex.: pendente, confirmado, concluído, cancelado).";
                }, {
                    readonly name: "scheduled_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data do agendamento.";
                }, {
                    readonly name: "scheduled_start_time";
                    readonly type: "time";
                    readonly nullable: false;
                    readonly description: "Horário de início do agendamento.";
                }, {
                    readonly name: "scheduled_end_time";
                    readonly type: "time";
                    readonly nullable: true;
                    readonly description: "Horário de término previsto do agendamento.";
                }, {
                    readonly name: "timezone";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Fuso horário do agendamento.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações do cliente ou do pet shop.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do agendamento.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora da última atualização do agendamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento do agendamento.";
                }];
                readonly primaryKey: readonly ["service_booking_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_id";
                    readonly targetEntity: "Service";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Serviço agendado.";
                }, {
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Cliente responsável pelo agendamento.";
                }, {
                    readonly fieldName: "pet_id";
                    readonly targetEntity: "Pet";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Pet atendido no agendamento.";
                }, {
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular o agendamento ao pedido.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_service_booking_customer";
                    readonly columns: readonly ["customer_id", "scheduled_date"];
                    readonly reason: "Listagem de agendamentos por cliente e data.";
                }, {
                    readonly indexName: "idx_service_booking_pet";
                    readonly columns: readonly ["pet_id", "scheduled_date"];
                    readonly reason: "Consultas de agendamentos por pet.";
                }, {
                    readonly indexName: "idx_service_booking_service_date";
                    readonly columns: readonly ["service_id", "scheduled_date"];
                    readonly reason: "Consulta de agendamentos por serviço e data.";
                }, {
                    readonly indexName: "idx_service_booking_order";
                    readonly columns: readonly ["order_id"];
                    readonly reason: "Localizar agendamento pelo pedido.";
                }, {
                    readonly indexName: "idx_service_booking_status_date";
                    readonly columns: readonly ["status", "scheduled_date"];
                    readonly reason: "Filtros de status e agenda.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceBooking.defs.ts";
                readonly exportName: "serviceBookingTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceBookingTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseAddToCart.defs" {
    export const usecaseAddToCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseAddToCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseAddToCart";
                readonly title: "Adicionar item ao carrinho";
                readonly purpose: "Adicionar produto ou serviço ao carrinho do cliente e recalcular totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["addToCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseAddToCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseConfirmStripePayment.defs" {
    export const usecaseConfirmStripePaymentUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseConfirmStripePayment";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseConfirmStripePayment";
                readonly title: "Confirmar pagamento Stripe";
                readonly purpose: "Atualizar status do pedido após confirmação de pagamento e registrar métricas.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "salesOpsMetrics"];
                readonly commands: readonly ["confirmStripePayment"];
                readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseConfirmStripePaymentUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseCreateOrder.defs" {
    export const usecaseCreateOrderUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseCreateOrder";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseCreateOrder";
                readonly title: "Criar pedido";
                readonly purpose: "Gerar pedido a partir do carrinho confirmado e marcar carrinho como convertido.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["order", "cart"];
                readonly commands: readonly ["startCheckout"];
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            };
        };
    };
    export default usecaseCreateOrderUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetCart.defs" {
    export const usecaseGetCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetCart";
                readonly title: "Consultar carrinho";
                readonly purpose: "Carregar o carrinho ativo do cliente com itens e totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetMetricsDashboard.defs" {
    export const usecaseGetMetricsDashboardUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetMetricsDashboard";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetMetricsDashboard";
                readonly title: "Consultar métricas de vendas";
                readonly purpose: "Obter séries temporais de métricas de vendas e pagamentos para dashboard.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetMetricsDashboardUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderAdminList.defs" {
    export const usecaseGetOrderAdminListUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderAdminList";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderAdminList";
                readonly title: "Listar pedidos administrativos";
                readonly purpose: "Listar pedidos por status e período para gestão administrativa.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderAdminListUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderHistory.defs" {
    export const usecaseGetOrderHistoryUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderHistory";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderHistory";
                readonly title: "Listar pedidos do cliente";
                readonly purpose: "Listar pedidos do cliente para acompanhamento de histórico.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderHistoryUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetServiceBookings.defs" {
    export const usecaseGetServiceBookingsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetServiceBookings";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetServiceBookings";
                readonly title: "Listar agendamentos";
                readonly purpose: "Consultar agendamentos por cliente, pet ou serviço.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate"];
                readonly readsTables: readonly ["serviceBooking"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetServiceBookingsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseManageCatalog.defs" {
    export const usecaseManageCatalogUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseManageCatalog";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseManageCatalog";
                readonly title: "Gerenciar catálogo";
                readonly purpose: "Cadastrar, editar ou desativar produtos e serviços, preços e disponibilidade.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["catalogAggregate"];
                readonly outputEntities: readonly ["catalogAggregate"];
                readonly readsTables: readonly ["product", "service", "catalogCategory"];
                readonly writesTables: readonly ["product", "service", "catalogCategory"];
                readonly commands: readonly ["manageCatalog"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseManageCatalogUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseReconcilePayments.defs" {
    export const usecaseReconcilePaymentsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseReconcilePayments";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseReconcilePayments";
                readonly title: "Conciliar recebíveis";
                readonly purpose: "Registrar conciliação de pagamentos aprovados e lançar recebíveis.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["receivableAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["receivableAggregate"];
                readonly readsTables: readonly ["order", "payment", "stripeTransaction"];
                readonly writesTables: readonly ["receivable", "financialEntry"];
                readonly commands: readonly ["reconcilePayments"];
                readonly rulesApplied: readonly ["ruleReceivableFromPayment"];
            };
        };
    };
    export default usecaseReconcilePaymentsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseScheduleService.defs" {
    export const usecaseScheduleServiceUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseScheduleService";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseScheduleService";
                readonly title: "Agendar serviço";
                readonly purpose: "Criar agendamento de serviço e vincular ao pedido quando aplicável.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["serviceBooking", "order"];
                readonly commands: readonly ["scheduleService"];
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
        };
    };
    export default usecaseScheduleServiceUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateCart.defs" {
    export const usecaseUpdateCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateCart";
                readonly title: "Atualizar carrinho";
                readonly purpose: "Alterar quantidades ou remover itens do carrinho e atualizar totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["updateCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseUpdateCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateMetricsOnOrderPaid.defs" {
    export const usecaseUpdateMetricsOnOrderPaidUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateMetricsOnOrderPaid";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateMetricsOnOrderPaid";
                readonly title: "Atualizar métricas de vendas";
                readonly purpose: "Atualizar métricas operacionais quando pedidos são pagos ou cancelados.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["salesOpsMetrics"];
                readonly commands: readonly [];
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseUpdateMetricsOnOrderPaidUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateOrderStatus.defs" {
    export const usecaseUpdateOrderStatusUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateOrderStatus";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateOrderStatus";
                readonly title: "Atualizar status do pedido";
                readonly purpose: "Alterar status do pedido conforme ciclo de vida.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly commands: readonly ["updateOrderStatus"];
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
            };
        };
    };
    export default usecaseUpdateOrderStatusUsecasePlan;
}
declare module "_102030_/l1/petshop/module" {
    export interface PetshopCatalogProduct {
        productId: string;
        name: string;
        category: string;
        priceInCents: number;
        currency: 'BRL';
        highlightScore: number;
        stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
        description: string;
        updatedAt: string;
    }
    export interface PetshopSeedResult {
        insertedCount: number;
        totalCount: number;
        seededAt: string;
    }
    export interface PetshopHomeLoadParams {
        category?: string;
        query?: string;
        topLimit?: number;
        forceSeed?: boolean;
    }
    export interface PetshopHomeLoadResult {
        seed: PetshopSeedResult;
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
    export interface PetshopUpdateProductParams {
        productId: string;
        author?: string;
        name?: string;
        category?: string;
        priceInCents?: number;
        highlightScore?: number;
        stockStatus?: PetshopCatalogProduct['stockStatus'];
        description?: string;
    }
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
    }
    export function readAppEnv(): AppEnv;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        dynamoResolvedTableName: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102030_/l1/petshop/persistence" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const tableDefinitions: TableDefinition[];
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls mdm.promoteProspect(prospectMdmId)
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        createdAt: string;
        updatedAt: string;
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getSharedPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: Array<{
            id: string;
            label: string;
            href: string;
            description?: string;
        }>;
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        backendRouter?: string;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function getPublicationTarget(targetName?: string): {
        assetBaseUrl: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
        name: string;
    };
    export function resolvePublicationDistPath(targetName: string, relativePath?: string): string;
    export function resolveActivePublicationDistPath(relativePath?: string): string;
    export function toPublishedAssetUrl(relativePath: string, targetName?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
    }
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord } from "_102034_/l1/mdm/module";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentRecord;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            userId?: string;
            authToken?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestContext {
        data: IDataRuntime;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        requestMeta?: {
            requestId?: string;
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102030_/l2/petshop/shared/mock/products" {
    import type { PetshopCatalogProduct } from "_102030_/l1/petshop/module";
    export function buildPetshopMockProducts(): PetshopCatalogProduct[];
}
declare module "_102030_/l2/petshop/shared/mock/adminMock" {
    export function getPetshopMockProducts(): import("_102030_/l1/petshop/module").PetshopCatalogProduct[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from "_102034_/l1/mdm/module";
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102030_/l1/petshop/layer_3_usecases/catalogUsecases" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult, PetshopSeedResult, PetshopUpdateProductParams } from "_102030_/l1/petshop/module";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function resetPetshopCatalogForTests(): void;
    export function seedPetshopMockData(ctx: RequestContext, force?: boolean): Promise<PetshopSeedResult>;
    export function listPetshopCatalog(ctx: RequestContext, input?: {
        category?: string;
        query?: string;
    }): Promise<PetshopCatalogProduct[]>;
    export function getPetshopTopProducts(ctx: RequestContext, limit?: number): Promise<PetshopCatalogProduct[]>;
    export function loadPetshopHome(ctx: RequestContext, input?: PetshopHomeLoadParams): Promise<PetshopHomeLoadResult>;
    export function updatePetshopProduct(ctx: RequestContext, input: PetshopUpdateProductParams): Promise<PetshopCatalogProduct>;
}
declare module "_102030_/l1/petshop/layer_2_controllers/catalogHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const petshopListCatalogHandler: BffHandler;
    export const petshopGetTopProductsHandler: BffHandler;
    export const petshopSeedMockDataHandler: BffHandler;
    export const petshopHomeLoadHandler: BffHandler;
    export const petshopUpdateProductHandler: BffHandler;
}
declare module "_102029_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102034_/l1/server/layer_1_external/observability/ConsoleLogger" {
    import type { ILogger } from "_102034_/l1/server/layer_2_controllers/contracts";
    export class ConsoleLogger implements ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/moduleRegistry" {
    import { type BffHandler, type ModuleBffRegistration, type RoutineResolution } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function getModuleBffRegistrations(): ModuleBffRegistration[];
    export function resolveRoutineResolution(routine: string): RoutineResolution;
    export function loadModuleRouter(registration: ModuleBffRegistration): Promise<Map<string, BffHandler>>;
    export function resetModuleRouterCache(): void;
}
declare module "_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function createMemoryDataRuntime(): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/pg" {
    export { getSharedPgPool, queryRows, withPgTransaction, } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
}
declare module "_102034_/l1/mdm/tableNames" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getMdmTableNames(appEnv: AppEnv['appEnv']): {
        documents: string;
        documentsEntitiesIndex: string;
        documentsProspectsIndex: string;
        kv: string;
        relationship: string;
        prospectRelationship: string;
        auditLog: string;
        tag: string;
        comment: string;
        attachment: string;
        numberSequence: string;
        outbox: string;
        replicationFailures: string;
        monitoringWrite: string;
        errorLog: string;
        statusHistory: string;
    };
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/MdmDataRuntimePostgres" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function createPostgresDataRuntime(env: AppEnv): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/runtimeFactory" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function getSharedDataRuntime(): IDataRuntime;
    export function resetSharedDataRuntime(): void;
}
declare module "_102034_/l1/monitor/module" {
    export type MonitorStatusGroup = 'success' | 'client_error' | 'server_error' | 'not_found';
    export interface MonitorBffExecutionLogRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
    /** Continuous aggregate — no id or updatedAt, maintained by TimescaleDB. */
    export interface MonitorBffExecutionAggregateMinuteRecord {
        bucketStart: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        totalCount: number;
        successCount: number;
        clientErrorCount: number;
        serverErrorCount: number;
        notFoundCount: number;
        totalDurationMs: number;
    }
    export interface MonitorClientTelemetryEventRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        module: string;
        routine: string;
        eventType: string;
        label?: string | null;
        durationMs?: number | null;
        metadata?: unknown;
        recordedAt: string;
        receivedAt: string;
    }
    export interface MonitorSeriesPoint {
        timestamp: string;
        total: number;
        success: number;
        clientError: number;
        serverError: number;
        notFound: number;
    }
    export interface MonitorExecutionEvent {
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/persistence/MonitorPersistenceMetadata" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export interface MonitorTableMetadata {
        projectId: string;
        moduleId: string;
        repositoryName: string;
        tableName: string;
        description: string;
        purpose: string;
        storageProfile: string;
        backupHot: boolean;
        writeMode: string;
        dynamoTableName: string | null;
        dynamoPartitionKey: string | null;
        dynamoSortKey: string | null;
        dynamoTtlField: string | null;
        localIndexes: Array<{
            name: string;
            unique: boolean;
            columns: string[];
        }>;
        detailsInDynamoOnly: boolean;
    }
    export class MonitorPersistenceMetadata {
        private readonly env;
        constructor(env: AppEnv);
        listAll(): Promise<MonitorTableMetadata[]>;
        listPostgresTables(): Promise<import("_102034_/l1/server/layer_1_external/persistence/contracts").ResolvedTableDefinition[]>;
        listDynamoTables(): Promise<import("_102034_/l1/server/layer_1_external/persistence/contracts").ResolvedTableDefinition[]>;
        findByPostgresTableName(tableName: string): Promise<MonitorTableMetadata | null>;
        findByDynamoTableName(tableName: string): Promise<MonitorTableMetadata | null>;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/postgres/MonitorRuntimePostgres" {
    import { type AttributeValue } from '@aws-sdk/client-dynamodb';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MonitorBffExecutionLogRecord, MonitorExecutionEvent } from "_102034_/l1/monitor/module";
    type MonitorPostgresColumn = {
        name: string;
        dataType: string;
        isNullable: boolean;
        defaultValue: string | null;
    };
    type MonitorPostgresIndex = {
        name: string;
        unique: boolean;
        method: string;
        columns: string[];
    };
    type MonitorDynamoKey = Record<string, AttributeValue>;
    export function normalizeStringList(value: unknown): string[];
    export function isSafeMonitorIdentifier(value: string): boolean;
    export function normalizeInspectFilters(input: unknown): Record<string, string>;
    export function normalizeDynamoKey(key: MonitorDynamoKey | undefined): string | null;
    export function decodeDynamoKey(cursor?: string | null): MonitorDynamoKey | undefined;
    export function parseRoutineParts(routine: string): {
        module: string;
        pageName: string;
        command: string;
    };
    export function getStatusGroup(statusCode: number): "success" | "client_error" | "server_error" | "not_found";
    export class MonitorRuntimePostgres {
        private readonly env;
        private readonly metadata;
        constructor(env?: AppEnv);
        recordExecution(event: MonitorExecutionEvent): Promise<void>;
        static isMissingMonitorStorageError(error: unknown): boolean;
        listKnownPostgresTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
        }>>;
        private listAvailableDatabases;
        private getKnownPostgresTableNames;
        private getKnownDynamoTableNames;
        private getTableNameByRepositoryName;
        private assertKnownPostgresTable;
        private assertKnownDynamoTable;
        private getPoolForDatabase;
        private listPostgresColumns;
        private getPostgresPrimaryKey;
        private listPostgresIndexes;
        private getPostgresTableMetrics;
        listKnownPostgresTablesDetailed(databaseName?: string): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
            totalSizeBytes: number | null;
        }>>;
        getPostgresTableDetails(input: {
            databaseName?: string;
            tableName: string;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            metrics: {
                rowCount: number;
                totalSizeBytes: number;
            };
            columns: MonitorPostgresColumn[];
            primaryKey: string[];
            indexes: MonitorPostgresIndex[];
        }>;
        inspectPostgresTable(input: {
            databaseName?: string;
            tableName: string;
            page?: number;
            filters?: unknown;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<Pick<MonitorPostgresColumn, 'name' | 'dataType' | 'isNullable'>>;
            pagination: {
                page: number;
                pageSize: number;
                totalRows: number;
                totalPages: number;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            order: {
                primary: string[];
                fallback: string;
            };
        }>;
        listKnownDynamoTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            itemCount: number | null;
            tableStatus: string | null;
            tableSizeBytes: number | null;
            metricsAreApproximate: boolean;
        }>>;
        getPostgresSnapshot(input?: {
            databaseName?: string;
        }): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            connection: {
                host: string;
                port: number;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                activeConnectionsByState: Record<string, number>;
                maxConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        }>;
        getDynamoSnapshot(): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            region: string;
            tables: Array<{
                tableName: string;
                description: string | null;
                moduleId: string | null;
                repositoryName: string | null;
                storageProfile: string | null;
                backupHot: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        }>;
        getDynamoTableDetails(input: {
            tableName: string;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            summary: {
                tableStatus: string | null;
                itemCount: number;
                tableSizeBytes: number;
                billingMode: string | null;
                tableClass: string | null;
                metricsAreApproximate: boolean;
            };
            keys: {
                partitionKey: string | null;
                sortKey: string | null;
            };
            attributeDefinitions: Array<{
                name: string;
                type: string;
            }>;
            globalSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
            localSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
        }>;
        inspectDynamoTable(input: {
            tableName: string;
            cursor?: string;
            filters?: unknown;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<{
                name: string;
                type: string;
                filterable: boolean;
            }>;
            pagination: {
                pageSize: number;
                cursor: string | null;
                nextCursor: string | null;
                hasNextPage: boolean;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            metricsAreApproximate: boolean;
        }>;
        getSnapshotData(): Promise<{
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<Pick<MonitorBffExecutionLogRecord, 'routine' | 'statusCode' | 'statusGroup' | 'errorCode' | 'finishedAt'>>;
        }>;
        recordTelemetry(events: Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            module: string;
            routine: string;
            eventType: string;
            label: string;
            durationMs: number | null;
            metadata: Record<string, unknown> | null;
            recordedAt: string;
            receivedAt: string;
        }>): Promise<void>;
        loadRequestTrace(input: {
            requestId?: string;
            traceId?: string;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            ok: boolean;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
        loadAbends(input: {
            module?: string;
            limit?: number;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/cache/BffExecutionSeriesStore" {
    import type { MonitorExecutionEvent, MonitorSeriesPoint } from "_102034_/l1/monitor/module";
    export class BffExecutionSeriesStore {
        private readonly maxWindowSeconds;
        private readonly buckets;
        constructor(maxWindowSeconds?: number);
        record(event: MonitorExecutionEvent): void;
        getSeries(input?: {
            windowSeconds?: number;
            routine?: string;
            source?: 'http' | 'message' | 'test';
        }): MonitorSeriesPoint[];
        reset(): void;
        private trim;
        private listRecentTimestamps;
        private incrementDetailPoint;
    }
    export function getSharedBffExecutionSeriesStore(): BffExecutionSeriesStore;
    export function resetSharedBffExecutionSeriesStore(): void;
}
declare module "_102034_/l1/monitor/layer_4_entities/MonitorExecutionEntity" {
    import type { MonitorExecutionEvent } from "_102034_/l1/monitor/module";
    export class MonitorExecutionEntity {
        static record(event: MonitorExecutionEvent): Promise<void>;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/execBff" {
    import { type BffRequest, type BffResponse, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createRequestContext(dataRuntime?: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): RequestContext;
    export function createDefaultRequestContext(): RequestContext;
    export function execBff(request: BffRequest, ctx?: RequestContext): Promise<{
        response: BffResponse;
        statusCode: number;
    }>;
}
declare module "_102030_/l1/petshop/layer_2_controllers/router.test" { }
declare module "_102030_/l1/petshop/layer_2_controllers/router" {
    import type { BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createPetshopRouter(): Map<string, BffHandler>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102030_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102030_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102030_/l2/petShopStripe/accountOrdersPage.defs" {
    export const accountOrdersPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "accountOrdersPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 89;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "accountOrdersPage";
                readonly pageName: "Minha conta e pedidos";
                readonly actor: "cliente";
                readonly purpose: "Acompanhar histórico de compras, serviços e status de pedidos.";
                readonly capabilities: readonly ["manageCartCheckout", "bookService"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly ["serviceBooking"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer"];
                readonly pageInputs: readonly [{
                    readonly name: "orderStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro opcional de status do pedido.";
                }, {
                    readonly name: "bookingStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro opcional de status do agendamento.";
                }, {
                    readonly name: "startDate";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data inicial para filtrar histórico.";
                }, {
                    readonly name: "endDate";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data final para filtrar histórico.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "productServiceDetailPage";
                    readonly trigger: "Repetir compra ou agendar serviço";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "filtrosDeHistorico";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "orderAndBookingFilters";
                        readonly purpose: "Permitir filtrar pedidos e agendamentos por período e status.";
                        readonly userActions: readonly ["Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "historicoDePedidos";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderHistoryList";
                        readonly purpose: "Listar pedidos do cliente com itens, valores e status de pagamento/entrega.";
                        readonly userActions: readonly ["Visualizar pedido", "Repetir compra"];
                        readonly requiredEntities: readonly ["Order", "OrderItem", "Payment"];
                        readonly readsFields: readonly ["Order.order_id", "Order.order_number", "Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "OrderItem", "Payment.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "agendamentosDeServicos";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceBookingList";
                        readonly purpose: "Exibir agendamentos do cliente com data/hora, pet e status.";
                        readonly userActions: readonly ["Ver detalhes do agendamento", "Agendar novamente"];
                        readonly requiredEntities: readonly ["ServiceBooking", "Service", "Pet"];
                        readonly readsFields: readonly ["ServiceBooking.service_booking_id", "ServiceBooking.status", "ServiceBooking.scheduled_date", "ServiceBooking.scheduled_start_time", "ServiceBooking.scheduled_end_time", "ServiceBooking.timezone", "Service", "Pet"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderHistory";
                readonly purpose: "Listar pedidos do cliente com status e itens.";
                readonly kind: "query";
                readonly input: {
                    readonly customerId: "uuid";
                    readonly filters: {
                        readonly orderStatus: "string?";
                        readonly startDate: "date?";
                        readonly endDate: "date?";
                    };
                };
                readonly output: {
                    readonly orders: readonly [{
                        readonly orderId: "uuid";
                        readonly orderNumber: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                        readonly createdAt: "datetime";
                        readonly items: readonly [{
                            readonly itemType: "product|service";
                            readonly itemId: "uuid";
                            readonly name: "string";
                            readonly quantity: "number";
                            readonly unitPrice: "number";
                        }];
                    }];
                };
                readonly readsEntities: readonly ["Order", "OrderItem", "Payment"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetOrderHistory"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getCustomerServiceBookings";
                readonly purpose: "Listar agendamentos de serviços do cliente com status e dados do pet.";
                readonly kind: "query";
                readonly input: {
                    readonly customerId: "uuid";
                    readonly filters: {
                        readonly bookingStatus: "string?";
                        readonly startDate: "date?";
                        readonly endDate: "date?";
                    };
                };
                readonly output: {
                    readonly bookings: readonly [{
                        readonly serviceBookingId: "uuid";
                        readonly status: "string";
                        readonly scheduledDate: "date";
                        readonly scheduledStartTime: "time";
                        readonly scheduledEndTime: "time?";
                        readonly timezone: "string";
                        readonly service: {
                            readonly serviceId: "uuid";
                            readonly name: "string";
                        };
                        readonly pet: {
                            readonly petId: "uuid";
                            readonly name: "string";
                        };
                    }];
                };
                readonly readsEntities: readonly ["ServiceBooking", "Service", "Pet"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["serviceBooking"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetServiceBookings"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default accountOrdersPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminCatalogPage.defs" {
    export const adminCatalogPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminCatalogPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 91;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminCatalogPage";
                readonly pageName: "Administração de catálogo";
                readonly actor: "adminPetShop";
                readonly purpose: "Cadastrar, editar e desativar produtos, serviços e categorias.";
                readonly capabilities: readonly ["manageCatalog"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["catalogManagement"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["productService", "organization"];
                readonly pageInputs: readonly [{
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Tipo de item a administrar (produto, serviço ou categoria).";
                }, {
                    readonly name: "statusFilter";
                    readonly type: "string[]";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro de status para itens do catálogo.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminDashboardPage";
                    readonly trigger: "Voltar ao dashboard";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e lista de catálogo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "CatalogFilters";
                        readonly purpose: "Definir filtros de tipo, status e categoria para a lista administrativa.";
                        readonly userActions: readonly ["Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Product", "Service", "CatalogCategory"];
                        readonly readsFields: readonly ["Product.status", "Product.categoryId", "Service.status", "Service.categoryId", "CatalogCategory.id", "CatalogCategory.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "CatalogAdminList";
                        readonly purpose: "Exibir lista de itens do catálogo com status e ações rápidas.";
                        readonly userActions: readonly ["Selecionar item", "Iniciar criação de item", "Ativar/desativar item"];
                        readonly requiredEntities: readonly ["Product", "Service", "CatalogCategory"];
                        readonly readsFields: readonly ["Product.id", "Product.name", "Product.price", "Product.status", "Service.id", "Service.name", "Service.price", "Service.status", "CatalogCategory.id", "CatalogCategory.name", "CatalogCategory.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Editor de item de catálogo";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "CatalogItemForm";
                        readonly purpose: "Cadastrar ou editar dados do item selecionado do catálogo.";
                        readonly userActions: readonly ["Salvar item", "Atualizar item", "Desativar item"];
                        readonly requiredEntities: readonly ["Product", "Service", "CatalogCategory"];
                        readonly readsFields: readonly ["Product.id", "Product.name", "Product.description", "Product.price", "Product.status", "Product.categoryId", "Service.id", "Service.name", "Service.description", "Service.price", "Service.duration", "Service.status", "Service.categoryId", "CatalogCategory.id", "CatalogCategory.name", "CatalogCategory.status"];
                        readonly writesFields: readonly ["Product.name", "Product.description", "Product.price", "Product.status", "Product.categoryId", "Service.name", "Service.description", "Service.price", "Service.duration", "Service.status", "Service.categoryId", "CatalogCategory.name", "CatalogCategory.status"];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getCatalogAdminList";
                readonly purpose: "Listar itens do catálogo para administração.";
                readonly kind: "query";
                readonly input: {
                    readonly itemType: "string?";
                    readonly statusFilter: "string[]?";
                    readonly categoryId: "string?";
                    readonly searchText: "string?";
                    readonly page: "number?";
                    readonly pageSize: "number?";
                };
                readonly output: {
                    readonly items: readonly [{
                        readonly itemId: "string";
                        readonly itemType: "string";
                        readonly name: "string";
                        readonly categoryId: "string?";
                        readonly categoryName: "string?";
                        readonly price: "number?";
                        readonly status: "string";
                        readonly updatedAt: "string";
                    }];
                    readonly pagination: {
                        readonly page: "number";
                        readonly pageSize: "number";
                        readonly totalItems: "number";
                        readonly totalPages: "number";
                    };
                };
                readonly readsEntities: readonly ["Product", "Service", "CatalogCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseManageCatalog"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "manageCatalog";
                readonly purpose: "Criar, editar ou desativar itens do catálogo.";
                readonly kind: "command";
                readonly input: {
                    readonly action: "string";
                    readonly itemType: "string";
                    readonly itemId: "string?";
                    readonly payload: {
                        readonly name: "string?";
                        readonly description: "string?";
                        readonly price: "number?";
                        readonly duration: "number?";
                        readonly status: "string?";
                        readonly categoryId: "string?";
                    };
                };
                readonly output: {
                    readonly itemId: "string";
                    readonly itemType: "string";
                    readonly status: "string";
                    readonly updatedAt: "string";
                };
                readonly readsEntities: readonly ["Product", "Service", "CatalogCategory"];
                readonly writesEntities: readonly ["Product", "Service", "CatalogCategory"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseManageCatalog"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminCatalogPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminDashboardPage.defs" {
    export const adminDashboardPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminDashboardPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 90;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminDashboardPage";
                readonly pageName: "Dashboard administrativo";
                readonly actor: "adminPetShop";
                readonly purpose: "Fornecer visão geral de pedidos, agenda e indicadores rápidos.";
                readonly capabilities: readonly ["manageOrdersServices", "financialOverview", "metricsDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycleManagement"];
                    readonly taskWorkflows: readonly ["serviceBooking", "paymentReconciliation"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["organization"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Intervalo de datas para filtrar KPIs, pedidos e agenda.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminOrdersPage";
                    readonly trigger: "Gerenciar pedidos";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminFinancialPage";
                    readonly trigger: "Ver financeiro";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminMetricsPage";
                    readonly trigger: "Ver métricas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo operacional";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "kpiSummaryCards";
                        readonly purpose: "Exibir KPIs de pedidos e agenda no período.";
                        readonly userActions: readonly ["Ver resumo operacional"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.status", "ServiceBooking.scheduled_date"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "operationalQueues";
                        readonly purpose: "Mostrar filas de pedidos por status e próximos agendamentos.";
                        readonly userActions: readonly ["Ver resumo operacional", "Acessar gestão de pedidos"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.order_number", "Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.service_id", "ServiceBooking.status", "ServiceBooking.scheduled_date", "ServiceBooking.scheduled_start_time"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Indicadores rápidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsSummaryWidget";
                        readonly purpose: "Apresentar resumo das métricas de vendas e pagamentos.";
                        readonly userActions: readonly ["Acessar métricas"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["salesOpsMetrics.totalRevenue", "salesOpsMetrics.orderCount", "salesOpsMetrics.approvedPayments", "salesOpsMetrics.canceledOrders"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAdminOverview";
                readonly purpose: "Carregar KPIs resumidos e filas operacionais.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly orderCountsByStatus: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly paymentStatusCounts: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly recentOrders: readonly [{
                        readonly orderId: "string";
                        readonly orderNumber: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                        readonly createdAt: "string";
                    }];
                    readonly upcomingBookings: readonly [{
                        readonly serviceBookingId: "string";
                        readonly serviceId: "string";
                        readonly status: "string";
                        readonly scheduledDate: "string";
                        readonly scheduledStartTime: "string";
                    }];
                };
                readonly readsEntities: readonly ["Order", "ServiceBooking"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "serviceBooking"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetOrderAdminList", "usecaseGetServiceBookings"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getMetricsSummary";
                readonly purpose: "Obter resumo das métricas de vendas para o painel.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly totalRevenue: "number";
                    readonly orderCount: "number";
                    readonly approvedPayments: "number";
                    readonly canceledOrders: "number";
                    readonly averageTicket: "number";
                };
                readonly readsEntities: readonly ["salesOpsMetrics"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetMetricsDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminDashboardPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminMetricsPage.defs" {
    export const adminMetricsPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminMetricsPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 94;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminMetricsPage";
                readonly pageName: "Métricas";
                readonly actor: "adminPetShop";
                readonly purpose: "Exibir métricas de vendas e pagamentos em dashboard administrativo.";
                readonly capabilities: readonly ["metricsDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["organization"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "DateRange";
                    readonly required: false;
                    readonly sources: readonly ["query", "uiState"];
                    readonly description: "Intervalo de datas para consulta das métricas.";
                }, {
                    readonly name: "filterDimensions";
                    readonly type: "MetricsFilterDimensions";
                    readonly required: false;
                    readonly sources: readonly ["query", "uiState"];
                    readonly description: "Dimensões de filtro (status do pedido, status do pagamento, tipo de item).";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "adminDashboardPage";
                    readonly trigger: "Acessar métricas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de métricas";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsFilters";
                        readonly purpose: "Selecionar período e dimensões de filtro para atualizar o dashboard.";
                        readonly userActions: readonly ["Definir intervalo de datas", "Selecionar status do pedido", "Selecionar status do pagamento", "Selecionar tipo de item", "Aplicar filtros"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["event_time", "order_status", "payment_status", "item_type"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
                    }];
                }, {
                    readonly sectionName: "Dashboard de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsCharts";
                        readonly purpose: "Exibir séries temporais e agregações de receita, pedidos e pagamentos.";
                        readonly userActions: readonly ["Visualizar gráficos", "Inspecionar métricas por período"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["event_time", "order_total", "order_count", "approved_count", "canceled_count", "order_status", "payment_status", "item_type"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
                    }, {
                        readonly organismName: "metricsSummaryCards";
                        readonly purpose: "Apresentar totais e indicadores resumidos do período selecionado.";
                        readonly userActions: readonly ["Visualizar indicadores", "Comparar totais"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["order_total", "order_count", "approved_count", "canceled_count"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getMetricsDashboard";
                readonly purpose: "Obter séries temporais e agregações para o dashboard.";
                readonly kind: "query";
                readonly input: {
                    readonly dateRange: {
                        readonly from: "date";
                        readonly to: "date";
                    };
                    readonly filters: {
                        readonly orderStatus: readonly ["string"];
                        readonly paymentStatus: readonly ["string"];
                        readonly itemType: readonly ["string"];
                    };
                    readonly granularity: "hour|day|week|month";
                };
                readonly output: {
                    readonly series: {
                        readonly revenue: readonly [{
                            readonly timestamp: "timestamptz";
                            readonly value: "number";
                        }];
                        readonly orders: readonly [{
                            readonly timestamp: "timestamptz";
                            readonly value: "number";
                        }];
                        readonly averageTicket: readonly [{
                            readonly timestamp: "timestamptz";
                            readonly value: "number";
                        }];
                        readonly approvalRate: readonly [{
                            readonly timestamp: "timestamptz";
                            readonly value: "number";
                        }];
                        readonly canceledOrders: readonly [{
                            readonly timestamp: "timestamptz";
                            readonly value: "number";
                        }];
                    };
                    readonly aggregations: {
                        readonly totalRevenue: "number";
                        readonly orderCount: "number";
                        readonly averageTicket: "number";
                        readonly approvedPayments: "number";
                        readonly canceledOrders: "number";
                    };
                    readonly dimensions: {
                        readonly orderStatus: readonly ["string"];
                        readonly paymentStatus: readonly ["string"];
                        readonly itemType: readonly ["string"];
                    };
                };
                readonly readsEntities: readonly ["salesOpsMetricsAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetMetricsDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminMetricsPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminOrdersPage.defs" {
    export const adminOrdersPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminOrdersPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 92;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminOrdersPage";
                readonly pageName: "Administração de pedidos/serviços";
                readonly actor: "adminPetShop";
                readonly purpose: "Gerenciar status de pedidos e acompanhar serviços agendados.";
                readonly capabilities: readonly ["manageOrdersServices"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycleManagement"];
                    readonly taskWorkflows: readonly ["serviceBooking"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["organization", "customer"];
                readonly pageInputs: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string[]";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro de status do pedido para a listagem.";
                }, {
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data inicial do período para filtrar pedidos e serviços.";
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data final do período para filtrar pedidos e serviços.";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Número do pedido para busca rápida.";
                }, {
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["userSelection"];
                    readonly description: "Identificador do pedido selecionado para atualização de status.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "order_id";
                }, {
                    readonly name: "serviceDate";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data para filtrar agendamentos de serviços.";
                }, {
                    readonly name: "serviceStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Status do agendamento para filtragem.";
                }, {
                    readonly name: "serviceId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Serviço para filtrar agendamentos.";
                    readonly entityRef: "Service";
                    readonly fieldRef: "service_id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminDashboardPage";
                    readonly trigger: "Voltar ao dashboard";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Pedidos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "orderFilters";
                        readonly purpose: "Permitir filtrar pedidos por status, período e número do pedido.";
                        readonly userActions: readonly ["Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.created_at", "Order.order_number"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "orderList";
                        readonly purpose: "Exibir lista de pedidos com status e pagamento para gestão administrativa.";
                        readonly userActions: readonly ["Selecionar pedido", "Atualizar status do pedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.order_id", "Order.order_number", "Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "Order.updated_at"];
                        readonly writesFields: readonly ["Order.status"];
                        readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "Agenda de serviços";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceBookingFilters";
                        readonly purpose: "Filtrar agendamentos por data, serviço e status.";
                        readonly userActions: readonly ["Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly ["ServiceBooking", "Service"];
                        readonly readsFields: readonly ["ServiceBooking.scheduled_date", "ServiceBooking.status", "Service.service_id"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "serviceBookingList";
                        readonly purpose: "Listar agendamentos de serviços com detalhes operacionais.";
                        readonly userActions: readonly ["Visualizar detalhes do agendamento"];
                        readonly requiredEntities: readonly ["ServiceBooking", "Service", "Customer", "Pet"];
                        readonly readsFields: readonly ["ServiceBooking.service_booking_id", "ServiceBooking.status", "ServiceBooking.scheduled_date", "ServiceBooking.scheduled_start_time", "ServiceBooking.scheduled_end_time", "ServiceBooking.order_id", "Service.service_id", "Service.title", "Customer.customer_id", "Customer.name", "Pet.pet_id", "Pet.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderAdminList";
                readonly purpose: "Listar pedidos por status e período.";
                readonly kind: "query";
                readonly input: {
                    readonly statusFilter: "string[]?";
                    readonly periodStart: "date?";
                    readonly periodEnd: "date?";
                    readonly orderNumber: "string?";
                    readonly page: "number?";
                    readonly pageSize: "number?";
                };
                readonly output: {
                    readonly orders: readonly [{
                        readonly orderId: "uuid";
                        readonly orderNumber: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                        readonly createdAt: "datetime";
                        readonly updatedAt: "datetime";
                    }];
                    readonly page: "number";
                    readonly pageSize: "number";
                    readonly total: "number";
                };
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetOrderAdminList"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "updateOrderStatus";
                readonly purpose: "Atualizar o status do pedido conforme o ciclo de vida.";
                readonly kind: "command";
                readonly input: {
                    readonly orderId: "uuid";
                    readonly newStatus: "string";
                    readonly statusReason: "string?";
                };
                readonly output: {
                    readonly orderId: "uuid";
                    readonly status: "string";
                    readonly statusHistory: readonly [{
                        readonly fromStatus: "string";
                        readonly toStatus: "string";
                        readonly changedAt: "datetime";
                        readonly changedBy: "string";
                    }];
                    readonly updatedAt: "datetime";
                };
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["usecaseUpdateOrderStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
            }, {
                readonly commandName: "getServiceBookings";
                readonly purpose: "Listar agendamentos de serviços para gestão.";
                readonly kind: "query";
                readonly input: {
                    readonly serviceDate: "date?";
                    readonly serviceId: "uuid?";
                    readonly status: "string?";
                    readonly page: "number?";
                    readonly pageSize: "number?";
                };
                readonly output: {
                    readonly serviceBookings: readonly [{
                        readonly serviceBookingId: "uuid";
                        readonly serviceId: "uuid";
                        readonly serviceName: "string";
                        readonly customerId: "uuid";
                        readonly customerName: "string";
                        readonly petId: "uuid";
                        readonly petName: "string";
                        readonly status: "string";
                        readonly scheduledDate: "date";
                        readonly scheduledStartTime: "time";
                        readonly scheduledEndTime: "time";
                        readonly orderId: "uuid?";
                    }];
                    readonly page: "number";
                    readonly pageSize: "number";
                    readonly total: "number";
                };
                readonly readsEntities: readonly ["ServiceBooking", "Service", "Customer", "Pet"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["serviceBooking"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetServiceBookings"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminOrdersPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/cartPage.defs" {
    export const cartPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "cartPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 86;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "cartPage";
                readonly pageName: "Carrinho";
                readonly actor: "cliente";
                readonly purpose: "Revisar itens e quantidades antes do checkout.";
                readonly capabilities: readonly ["manageCartCheckout"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["checkoutAndPayment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer", "productService"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "productServiceDetailPage";
                    readonly trigger: "Adicionar ao carrinho";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "checkoutPage";
                    readonly trigger: "Iniciar checkout";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Itens do carrinho";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "listaItensCarrinho";
                        readonly purpose: "Exibir itens do carrinho com quantidades e permitir ajustes ou remoções.";
                        readonly userActions: readonly ["Ajustar quantidade", "Remover item"];
                        readonly requiredEntities: readonly ["Cart", "CartItem", "Product", "Service"];
                        readonly readsFields: readonly ["Cart.items", "CartItem.quantity", "CartItem.unitPrice", "CartItem.totalPrice", "Product.name", "Service.name"];
                        readonly writesFields: readonly ["CartItem.quantity"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumo e checkout";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "resumoTotais";
                        readonly purpose: "Exibir subtotal, descontos e total do carrinho.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Cart"];
                        readonly readsFields: readonly ["Cart.subtotalAmount", "Cart.discountAmount", "Cart.totalAmount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "acaoIniciarCheckout";
                        readonly purpose: "Confirmar itens e iniciar o checkout criando o pedido.";
                        readonly userActions: readonly ["Iniciar checkout"];
                        readonly requiredEntities: readonly ["Cart", "Order", "OrderItem"];
                        readonly readsFields: readonly ["Cart.totalAmount", "Cart.itemsCount"];
                        readonly writesFields: readonly ["Order.status", "OrderItem"];
                        readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getCart";
                readonly purpose: "Carregar o carrinho ativo do cliente com itens e totais.";
                readonly kind: "query";
                readonly input: {
                    readonly cartContext: {
                        readonly "cartId?": "string";
                    };
                    readonly include: {
                        readonly items: "boolean";
                        readonly totals: "boolean";
                    };
                };
                readonly output: {
                    readonly cart: {
                        readonly cartId: "string";
                        readonly status: "string";
                        readonly currency: "string";
                        readonly itemsCount: "number";
                        readonly subtotalAmount: "number";
                        readonly discountAmount: "number";
                        readonly totalAmount: "number";
                        readonly items: readonly [{
                            readonly itemId: "string";
                            readonly "productId?": "string";
                            readonly "serviceId?": "string";
                            readonly name: "string";
                            readonly quantity: "number";
                            readonly unitPrice: "number";
                            readonly totalPrice: "number";
                        }];
                    };
                };
                readonly readsEntities: readonly ["Cart", "CartItem", "Product", "Service"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetCart"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "updateCart";
                readonly purpose: "Atualizar quantidade ou remover itens do carrinho.";
                readonly kind: "command";
                readonly input: {
                    readonly cartContext: {
                        readonly "cartId?": "string";
                    };
                    readonly changes: {
                        readonly items: readonly [{
                            readonly "itemId?": "string";
                            readonly "productId?": "string";
                            readonly "serviceId?": "string";
                            readonly "quantity?": "number";
                            readonly action: "updateQuantity|remove";
                        }];
                    };
                };
                readonly output: {
                    readonly cart: {
                        readonly cartId: "string";
                        readonly status: "string";
                        readonly itemsCount: "number";
                        readonly subtotalAmount: "number";
                        readonly discountAmount: "number";
                        readonly totalAmount: "number";
                        readonly items: readonly [{
                            readonly itemId: "string";
                            readonly "productId?": "string";
                            readonly "serviceId?": "string";
                            readonly name: "string";
                            readonly quantity: "number";
                            readonly unitPrice: "number";
                            readonly totalPrice: "number";
                        }];
                    };
                };
                readonly readsEntities: readonly ["Cart", "CartItem"];
                readonly writesEntities: readonly ["Cart", "CartItem"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly usecaseRefs: readonly ["usecaseUpdateCart"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "startCheckout";
                readonly purpose: "Criar pedido a partir do carrinho confirmado.";
                readonly kind: "command";
                readonly input: {
                    readonly cartContext: {
                        readonly "cartId?": "string";
                    };
                    readonly "deliveryContact?": {
                        readonly "phone?": "string";
                        readonly "email?": "string";
                    };
                    readonly "deliveryAddress?": {
                        readonly "addressId?": "string";
                        readonly "street?": "string";
                        readonly "number?": "string";
                        readonly "city?": "string";
                        readonly "state?": "string";
                        readonly "postalCode?": "string";
                    };
                };
                readonly output: {
                    readonly order: {
                        readonly orderId: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                    };
                    readonly cart: {
                        readonly cartId: "string";
                        readonly status: "string";
                    };
                };
                readonly readsEntities: readonly ["Cart", "CartItem"];
                readonly writesEntities: readonly ["Order", "OrderItem", "Cart"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["order", "cart"];
                readonly usecaseRefs: readonly ["usecaseCreateOrder"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            }];
        };
    };
    export default cartPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/catalogPage.defs" {
    export const catalogPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "catalogPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 84;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "catalogPage";
                readonly pageName: "Catálogo";
                readonly actor: "cliente";
                readonly purpose: "Listar produtos e serviços disponíveis por categoria e filtros.";
                readonly capabilities: readonly ["browseCatalog"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["productService"];
                readonly pageInputs: readonly [{
                    readonly name: "categoria";
                    readonly type: "string";
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro de categoria selecionada";
                    readonly entityRef: "CatalogCategory";
                    readonly fieldRef: "CatalogCategory.title";
                }, {
                    readonly name: "tipo";
                    readonly type: "string";
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro de tipo (produto ou serviço)";
                }, {
                    readonly name: "precoMin";
                    readonly type: "number";
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Preço mínimo para filtro";
                }, {
                    readonly name: "precoMax";
                    readonly type: "number";
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Preço máximo para filtro";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Número da página para paginação";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Tamanho da página para paginação";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "homePage";
                    readonly trigger: "Explorar catálogo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "productServiceDetailPage";
                    readonly trigger: "Selecionar item";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e categorias";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "catalogFilters";
                        readonly purpose: "Permitir ao cliente filtrar o catálogo por categoria, tipo e faixa de preço.";
                        readonly userActions: readonly ["Selecionar categoria", "Selecionar tipo", "Definir faixa de preço", "Aplicar filtros"];
                        readonly requiredEntities: readonly ["CatalogCategory"];
                        readonly readsFields: readonly ["CatalogCategory.title"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista do catálogo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "catalogList";
                        readonly purpose: "Exibir lista paginada de produtos e serviços disponíveis.";
                        readonly userActions: readonly ["Navegar páginas", "Selecionar item"];
                        readonly requiredEntities: readonly ["Product", "Service", "CatalogCategory"];
                        readonly readsFields: readonly ["Product.productId", "Product.title", "Product.price", "Product.status", "Service.serviceId", "Service.title", "Service.price", "Service.status", "CatalogCategory.title"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getCatalogList";
                readonly purpose: "Buscar lista paginada de produtos e serviços conforme filtros.";
                readonly kind: "query";
                readonly input: {
                    readonly categoria: {
                        readonly type: "string";
                        readonly required: false;
                    };
                    readonly tipo: {
                        readonly type: "string";
                        readonly required: false;
                    };
                    readonly precoMin: {
                        readonly type: "number";
                        readonly required: false;
                    };
                    readonly precoMax: {
                        readonly type: "number";
                        readonly required: false;
                    };
                    readonly page: {
                        readonly type: "number";
                        readonly required: false;
                    };
                    readonly pageSize: {
                        readonly type: "number";
                        readonly required: false;
                    };
                };
                readonly output: {
                    readonly items: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "object";
                            readonly properties: {
                                readonly itemId: {
                                    readonly type: "string";
                                };
                                readonly itemType: {
                                    readonly type: "string";
                                    readonly enum: readonly ["Product", "Service"];
                                };
                                readonly title: {
                                    readonly type: "string";
                                };
                                readonly summary: {
                                    readonly type: "string";
                                };
                                readonly price: {
                                    readonly type: "number";
                                };
                                readonly status: {
                                    readonly type: "string";
                                };
                                readonly categoryTitle: {
                                    readonly type: "string";
                                };
                            };
                        };
                    };
                    readonly pagination: {
                        readonly type: "object";
                        readonly properties: {
                            readonly page: {
                                readonly type: "number";
                            };
                            readonly pageSize: {
                                readonly type: "number";
                            };
                            readonly totalItems: {
                                readonly type: "number";
                            };
                        };
                    };
                };
                readonly readsEntities: readonly ["Product", "Service", "CatalogCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default catalogPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/checkoutPage.defs" {
    export const checkoutPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "checkoutPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 87;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "checkoutPage";
                readonly pageName: "Checkout";
                readonly actor: "cliente";
                readonly purpose: "Coletar dados finais e confirmar pagamento via Stripe.";
                readonly capabilities: readonly ["manageCartCheckout", "payWithStripe"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["checkoutAndPayment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["stripePaymentsPlugin"];
                readonly mdmRefs: readonly ["customer"];
                readonly pageInputs: readonly [{
                    readonly name: "cartId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador do carrinho confirmado para iniciar o checkout.";
                    readonly entityRef: "Cart";
                    readonly fieldRef: "cartId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "cartPage";
                    readonly trigger: "Iniciar checkout";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "accountOrdersPage";
                    readonly trigger: "Pagamento confirmado";
                    readonly description: "Acompanhar pedido após confirmação do pagamento.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "checkoutCartSummary";
                        readonly purpose: "Exibir itens confirmados do carrinho e totais do pedido.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Cart", "CartItem", "Product", "Service"];
                        readonly readsFields: readonly ["cart.items", "cart.items.itemType", "cart.items.productId", "cart.items.serviceId", "cart.items.name", "cart.items.quantity", "cart.items.unitPrice", "cart.items.totalPrice", "cart.totals.subtotal", "cart.totals.discount", "cart.totals.shipping", "cart.totals.total", "cart.currency"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Dados de entrega e contato";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "deliveryContactForm";
                        readonly purpose: "Coletar endereço de entrega e dados de contato do cliente.";
                        readonly userActions: readonly ["Informar endereço de entrega", "Informar dados de contato"];
                        readonly requiredEntities: readonly ["Address", "Customer"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["order.deliveryAddress", "order.contact"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Pagamento Stripe";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "stripePaymentConfirmation";
                        readonly purpose: "Confirmar criação do pedido e executar pagamento via Stripe.";
                        readonly userActions: readonly ["Confirmar dados do pedido", "Confirmar pagamento Stripe"];
                        readonly requiredEntities: readonly ["Order", "Payment", "StripeTransaction"];
                        readonly readsFields: readonly ["order.orderId", "order.orderNumber", "order.status", "order.paymentStatus", "order.totalAmount", "order.currency"];
                        readonly writesFields: readonly ["order.status", "order.paymentStatus", "payment.status", "stripeTransaction.status"];
                        readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getCheckoutCartSummary";
                readonly purpose: "Carregar resumo do carrinho confirmado para exibição no checkout.";
                readonly kind: "query";
                readonly input: {
                    readonly cartId: "string";
                };
                readonly output: {
                    readonly cartId: "string";
                    readonly items: readonly [{
                        readonly itemId: "string";
                        readonly itemType: "product|service";
                        readonly productId: "string?";
                        readonly serviceId: "string?";
                        readonly name: "string";
                        readonly quantity: "number";
                        readonly unitPrice: "number";
                        readonly totalPrice: "number";
                    }];
                    readonly totals: {
                        readonly subtotal: "number";
                        readonly discount: "number";
                        readonly shipping: "number";
                        readonly total: "number";
                    };
                    readonly currency: "string";
                };
                readonly readsEntities: readonly ["Cart", "CartItem", "Product", "Service"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetCart"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "createOrderFromCheckout";
                readonly purpose: "Criar pedido com base no carrinho e dados de entrega/contato do cliente.";
                readonly kind: "command";
                readonly input: {
                    readonly cartId: "string";
                    readonly deliveryAddress: {
                        readonly street: "string";
                        readonly number: "string";
                        readonly complement: "string?";
                        readonly district: "string";
                        readonly city: "string";
                        readonly state: "string";
                        readonly postalCode: "string";
                        readonly country: "string";
                    };
                    readonly contact: {
                        readonly name: "string";
                        readonly email: "string";
                        readonly phone: "string";
                    };
                };
                readonly output: {
                    readonly orderId: "string";
                    readonly orderNumber: "string";
                    readonly status: "string";
                    readonly paymentStatus: "string";
                    readonly orderSummary: {
                        readonly items: readonly [{
                            readonly itemId: "string";
                            readonly itemType: "product|service";
                            readonly name: "string";
                            readonly quantity: "number";
                            readonly unitPrice: "number";
                            readonly totalPrice: "number";
                        }];
                        readonly totals: {
                            readonly subtotal: "number";
                            readonly discount: "number";
                            readonly shipping: "number";
                            readonly total: "number";
                        };
                        readonly currency: "string";
                    };
                };
                readonly readsEntities: readonly ["Cart", "Customer", "Address"];
                readonly writesEntities: readonly ["Order", "OrderItem", "Cart"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["order", "cart"];
                readonly usecaseRefs: readonly ["usecaseCreateOrder"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            }, {
                readonly commandName: "confirmStripePayment";
                readonly purpose: "Confirmar pagamento via Stripe e atualizar status do pedido.";
                readonly kind: "command";
                readonly input: {
                    readonly orderId: "string";
                    readonly paymentIntentId: "string";
                    readonly paymentMethod: "string";
                    readonly confirmationData: {
                        readonly clientSecret: "string?";
                        readonly returnUrl: "string?";
                    };
                };
                readonly output: {
                    readonly paymentStatus: "string";
                    readonly orderStatus: "string";
                    readonly confirmation: {
                        readonly orderId: "string";
                        readonly receiptUrl: "string?";
                        readonly paidAt: "string";
                    };
                };
                readonly readsEntities: readonly ["Order", "Payment", "StripeTransaction"];
                readonly writesEntities: readonly ["Payment", "StripeTransaction", "Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "salesOpsMetrics"];
                readonly usecaseRefs: readonly ["usecaseConfirmStripePayment"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
            }];
        };
    };
    export default checkoutPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/homePage.defs" {
    export const homePagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "homePage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 83;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "homePage";
                readonly pageName: "Página inicial";
                readonly actor: "cliente";
                readonly purpose: "Apresentar o pet shop e destacar categorias e ofertas para entrada no catálogo.";
                readonly capabilities: readonly ["browseCatalog"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["productService"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "catalogPage";
                    readonly trigger: "Explorar catálogo";
                    readonly description: "Levar o cliente para a listagem completa do catálogo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Vitrine de destaques";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "catalogHighlightsShowcase";
                        readonly purpose: "Exibir categorias, produtos e serviços em destaque com preço e disponibilidade.";
                        readonly userActions: readonly ["Selecionar categoria em destaque", "Selecionar item em destaque"];
                        readonly requiredEntities: readonly ["CatalogCategory", "Product", "Service"];
                        readonly readsFields: readonly ["CatalogCategory.name", "CatalogCategory.imageUrl", "Product.productId", "Product.name", "Product.price", "Product.availabilityStatus", "Service.serviceId", "Service.name", "Service.price", "Service.availabilityStatus"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Chamada para catálogo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "catalogExploreCallToAction";
                        readonly purpose: "Incentivar o usuário a explorar o catálogo completo.";
                        readonly userActions: readonly ["Explorar catálogo"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getCatalogHighlights";
                readonly purpose: "Carregar categorias, produtos e serviços em destaque para a vitrine.";
                readonly kind: "query";
                readonly input: {
                    readonly highlightLimits: {
                        readonly type: "object";
                        readonly required: false;
                        readonly fields: {
                            readonly categories: {
                                readonly type: "number";
                            };
                            readonly products: {
                                readonly type: "number";
                            };
                            readonly services: {
                                readonly type: "number";
                            };
                        };
                    };
                    readonly filters: {
                        readonly type: "object";
                        readonly required: false;
                        readonly fields: {
                            readonly categoryIds: {
                                readonly type: "string[]";
                            };
                            readonly availabilityStatus: {
                                readonly type: "string";
                            };
                            readonly priceRange: {
                                readonly type: "object";
                                readonly fields: {
                                    readonly min: {
                                        readonly type: "number";
                                    };
                                    readonly max: {
                                        readonly type: "number";
                                    };
                                };
                            };
                        };
                    };
                };
                readonly output: {
                    readonly categories: {
                        readonly type: "array";
                        readonly items: {
                            readonly categoryId: "string";
                            readonly name: "string";
                            readonly imageUrl: "string";
                        };
                    };
                    readonly items: {
                        readonly type: "array";
                        readonly items: {
                            readonly itemType: "string";
                            readonly itemId: "string";
                            readonly name: "string";
                            readonly price: {
                                readonly amount: "number";
                                readonly currency: "string";
                            };
                            readonly availabilityStatus: "string";
                            readonly categoryIds: "string[]";
                            readonly imageUrl: "string";
                        };
                    };
                };
                readonly readsEntities: readonly ["CatalogCategory", "Product", "Service"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default homePagePagePlan;
}
declare module "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs" {
    export const pluginStripePagamentosPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginConnectionPlan;
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: AuraDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102029_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
        telemetryReceived?: number;
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102030_/l2/petshop/shared/contracts/home" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult } from "_102030_/l1/petshop/module";
    export type PetshopHomeRequest = PetshopHomeLoadParams;
    export interface PetshopHomeResponse extends PetshopHomeLoadResult {
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
}
declare module "_102030_/l2/petshop/web/shared/home" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetshopHomeRequest, PetshopHomeResponse } from "_102030_/l2/petshop/shared/contracts/home";
    export function loadPetshopHome(params?: PetshopHomeRequest, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<PetshopHomeResponse>>;
}
declare module "_102030_/l2/petshop/web/shared/homeFormatters" {
    export function formatPrice(priceInCents: number): string;
}
declare module "_102030_/l2/petshop/shared/contracts/update-product" {
    export type { PetshopUpdateProductParams, PetshopCatalogProduct } from "_102030_/l1/petshop/module";
}
declare module "_102030_/l2/petshop/web/shared/updateProduct" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetshopCatalogProduct, PetshopUpdateProductParams } from "_102030_/l2/petshop/shared/contracts/update-product";
    export function updatePetshopProduct(params: PetshopUpdateProductParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<PetshopCatalogProduct>>;
}
declare module "_102030_/l2/petshop/web/desktop/page11/home" {
    import { LitElement } from 'lit';
    import type { PetshopCatalogProduct } from "_102030_/l1/petshop/module";
    type PetshopSection = 'catalog' | 'edit-products';
    export class PetshopWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            items: {
                state: boolean;
            };
            topItems: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            editorAuthor: {
                state: boolean;
            };
        };
        currentSection: PetshopSection;
        items: PetshopCatalogProduct[];
        topItems: PetshopCatalogProduct[];
        status: string;
        editorAuthor: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handlePopState;
        private handleRouteChange;
        private navigateWithinModule;
        private loadHome;
        private handleSectionClick;
        private handleEditorSubmit;
        private retryUpdateProduct;
        private saveProduct;
        private renderCatalog;
        private renderEditor;
        render(): any;
    }
}
declare module "_102030_/l2/petshop/index" { }
declare module "_102030_/l2/petshop/module.defs" {
    export const skill: {
        readonly moduleId: "petshop";
        readonly purpose: "Petshop client module with desktop and mobile page variations.";
        readonly pages: readonly ["home", "edit-products"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.petshop.currentSection", "ui.petshop.selectedCategory", "ui.petshop.searchQuery", "ui.petshop.editorAuthor"];
    };
}
declare module "_102030_/l2/petshop/module" {
    import type { AuraModuleFrontendDefinition } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.petshop.currentSection";
        readonly selectedCategory: "ui.petshop.selectedCategory";
        readonly searchQuery: "ui.petshop.searchQuery";
        readonly editorAuthor: "ui.petshop.editorAuthor";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102030_/l2/petshop/web/routes/catalog" {
    export { PetshopWebDesktopHomePage } from "_102030_/l2/petshop/web/desktop/page11/home";
}
declare module "_102030_/l2/petshop/web/routes/edit-products" {
    export { PetshopWebDesktopHomePage } from "_102030_/l2/petshop/web/desktop/page11/home";
}
declare module "_102030_/l2/petshop/web/shared/home.defs" {
    export const skill = "\n# Petshop Home Page\n\n## Purpose\n\nRender the desktop home page for the petshop module using a single aggregated\nBFF request.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `petshop.home.load`\n- The routine must return only the data the page needs:\n  - `seed`\n  - `catalog`\n  - `topProducts`\n\n## Page Behavior\n\n- Load the page with one BFF call on connect\n- Render a compact toolbar with category filters\n- Show a status line with the current page state\n- Render a \"Top products\" section\n- Render a \"Catalog\" section\n- Reload the page when the user clicks reload\n- Re-run the page load with a category filter when the user clicks a category\n\n## Important Data\n\n- Catalog item fields:\n  - `name`\n  - `category`\n  - `priceInCents`\n  - `stockStatus`\n  - `description`\n- Top product fields:\n  - `name`\n  - `category`\n  - `highlightScore`\n  - `priceInCents`\n\n## Shared Files\n\n- `web/shared/home.ts` owns the page BFF call\n- `web/shared/homeFormatters.ts` owns display formatting helpers such as\n  `formatPrice`\n\n## Layout Intent\n\n- Dense but readable business UI\n- Fast visual scan for category, stock state, and price\n- Keep the page compatible with the master shell aside/header\n- Use light DOM compatible styling\n";
}
declare module "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs" {
    export const pluginStripePagamentosPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginPlan;
}
