declare module "_102030_/l1/petShopStripe/layer_1_external/cart.defs" {
    export const cartTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "cart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "plan-table-definition:cart";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "cart";
                readonly tableName: "cart";
                readonly moduleId: "petShopStripe";
                readonly title: "Carrinho";
                readonly purpose: "Persistir o carrinho ativo do cliente para checkout.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Cart";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "cart_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do carrinho.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente dono do carrinho.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do carrinho (ativo, convertido, abandonado, expirado).";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Moeda usada para preços do carrinho.";
                }, {
                    readonly name: "items_count";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens no carrinho.";
                }, {
                    readonly name: "subtotal_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Subtotal do carrinho antes de descontos.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Desconto aplicado ao carrinho.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total do carrinho após descontos.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do carrinho.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do carrinho.";
                }, {
                    readonly name: "expires_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data de expiração do carrinho.";
                }, {
                    readonly name: "last_activity_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Última interação no carrinho.";
                }];
                readonly primaryKey: readonly ["cart_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule.persistence.excludeMdmEntities";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_cart_customer_status";
                    readonly columns: readonly ["customer_id", "status"];
                    readonly reason: "rule.index.lookupByCustomerStatus";
                }, {
                    readonly indexName: "idx_cart_updated_at";
                    readonly columns: readonly ["updated_at"];
                    readonly reason: "rule.index.sortByRecentUpdate";
                }, {
                    readonly indexName: "idx_cart_expires_at";
                    readonly columns: readonly ["expires_at"];
                    readonly reason: "rule.index.expirationCleanup";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "CartDetails";
                    readonly reason: "rule.persistence.aggregateWithChildEntities";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/cart.defs.ts";
                readonly exportName: "cartTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default cartTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "plan-table-definition:order";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "petShopStripe";
                readonly title: "Pedido";
                readonly purpose: "Registrar pedidos gerados no checkout e seu ciclo de vida.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "order_number";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Número legível do pedido para referência do cliente e admin.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente responsável pelo pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do ciclo de vida do pedido.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do pagamento associado ao pedido.";
                }, {
                    readonly name: "payment_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao pagamento horizontal.";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "BRL";
                    readonly description: "Moeda do pedido.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Valor total do pedido.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de descontos aplicados.";
                }, {
                    readonly name: "shipping_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor de entrega, quando aplicável.";
                }, {
                    readonly name: "scheduled_service_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data e hora do serviço agendado, quando aplicável.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Última atualização do pedido.";
                }, {
                    readonly name: "paid_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora da confirmação de pagamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "ruleOrderRequiresCustomer";
                }, {
                    readonly fieldName: "payment_id";
                    readonly targetEntity: "Payment";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "rulePaymentRequiredToConfirmOrder";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_customer_id_created_at";
                    readonly columns: readonly ["customer_id", "created_at"];
                    readonly unique: false;
                    readonly reason: "Busca de pedidos do cliente por período.";
                }, {
                    readonly indexName: "idx_order_status_created_at";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar pedidos por status no admin.";
                }, {
                    readonly indexName: "idx_order_paid_at";
                    readonly columns: readonly ["paid_at"];
                    readonly unique: false;
                    readonly reason: "Apuração de métricas por data de pagamento.";
                }, {
                    readonly indexName: "idx_order_scheduled_service_at";
                    readonly columns: readonly ["scheduled_service_at"];
                    readonly unique: false;
                    readonly reason: "Agenda de serviços.";
                }, {
                    readonly indexName: "idx_order_order_number";
                    readonly columns: readonly ["order_number"];
                    readonly unique: true;
                    readonly reason: "Consulta rápida por número do pedido.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderDetails";
                    readonly reason: "Armazenar itens do pedido e dados auxiliares do checkout.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["metricTableSalesOps"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "ruleOrderStatusLifecycle", "rulePaymentRequiredToConfirmOrder"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/salesOpsMetrics.defs" {
    export const salesOpsMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "salesOpsMetrics";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 53;
            readonly planId: "plan-metric-table-definition:salesOpsMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "salesOpsMetrics";
                readonly tableName: "sales_ops_metrics";
                readonly moduleId: "petShopStripe";
                readonly title: "Métricas de vendas e pagamentos";
                readonly purpose: "Agregar dados de pedidos e pagamentos para análise de receita, ticket médio, volume de pedidos e taxa de aprovação.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento agregado.";
                }, {
                    readonly name: "order_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pedido no momento do evento.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pagamento associado.";
                }, {
                    readonly name: "item_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo do item vendido (produto ou serviço).";
                }, {
                    readonly name: "order_total";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total dos pedidos.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "approved_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pagamentos aprovados.";
                }, {
                    readonly name: "canceled_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos cancelados.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderStatus";
                    readonly column: "order_status";
                    readonly type: "text";
                    readonly description: "Status do pedido no momento do evento";
                }, {
                    readonly dimensionId: "paymentStatus";
                    readonly column: "payment_status";
                    readonly type: "text";
                    readonly description: "Status do pagamento associado";
                }, {
                    readonly dimensionId: "itemType";
                    readonly column: "item_type";
                    readonly type: "text";
                    readonly description: "Tipo do item vendido (produto ou serviço)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "order_total";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total dos pedidos";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "order_total";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio dos pedidos";
                }, {
                    readonly measureId: "approvedPayments";
                    readonly column: "approved_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pagamentos aprovados";
                }, {
                    readonly measureId: "canceledOrders";
                    readonly column: "canceled_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos cancelados";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderPaid", "orderCanceled", "serviceBookingCreated", "serviceBookingConfirmed"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "90 days";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_sales_ops_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consulta temporal de métricas.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_order_status_time";
                        readonly columns: readonly ["order_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pedido e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_payment_status_time";
                        readonly columns: readonly ["payment_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pagamento e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_item_type_time";
                        readonly columns: readonly ["item_type", "event_time"];
                        readonly purpose: "Filtrar métricas por tipo de item e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseUpdateMetricsOnOrderPaid"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesOpsMetrics.defs.ts";
                readonly exportName: "salesOpsMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesOpsMetricsMetricTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/serviceBooking.defs" {
    export const serviceBookingTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "serviceBooking";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "plan-table-definition:serviceBooking";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "serviceBooking";
                readonly tableName: "service_booking";
                readonly moduleId: "petShopStripe";
                readonly title: "Agendamento de serviço";
                readonly purpose: "Controlar reservas de data e horário para serviços do pet shop.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ServiceBooking";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "service_booking_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do agendamento de serviço.";
                }, {
                    readonly name: "service_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Serviço reservado no agendamento.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente que realizou o agendamento.";
                }, {
                    readonly name: "pet_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pet associado ao serviço.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido associado ao agendamento.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do agendamento (ex.: pendente, confirmado, concluído, cancelado).";
                }, {
                    readonly name: "scheduled_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data do agendamento.";
                }, {
                    readonly name: "scheduled_start_time";
                    readonly type: "time";
                    readonly nullable: false;
                    readonly description: "Horário de início do agendamento.";
                }, {
                    readonly name: "scheduled_end_time";
                    readonly type: "time";
                    readonly nullable: true;
                    readonly description: "Horário de término previsto do agendamento.";
                }, {
                    readonly name: "timezone";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Fuso horário do agendamento.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações do cliente ou do pet shop.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do agendamento.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora da última atualização do agendamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento do agendamento.";
                }];
                readonly primaryKey: readonly ["service_booking_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_id";
                    readonly targetEntity: "Service";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Serviço agendado.";
                }, {
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Cliente responsável pelo agendamento.";
                }, {
                    readonly fieldName: "pet_id";
                    readonly targetEntity: "Pet";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Pet atendido no agendamento.";
                }, {
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular o agendamento ao pedido.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_service_booking_customer";
                    readonly columns: readonly ["customer_id", "scheduled_date"];
                    readonly reason: "Listagem de agendamentos por cliente e data.";
                }, {
                    readonly indexName: "idx_service_booking_pet";
                    readonly columns: readonly ["pet_id", "scheduled_date"];
                    readonly reason: "Consultas de agendamentos por pet.";
                }, {
                    readonly indexName: "idx_service_booking_service_date";
                    readonly columns: readonly ["service_id", "scheduled_date"];
                    readonly reason: "Consulta de agendamentos por serviço e data.";
                }, {
                    readonly indexName: "idx_service_booking_order";
                    readonly columns: readonly ["order_id"];
                    readonly reason: "Localizar agendamento pelo pedido.";
                }, {
                    readonly indexName: "idx_service_booking_status_date";
                    readonly columns: readonly ["status", "scheduled_date"];
                    readonly reason: "Filtros de status e agenda.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceBooking.defs.ts";
                readonly exportName: "serviceBookingTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceBookingTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/accountOrdersPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getOrderHistory\",\"purpose\":\"Listar pedidos do cliente com status e itens.\",\"kind\":\"query\",\"input\":{\"customerId\":\"uuid\",\"filters\":{\"orderStatus\":\"string?\",\"startDate\":\"date?\",\"endDate\":\"date?\"}},\"output\":{\"orders\":[{\"orderId\":\"uuid\",\"orderNumber\":\"string\",\"status\":\"string\",\"paymentStatus\":\"string\",\"totalAmount\":\"number\",\"createdAt\":\"datetime\",\"items\":[{\"itemType\":\"product|service\",\"itemId\":\"uuid\",\"name\":\"string\",\"quantity\":\"number\",\"unitPrice\":\"number\"}]}]},\"readsEntities\":[\"Order\",\"OrderItem\",\"Payment\"],\"writesEntities\":[],\"readsTables\":[\"order\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetOrderHistory\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]},{\"commandName\":\"getCustomerServiceBookings\",\"purpose\":\"Listar agendamentos de servi\u00E7os do cliente com status e dados do pet.\",\"kind\":\"query\",\"input\":{\"customerId\":\"uuid\",\"filters\":{\"bookingStatus\":\"string?\",\"startDate\":\"date?\",\"endDate\":\"date?\"}},\"output\":{\"bookings\":[{\"serviceBookingId\":\"uuid\",\"status\":\"string\",\"scheduledDate\":\"date\",\"scheduledStartTime\":\"time\",\"scheduledEndTime\":\"time?\",\"timezone\":\"string\",\"service\":{\"serviceId\":\"uuid\",\"name\":\"string\"},\"pet\":{\"petId\":\"uuid\",\"name\":\"string\"}}]},\"readsEntities\":[\"ServiceBooking\",\"Service\",\"Pet\"],\"writesEntities\":[],\"readsTables\":[\"serviceBooking\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetServiceBookings\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/adminCatalogPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getCatalogAdminList\",\"purpose\":\"Listar itens do cat\u00E1logo para administra\u00E7\u00E3o.\",\"kind\":\"query\",\"input\":{\"itemType\":\"string?\",\"statusFilter\":\"string[]?\",\"categoryId\":\"string?\",\"searchText\":\"string?\",\"page\":\"number?\",\"pageSize\":\"number?\"},\"output\":{\"items\":[{\"itemId\":\"string\",\"itemType\":\"string\",\"name\":\"string\",\"categoryId\":\"string?\",\"categoryName\":\"string?\",\"price\":\"number?\",\"status\":\"string\",\"updatedAt\":\"string\"}],\"pagination\":{\"page\":\"number\",\"pageSize\":\"number\",\"totalItems\":\"number\",\"totalPages\":\"number\"}},\"readsEntities\":[\"Product\",\"Service\",\"CatalogCategory\"],\"writesEntities\":[],\"readsTables\":[],\"writesTables\":[],\"usecaseRefs\":[\"usecaseManageCatalog\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]},{\"commandName\":\"manageCatalog\",\"purpose\":\"Criar, editar ou desativar itens do cat\u00E1logo.\",\"kind\":\"command\",\"input\":{\"action\":\"string\",\"itemType\":\"string\",\"itemId\":\"string?\",\"payload\":{\"name\":\"string?\",\"description\":\"string?\",\"price\":\"number?\",\"duration\":\"number?\",\"status\":\"string?\",\"categoryId\":\"string?\"}},\"output\":{\"itemId\":\"string\",\"itemType\":\"string\",\"status\":\"string\",\"updatedAt\":\"string\"},\"readsEntities\":[\"Product\",\"Service\",\"CatalogCategory\"],\"writesEntities\":[\"Product\",\"Service\",\"CatalogCategory\"],\"readsTables\":[],\"writesTables\":[],\"usecaseRefs\":[\"usecaseManageCatalog\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/adminMetricsPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getMetricsDashboard\",\"purpose\":\"Obter s\u00E9ries temporais e agrega\u00E7\u00F5es para o dashboard.\",\"kind\":\"query\",\"input\":{\"dateRange\":{\"from\":\"date\",\"to\":\"date\"},\"filters\":{\"orderStatus\":[\"string\"],\"paymentStatus\":[\"string\"],\"itemType\":[\"string\"]},\"granularity\":\"hour|day|week|month\"},\"output\":{\"series\":{\"revenue\":[{\"timestamp\":\"timestamptz\",\"value\":\"number\"}],\"orders\":[{\"timestamp\":\"timestamptz\",\"value\":\"number\"}],\"averageTicket\":[{\"timestamp\":\"timestamptz\",\"value\":\"number\"}],\"approvalRate\":[{\"timestamp\":\"timestamptz\",\"value\":\"number\"}],\"canceledOrders\":[{\"timestamp\":\"timestamptz\",\"value\":\"number\"}]},\"aggregations\":{\"totalRevenue\":\"number\",\"orderCount\":\"number\",\"averageTicket\":\"number\",\"approvedPayments\":\"number\",\"canceledOrders\":\"number\"},\"dimensions\":{\"orderStatus\":[\"string\"],\"paymentStatus\":[\"string\"],\"itemType\":[\"string\"]}},\"readsEntities\":[\"salesOpsMetricsAggregate\"],\"writesEntities\":[],\"readsTables\":[\"salesOpsMetrics\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetMetricsDashboard\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/adminOrdersPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getOrderAdminList\",\"purpose\":\"Listar pedidos por status e per\u00EDodo.\",\"kind\":\"query\",\"input\":{\"statusFilter\":\"string[]?\",\"periodStart\":\"date?\",\"periodEnd\":\"date?\",\"orderNumber\":\"string?\",\"page\":\"number?\",\"pageSize\":\"number?\"},\"output\":{\"orders\":[{\"orderId\":\"uuid\",\"orderNumber\":\"string\",\"status\":\"string\",\"paymentStatus\":\"string\",\"totalAmount\":\"number\",\"createdAt\":\"datetime\",\"updatedAt\":\"datetime\"}],\"page\":\"number\",\"pageSize\":\"number\",\"total\":\"number\"},\"readsEntities\":[\"Order\"],\"writesEntities\":[],\"readsTables\":[\"order\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetOrderAdminList\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]},{\"commandName\":\"updateOrderStatus\",\"purpose\":\"Atualizar o status do pedido conforme o ciclo de vida.\",\"kind\":\"command\",\"input\":{\"orderId\":\"uuid\",\"newStatus\":\"string\",\"statusReason\":\"string?\"},\"output\":{\"orderId\":\"uuid\",\"status\":\"string\",\"statusHistory\":[{\"fromStatus\":\"string\",\"toStatus\":\"string\",\"changedAt\":\"datetime\",\"changedBy\":\"string\"}],\"updatedAt\":\"datetime\"},\"readsEntities\":[\"Order\"],\"writesEntities\":[\"Order\"],\"readsTables\":[\"order\"],\"writesTables\":[\"order\"],\"usecaseRefs\":[\"usecaseUpdateOrderStatus\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[\"ruleOrderStatusLifecycle\"]},{\"commandName\":\"getServiceBookings\",\"purpose\":\"Listar agendamentos de servi\u00E7os para gest\u00E3o.\",\"kind\":\"query\",\"input\":{\"serviceDate\":\"date?\",\"serviceId\":\"uuid?\",\"status\":\"string?\",\"page\":\"number?\",\"pageSize\":\"number?\"},\"output\":{\"serviceBookings\":[{\"serviceBookingId\":\"uuid\",\"serviceId\":\"uuid\",\"serviceName\":\"string\",\"customerId\":\"uuid\",\"customerName\":\"string\",\"petId\":\"uuid\",\"petName\":\"string\",\"status\":\"string\",\"scheduledDate\":\"date\",\"scheduledStartTime\":\"time\",\"scheduledEndTime\":\"time\",\"orderId\":\"uuid?\"}],\"page\":\"number\",\"pageSize\":\"number\",\"total\":\"number\"},\"readsEntities\":[\"ServiceBooking\",\"Service\",\"Customer\",\"Pet\"],\"writesEntities\":[],\"readsTables\":[\"serviceBooking\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetServiceBookings\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/cartPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getCart\",\"purpose\":\"Carregar o carrinho ativo do cliente com itens e totais.\",\"kind\":\"query\",\"input\":{\"cartContext\":{\"cartId?\":\"string\"},\"include\":{\"items\":\"boolean\",\"totals\":\"boolean\"}},\"output\":{\"cart\":{\"cartId\":\"string\",\"status\":\"string\",\"currency\":\"string\",\"itemsCount\":\"number\",\"subtotalAmount\":\"number\",\"discountAmount\":\"number\",\"totalAmount\":\"number\",\"items\":[{\"itemId\":\"string\",\"productId?\":\"string\",\"serviceId?\":\"string\",\"name\":\"string\",\"quantity\":\"number\",\"unitPrice\":\"number\",\"totalPrice\":\"number\"}]}},\"readsEntities\":[\"Cart\",\"CartItem\",\"Product\",\"Service\"],\"writesEntities\":[],\"readsTables\":[\"cart\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetCart\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]},{\"commandName\":\"updateCart\",\"purpose\":\"Atualizar quantidade ou remover itens do carrinho.\",\"kind\":\"command\",\"input\":{\"cartContext\":{\"cartId?\":\"string\"},\"changes\":{\"items\":[{\"itemId?\":\"string\",\"productId?\":\"string\",\"serviceId?\":\"string\",\"quantity?\":\"number\",\"action\":\"updateQuantity|remove\"}]}},\"output\":{\"cart\":{\"cartId\":\"string\",\"status\":\"string\",\"itemsCount\":\"number\",\"subtotalAmount\":\"number\",\"discountAmount\":\"number\",\"totalAmount\":\"number\",\"items\":[{\"itemId\":\"string\",\"productId?\":\"string\",\"serviceId?\":\"string\",\"name\":\"string\",\"quantity\":\"number\",\"unitPrice\":\"number\",\"totalPrice\":\"number\"}]}} ,\"readsEntities\":[\"Cart\",\"CartItem\"],\"writesEntities\":[\"Cart\",\"CartItem\"],\"readsTables\":[\"cart\"],\"writesTables\":[\"cart\"],\"usecaseRefs\":[\"usecaseUpdateCart\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]},{\"commandName\":\"startCheckout\",\"purpose\":\"Criar pedido a partir do carrinho confirmado.\",\"kind\":\"command\",\"input\":{\"cartContext\":{\"cartId?\":\"string\"},\"deliveryContact?\":{\"phone?\":\"string\",\"email?\":\"string\"},\"deliveryAddress?\":{\"addressId?\":\"string\",\"street?\":\"string\",\"number?\":\"string\",\"city?\":\"string\",\"state?\":\"string\",\"postalCode?\":\"string\"}},\"output\":{\"order\":{\"orderId\":\"string\",\"status\":\"string\",\"paymentStatus\":\"string\",\"totalAmount\":\"number\"},\"cart\":{\"cartId\":\"string\",\"status\":\"string\"}},\"readsEntities\":[\"Cart\",\"CartItem\"],\"writesEntities\":[\"Order\",\"OrderItem\",\"Cart\"],\"readsTables\":[\"cart\"],\"writesTables\":[\"order\",\"cart\"],\"usecaseRefs\":[\"usecaseCreateOrder\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[\"ruleOrderRequiresCustomer\"]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/catalogPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getCatalogList\",\"purpose\":\"Buscar lista paginada de produtos e servi\u00E7os conforme filtros.\",\"kind\":\"query\",\"input\":{\"categoria\":{\"type\":\"string\",\"required\":false},\"tipo\":{\"type\":\"string\",\"required\":false},\"precoMin\":{\"type\":\"number\",\"required\":false},\"precoMax\":{\"type\":\"number\",\"required\":false},\"page\":{\"type\":\"number\",\"required\":false},\"pageSize\":{\"type\":\"number\",\"required\":false}},\"output\":{\"items\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"itemId\":{\"type\":\"string\"},\"itemType\":{\"type\":\"string\",\"enum\":[\"Product\",\"Service\"]},\"title\":{\"type\":\"string\"},\"summary\":{\"type\":\"string\"},\"price\":{\"type\":\"number\"},\"status\":{\"type\":\"string\"},\"categoryTitle\":{\"type\":\"string\"}}}},\"pagination\":{\"type\":\"object\",\"properties\":{\"page\":{\"type\":\"number\"},\"pageSize\":{\"type\":\"number\"},\"totalItems\":{\"type\":\"number\"}}}},\"readsEntities\":[\"Product\",\"Service\",\"CatalogCategory\"],\"writesEntities\":[],\"readsTables\":[],\"writesTables\":[],\"usecaseRefs\":[],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/checkoutPage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getCheckoutCartSummary\",\"purpose\":\"Carregar resumo do carrinho confirmado para exibi\u00E7\u00E3o no checkout.\",\"kind\":\"query\",\"input\":{\"cartId\":\"string\"},\"output\":{\"cartId\":\"string\",\"items\":[{\"itemId\":\"string\",\"itemType\":\"product|service\",\"productId\":\"string?\",\"serviceId\":\"string?\",\"name\":\"string\",\"quantity\":\"number\",\"unitPrice\":\"number\",\"totalPrice\":\"number\"}],\"totals\":{\"subtotal\":\"number\",\"discount\":\"number\",\"shipping\":\"number\",\"total\":\"number\"},\"currency\":\"string\"},\"readsEntities\":[\"Cart\",\"CartItem\",\"Product\",\"Service\"],\"writesEntities\":[],\"readsTables\":[\"cart\"],\"writesTables\":[],\"usecaseRefs\":[\"usecaseGetCart\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]},{\"commandName\":\"createOrderFromCheckout\",\"purpose\":\"Criar pedido com base no carrinho e dados de entrega/contato do cliente.\",\"kind\":\"command\",\"input\":{\"cartId\":\"string\",\"deliveryAddress\":{\"street\":\"string\",\"number\":\"string\",\"complement\":\"string?\",\"district\":\"string\",\"city\":\"string\",\"state\":\"string\",\"postalCode\":\"string\",\"country\":\"string\"},\"contact\":{\"name\":\"string\",\"email\":\"string\",\"phone\":\"string\"}},\"output\":{\"orderId\":\"string\",\"orderNumber\":\"string\",\"status\":\"string\",\"paymentStatus\":\"string\",\"orderSummary\":{\"items\":[{\"itemId\":\"string\",\"itemType\":\"product|service\",\"name\":\"string\",\"quantity\":\"number\",\"unitPrice\":\"number\",\"totalPrice\":\"number\"}],\"totals\":{\"subtotal\":\"number\",\"discount\":\"number\",\"shipping\":\"number\",\"total\":\"number\"},\"currency\":\"string\"}},\"readsEntities\":[\"Cart\",\"Customer\",\"Address\"],\"writesEntities\":[\"Order\",\"OrderItem\",\"Cart\"],\"readsTables\":[\"cart\"],\"writesTables\":[\"order\",\"cart\"],\"usecaseRefs\":[\"usecaseCreateOrder\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[\"ruleOrderRequiresCustomer\"]},{\"commandName\":\"confirmStripePayment\",\"purpose\":\"Confirmar pagamento via Stripe e atualizar status do pedido.\",\"kind\":\"command\",\"input\":{\"orderId\":\"string\",\"paymentIntentId\":\"string\",\"paymentMethod\":\"string\",\"confirmationData\":{\"clientSecret\":\"string?\",\"returnUrl\":\"string?\"}},\"output\":{\"paymentStatus\":\"string\",\"orderStatus\":\"string\",\"confirmation\":{\"orderId\":\"string\",\"receiptUrl\":\"string?\",\"paidAt\":\"string\"}},\"readsEntities\":[\"Order\",\"Payment\",\"StripeTransaction\"],\"writesEntities\":[\"Payment\",\"StripeTransaction\",\"Order\"],\"readsTables\":[\"order\"],\"writesTables\":[\"order\",\"salesOpsMetrics\"],\"usecaseRefs\":[\"usecaseConfirmStripePayment\"],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[\"rulePaymentRequiredToConfirmOrder\",\"ruleStripeTransactionLink\",\"ruleMetricsUpdateOnOrderPaid\"]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_2_controllers/homePage.defs" {
    export const skill = "\n## Pages spec\n```JSON\n[{\"commandName\":\"getCatalogHighlights\",\"purpose\":\"Carregar categorias, produtos e servi\u00E7os em destaque para a vitrine.\",\"kind\":\"query\",\"input\":{\"highlightLimits\":{\"type\":\"object\",\"required\":false,\"fields\":{\"categories\":{\"type\":\"number\"},\"products\":{\"type\":\"number\"},\"services\":{\"type\":\"number\"}}},\"filters\":{\"type\":\"object\",\"required\":false,\"fields\":{\"categoryIds\":{\"type\":\"string[]\"},\"availabilityStatus\":{\"type\":\"string\"},\"priceRange\":{\"type\":\"object\",\"fields\":{\"min\":{\"type\":\"number\"},\"max\":{\"type\":\"number\"}}}}}},\"output\":{\"categories\":{\"type\":\"array\",\"items\":{\"categoryId\":\"string\",\"name\":\"string\",\"imageUrl\":\"string\"}},\"items\":{\"type\":\"array\",\"items\":{\"itemType\":\"string\",\"itemId\":\"string\",\"name\":\"string\",\"price\":{\"amount\":\"number\",\"currency\":\"string\"},\"availabilityStatus\":\"string\",\"categoryIds\":\"string[]\",\"imageUrl\":\"string\"}}},\"readsEntities\":[\"CatalogCategory\",\"Product\",\"Service\"],\"writesEntities\":[],\"readsTables\":[],\"writesTables\":[],\"usecaseRefs\":[],\"layerContract\":{\"controllerLayer\":\"layer_2_controllers\",\"mustCallLayer\":\"layer_3_usecases\",\"directTableAccessForbidden\":true},\"rulesApplied\":[]}]\n```\n";
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseAddToCart.defs" {
    export const usecaseAddToCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseAddToCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseAddToCart";
                readonly title: "Adicionar item ao carrinho";
                readonly purpose: "Adicionar produto ou serviço ao carrinho do cliente e recalcular totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["addToCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseAddToCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseConfirmStripePayment.defs" {
    export const usecaseConfirmStripePaymentUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseConfirmStripePayment";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseConfirmStripePayment";
                readonly title: "Confirmar pagamento Stripe";
                readonly purpose: "Atualizar status do pedido após confirmação de pagamento e registrar métricas.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "salesOpsMetrics"];
                readonly commands: readonly ["confirmStripePayment"];
                readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseConfirmStripePaymentUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseCreateOrder.defs" {
    export const usecaseCreateOrderUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseCreateOrder";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseCreateOrder";
                readonly title: "Criar pedido";
                readonly purpose: "Gerar pedido a partir do carrinho confirmado e marcar carrinho como convertido.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["order", "cart"];
                readonly commands: readonly ["startCheckout"];
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            };
        };
    };
    export default usecaseCreateOrderUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetCart.defs" {
    export const usecaseGetCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetCart";
                readonly title: "Consultar carrinho";
                readonly purpose: "Carregar o carrinho ativo do cliente com itens e totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetMetricsDashboard.defs" {
    export const usecaseGetMetricsDashboardUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetMetricsDashboard";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetMetricsDashboard";
                readonly title: "Consultar métricas de vendas";
                readonly purpose: "Obter séries temporais de métricas de vendas e pagamentos para dashboard.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetMetricsDashboardUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderAdminList.defs" {
    export const usecaseGetOrderAdminListUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderAdminList";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderAdminList";
                readonly title: "Listar pedidos administrativos";
                readonly purpose: "Listar pedidos por status e período para gestão administrativa.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderAdminListUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderHistory.defs" {
    export const usecaseGetOrderHistoryUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderHistory";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderHistory";
                readonly title: "Listar pedidos do cliente";
                readonly purpose: "Listar pedidos do cliente para acompanhamento de histórico.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderHistoryUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetServiceBookings.defs" {
    export const usecaseGetServiceBookingsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetServiceBookings";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetServiceBookings";
                readonly title: "Listar agendamentos";
                readonly purpose: "Consultar agendamentos por cliente, pet ou serviço.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate"];
                readonly readsTables: readonly ["serviceBooking"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetServiceBookingsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseManageCatalog.defs" {
    export const usecaseManageCatalogUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseManageCatalog";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseManageCatalog";
                readonly title: "Gerenciar catálogo";
                readonly purpose: "Cadastrar, editar ou desativar produtos e serviços, preços e disponibilidade.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["catalogAggregate"];
                readonly outputEntities: readonly ["catalogAggregate"];
                readonly readsTables: readonly ["product", "service", "catalogCategory"];
                readonly writesTables: readonly ["product", "service", "catalogCategory"];
                readonly commands: readonly ["manageCatalog"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseManageCatalogUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseReconcilePayments.defs" {
    export const usecaseReconcilePaymentsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseReconcilePayments";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseReconcilePayments";
                readonly title: "Conciliar recebíveis";
                readonly purpose: "Registrar conciliação de pagamentos aprovados e lançar recebíveis.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["receivableAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["receivableAggregate"];
                readonly readsTables: readonly ["order", "payment", "stripeTransaction"];
                readonly writesTables: readonly ["receivable", "financialEntry"];
                readonly commands: readonly ["reconcilePayments"];
                readonly rulesApplied: readonly ["ruleReceivableFromPayment"];
            };
        };
    };
    export default usecaseReconcilePaymentsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseScheduleService.defs" {
    export const usecaseScheduleServiceUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseScheduleService";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseScheduleService";
                readonly title: "Agendar serviço";
                readonly purpose: "Criar agendamento de serviço e vincular ao pedido quando aplicável.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["serviceBooking", "order"];
                readonly commands: readonly ["scheduleService"];
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
        };
    };
    export default usecaseScheduleServiceUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateCart.defs" {
    export const usecaseUpdateCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateCart";
                readonly title: "Atualizar carrinho";
                readonly purpose: "Alterar quantidades ou remover itens do carrinho e atualizar totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["updateCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseUpdateCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateMetricsOnOrderPaid.defs" {
    export const usecaseUpdateMetricsOnOrderPaidUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateMetricsOnOrderPaid";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateMetricsOnOrderPaid";
                readonly title: "Atualizar métricas de vendas";
                readonly purpose: "Atualizar métricas operacionais quando pedidos são pagos ou cancelados.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["salesOpsMetrics"];
                readonly commands: readonly [];
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseUpdateMetricsOnOrderPaidUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateOrderStatus.defs" {
    export const usecaseUpdateOrderStatusUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateOrderStatus";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateOrderStatus";
                readonly title: "Atualizar status do pedido";
                readonly purpose: "Alterar status do pedido conforme ciclo de vida.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly commands: readonly ["updateOrderStatus"];
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
            };
        };
    };
    export default usecaseUpdateOrderStatusUsecasePlan;
}
declare module "_102030_/l1/petshop/module" {
    export interface PetshopCatalogProduct {
        productId: string;
        name: string;
        category: string;
        priceInCents: number;
        currency: 'BRL';
        highlightScore: number;
        stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
        description: string;
        updatedAt: string;
    }
    export interface PetshopSeedResult {
        insertedCount: number;
        totalCount: number;
        seededAt: string;
    }
    export interface PetshopHomeLoadParams {
        category?: string;
        query?: string;
        topLimit?: number;
        forceSeed?: boolean;
    }
    export interface PetshopHomeLoadResult {
        seed: PetshopSeedResult;
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
    export interface PetshopUpdateProductParams {
        productId: string;
        author?: string;
        name?: string;
        category?: string;
        priceInCents?: number;
        highlightScore?: number;
        stockStatus?: PetshopCatalogProduct['stockStatus'];
        description?: string;
    }
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
    }
    export function readAppEnv(): AppEnv;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        dynamoResolvedTableName: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102030_/l1/petshop/persistence" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const tableDefinitions: TableDefinition[];
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls mdm.promoteProspect(prospectMdmId)
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        createdAt: string;
        updatedAt: string;
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getSharedPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: Array<{
            id: string;
            label: string;
            href: string;
            description?: string;
        }>;
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        backendRouter?: string;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function getPublicationTarget(targetName?: string): {
        assetBaseUrl: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
        name: string;
    };
    export function resolvePublicationDistPath(targetName: string, relativePath?: string): string;
    export function resolveActivePublicationDistPath(relativePath?: string): string;
    export function toPublishedAssetUrl(relativePath: string, targetName?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
    }
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord } from "_102034_/l1/mdm/module";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentRecord;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            userId?: string;
            authToken?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestContext {
        data: IDataRuntime;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        requestMeta?: {
            requestId?: string;
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102030_/l2/petshop/shared/mock/products" {
    import type { PetshopCatalogProduct } from "_102030_/l1/petshop/module";
    export function buildPetshopMockProducts(): PetshopCatalogProduct[];
}
declare module "_102030_/l2/petshop/shared/mock/adminMock" {
    export function getPetshopMockProducts(): import("_102030_/l1/petshop/module").PetshopCatalogProduct[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from "_102034_/l1/mdm/module";
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102030_/l1/petshop/layer_3_usecases/catalogUsecases" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult, PetshopSeedResult, PetshopUpdateProductParams } from "_102030_/l1/petshop/module";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function resetPetshopCatalogForTests(): void;
    export function seedPetshopMockData(ctx: RequestContext, force?: boolean): Promise<PetshopSeedResult>;
    export function listPetshopCatalog(ctx: RequestContext, input?: {
        category?: string;
        query?: string;
    }): Promise<PetshopCatalogProduct[]>;
    export function getPetshopTopProducts(ctx: RequestContext, limit?: number): Promise<PetshopCatalogProduct[]>;
    export function loadPetshopHome(ctx: RequestContext, input?: PetshopHomeLoadParams): Promise<PetshopHomeLoadResult>;
    export function updatePetshopProduct(ctx: RequestContext, input: PetshopUpdateProductParams): Promise<PetshopCatalogProduct>;
}
declare module "_102030_/l1/petshop/layer_2_controllers/catalogHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const petshopListCatalogHandler: BffHandler;
    export const petshopGetTopProductsHandler: BffHandler;
    export const petshopSeedMockDataHandler: BffHandler;
    export const petshopHomeLoadHandler: BffHandler;
    export const petshopUpdateProductHandler: BffHandler;
}
declare module "_102029_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102034_/l1/server/layer_1_external/observability/ConsoleLogger" {
    import type { ILogger } from "_102034_/l1/server/layer_2_controllers/contracts";
    export class ConsoleLogger implements ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/moduleRegistry" {
    import { type BffHandler, type ModuleBffRegistration, type RoutineResolution } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function getModuleBffRegistrations(): ModuleBffRegistration[];
    export function resolveRoutineResolution(routine: string): RoutineResolution;
    export function loadModuleRouter(registration: ModuleBffRegistration): Promise<Map<string, BffHandler>>;
    export function resetModuleRouterCache(): void;
}
declare module "_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function createMemoryDataRuntime(): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/pg" {
    export { getSharedPgPool, queryRows, withPgTransaction, } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
}
declare module "_102034_/l1/mdm/tableNames" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getMdmTableNames(appEnv: AppEnv['appEnv']): {
        documents: string;
        documentsEntitiesIndex: string;
        documentsProspectsIndex: string;
        kv: string;
        relationship: string;
        prospectRelationship: string;
        auditLog: string;
        tag: string;
        comment: string;
        attachment: string;
        numberSequence: string;
        outbox: string;
        replicationFailures: string;
        monitoringWrite: string;
        errorLog: string;
        statusHistory: string;
    };
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/MdmDataRuntimePostgres" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function createPostgresDataRuntime(env: AppEnv): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/runtimeFactory" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function getSharedDataRuntime(): IDataRuntime;
    export function resetSharedDataRuntime(): void;
}
declare module "_102034_/l1/monitor/module" {
    export type MonitorStatusGroup = 'success' | 'client_error' | 'server_error' | 'not_found';
    export interface MonitorBffExecutionLogRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
    /** Continuous aggregate — no id or updatedAt, maintained by TimescaleDB. */
    export interface MonitorBffExecutionAggregateMinuteRecord {
        bucketStart: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        totalCount: number;
        successCount: number;
        clientErrorCount: number;
        serverErrorCount: number;
        notFoundCount: number;
        totalDurationMs: number;
    }
    export interface MonitorClientTelemetryEventRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        module: string;
        routine: string;
        eventType: string;
        label?: string | null;
        durationMs?: number | null;
        metadata?: unknown;
        recordedAt: string;
        receivedAt: string;
    }
    export interface MonitorSeriesPoint {
        timestamp: string;
        total: number;
        success: number;
        clientError: number;
        serverError: number;
        notFound: number;
    }
    export interface MonitorExecutionEvent {
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/persistence/MonitorPersistenceMetadata" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export interface MonitorTableMetadata {
        projectId: string;
        moduleId: string;
        repositoryName: string;
        tableName: string;
        description: string;
        purpose: string;
        storageProfile: string;
        backupHot: boolean;
        writeMode: string;
        dynamoTableName: string | null;
        dynamoPartitionKey: string | null;
        dynamoSortKey: string | null;
        dynamoTtlField: string | null;
        localIndexes: Array<{
            name: string;
            unique: boolean;
            columns: string[];
        }>;
        detailsInDynamoOnly: boolean;
    }
    export class MonitorPersistenceMetadata {
        private readonly env;
        constructor(env: AppEnv);
        listAll(): Promise<MonitorTableMetadata[]>;
        listPostgresTables(): Promise<import("_102034_/l1/server/layer_1_external/persistence/contracts").ResolvedTableDefinition[]>;
        listDynamoTables(): Promise<import("_102034_/l1/server/layer_1_external/persistence/contracts").ResolvedTableDefinition[]>;
        findByPostgresTableName(tableName: string): Promise<MonitorTableMetadata | null>;
        findByDynamoTableName(tableName: string): Promise<MonitorTableMetadata | null>;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/postgres/MonitorRuntimePostgres" {
    import { type AttributeValue } from '@aws-sdk/client-dynamodb';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MonitorBffExecutionLogRecord, MonitorExecutionEvent } from "_102034_/l1/monitor/module";
    type MonitorPostgresColumn = {
        name: string;
        dataType: string;
        isNullable: boolean;
        defaultValue: string | null;
    };
    type MonitorPostgresIndex = {
        name: string;
        unique: boolean;
        method: string;
        columns: string[];
    };
    type MonitorDynamoKey = Record<string, AttributeValue>;
    export function normalizeStringList(value: unknown): string[];
    export function isSafeMonitorIdentifier(value: string): boolean;
    export function normalizeInspectFilters(input: unknown): Record<string, string>;
    export function normalizeDynamoKey(key: MonitorDynamoKey | undefined): string | null;
    export function decodeDynamoKey(cursor?: string | null): MonitorDynamoKey | undefined;
    export function parseRoutineParts(routine: string): {
        module: string;
        pageName: string;
        command: string;
    };
    export function getStatusGroup(statusCode: number): "success" | "client_error" | "server_error" | "not_found";
    export class MonitorRuntimePostgres {
        private readonly env;
        private readonly metadata;
        constructor(env?: AppEnv);
        recordExecution(event: MonitorExecutionEvent): Promise<void>;
        static isMissingMonitorStorageError(error: unknown): boolean;
        listKnownPostgresTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
        }>>;
        private listAvailableDatabases;
        private getKnownPostgresTableNames;
        private getKnownDynamoTableNames;
        private getTableNameByRepositoryName;
        private assertKnownPostgresTable;
        private assertKnownDynamoTable;
        private getPoolForDatabase;
        private listPostgresColumns;
        private getPostgresPrimaryKey;
        private listPostgresIndexes;
        private getPostgresTableMetrics;
        listKnownPostgresTablesDetailed(databaseName?: string): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
            totalSizeBytes: number | null;
        }>>;
        getPostgresTableDetails(input: {
            databaseName?: string;
            tableName: string;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            metrics: {
                rowCount: number;
                totalSizeBytes: number;
            };
            columns: MonitorPostgresColumn[];
            primaryKey: string[];
            indexes: MonitorPostgresIndex[];
        }>;
        inspectPostgresTable(input: {
            databaseName?: string;
            tableName: string;
            page?: number;
            filters?: unknown;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<Pick<MonitorPostgresColumn, 'name' | 'dataType' | 'isNullable'>>;
            pagination: {
                page: number;
                pageSize: number;
                totalRows: number;
                totalPages: number;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            order: {
                primary: string[];
                fallback: string;
            };
        }>;
        listKnownDynamoTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            itemCount: number | null;
            tableStatus: string | null;
            tableSizeBytes: number | null;
            metricsAreApproximate: boolean;
        }>>;
        getPostgresSnapshot(input?: {
            databaseName?: string;
        }): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            connection: {
                host: string;
                port: number;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                activeConnectionsByState: Record<string, number>;
                maxConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        }>;
        getDynamoSnapshot(): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            region: string;
            tables: Array<{
                tableName: string;
                description: string | null;
                moduleId: string | null;
                repositoryName: string | null;
                storageProfile: string | null;
                backupHot: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        }>;
        getDynamoTableDetails(input: {
            tableName: string;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            summary: {
                tableStatus: string | null;
                itemCount: number;
                tableSizeBytes: number;
                billingMode: string | null;
                tableClass: string | null;
                metricsAreApproximate: boolean;
            };
            keys: {
                partitionKey: string | null;
                sortKey: string | null;
            };
            attributeDefinitions: Array<{
                name: string;
                type: string;
            }>;
            globalSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
            localSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
        }>;
        inspectDynamoTable(input: {
            tableName: string;
            cursor?: string;
            filters?: unknown;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<{
                name: string;
                type: string;
                filterable: boolean;
            }>;
            pagination: {
                pageSize: number;
                cursor: string | null;
                nextCursor: string | null;
                hasNextPage: boolean;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            metricsAreApproximate: boolean;
        }>;
        getSnapshotData(): Promise<{
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<Pick<MonitorBffExecutionLogRecord, 'routine' | 'statusCode' | 'statusGroup' | 'errorCode' | 'finishedAt'>>;
        }>;
        recordTelemetry(events: Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            module: string;
            routine: string;
            eventType: string;
            label: string;
            durationMs: number | null;
            metadata: Record<string, unknown> | null;
            recordedAt: string;
            receivedAt: string;
        }>): Promise<void>;
        loadRequestTrace(input: {
            requestId?: string;
            traceId?: string;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            ok: boolean;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
        loadAbends(input: {
            module?: string;
            limit?: number;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/cache/BffExecutionSeriesStore" {
    import type { MonitorExecutionEvent, MonitorSeriesPoint } from "_102034_/l1/monitor/module";
    export class BffExecutionSeriesStore {
        private readonly maxWindowSeconds;
        private readonly buckets;
        constructor(maxWindowSeconds?: number);
        record(event: MonitorExecutionEvent): void;
        getSeries(input?: {
            windowSeconds?: number;
            routine?: string;
            source?: 'http' | 'message' | 'test';
        }): MonitorSeriesPoint[];
        reset(): void;
        private trim;
        private listRecentTimestamps;
        private incrementDetailPoint;
    }
    export function getSharedBffExecutionSeriesStore(): BffExecutionSeriesStore;
    export function resetSharedBffExecutionSeriesStore(): void;
}
declare module "_102034_/l1/monitor/layer_4_entities/MonitorExecutionEntity" {
    import type { MonitorExecutionEvent } from "_102034_/l1/monitor/module";
    export class MonitorExecutionEntity {
        static record(event: MonitorExecutionEvent): Promise<void>;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/execBff" {
    import { type BffRequest, type BffResponse, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createRequestContext(dataRuntime?: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): RequestContext;
    export function createDefaultRequestContext(): RequestContext;
    export function execBff(request: BffRequest, ctx?: RequestContext): Promise<{
        response: BffResponse;
        statusCode: number;
    }>;
}
declare module "_102030_/l1/petshop/layer_2_controllers/router.test" { }
declare module "_102030_/l1/petshop/layer_2_controllers/router" {
    import type { BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createPetshopRouter(): Map<string, BffHandler>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102030_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102030_/l2/project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
        layouts: {
            1: {
                name: string;
                skill: string;
            };
        };
        designSystems: {
            1: {
                name: string;
                skill: string;
            };
        };
    };
}
declare module "_102030_/l2/petShopStripe/accountOrdersPage.defs" {
    export const accountOrdersPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: string[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    customerId: string;
                    filters: {
                        orderStatus: string;
                        startDate: string;
                        endDate: string;
                        bookingStatus?: undefined;
                    };
                };
                output: {
                    orders: {
                        orderId: string;
                        orderNumber: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                        createdAt: string;
                        items: {
                            itemType: string;
                            itemId: string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                        }[];
                    }[];
                    bookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    customerId: string;
                    filters: {
                        bookingStatus: string;
                        startDate: string;
                        endDate: string;
                        orderStatus?: undefined;
                    };
                };
                output: {
                    bookings: {
                        serviceBookingId: string;
                        status: string;
                        scheduledDate: string;
                        scheduledStartTime: string;
                        scheduledEndTime: string;
                        timezone: string;
                        service: {
                            serviceId: string;
                            name: string;
                        };
                        pet: {
                            petId: string;
                            name: string;
                        };
                    }[];
                    orders?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/adminCatalogPage.defs" {
    export const adminCatalogPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    itemType: string;
                    statusFilter: string;
                    categoryId: string;
                    searchText: string;
                    page: string;
                    pageSize: string;
                    action?: undefined;
                    itemId?: undefined;
                    payload?: undefined;
                };
                output: {
                    items: {
                        itemId: string;
                        itemType: string;
                        name: string;
                        categoryId: string;
                        categoryName: string;
                        price: string;
                        status: string;
                        updatedAt: string;
                    }[];
                    pagination: {
                        page: string;
                        pageSize: string;
                        totalItems: string;
                        totalPages: string;
                    };
                    itemId?: undefined;
                    itemType?: undefined;
                    status?: undefined;
                    updatedAt?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    action: string;
                    itemType: string;
                    itemId: string;
                    payload: {
                        name: string;
                        description: string;
                        price: string;
                        duration: string;
                        status: string;
                        categoryId: string;
                    };
                    statusFilter?: undefined;
                    categoryId?: undefined;
                    searchText?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                };
                output: {
                    itemId: string;
                    itemType: string;
                    status: string;
                    updatedAt: string;
                    items?: undefined;
                    pagination?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/adminDashboardPage.defs" {
    export const adminDashboardPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminDashboardPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 90;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminDashboardPage";
                readonly pageName: "Dashboard administrativo";
                readonly actor: "adminPetShop";
                readonly purpose: "Fornecer visão geral de pedidos, agenda e indicadores rápidos.";
                readonly capabilities: readonly ["manageOrdersServices", "financialOverview", "metricsDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycleManagement"];
                    readonly taskWorkflows: readonly ["serviceBooking", "paymentReconciliation"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["organization"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Intervalo de datas para filtrar KPIs, pedidos e agenda.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminOrdersPage";
                    readonly trigger: "Gerenciar pedidos";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminFinancialPage";
                    readonly trigger: "Ver financeiro";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminMetricsPage";
                    readonly trigger: "Ver métricas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo operacional";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "kpiSummaryCards";
                        readonly purpose: "Exibir KPIs de pedidos e agenda no período.";
                        readonly userActions: readonly ["Ver resumo operacional"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.status", "ServiceBooking.scheduled_date"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "operationalQueues";
                        readonly purpose: "Mostrar filas de pedidos por status e próximos agendamentos.";
                        readonly userActions: readonly ["Ver resumo operacional", "Acessar gestão de pedidos"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.order_number", "Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.service_id", "ServiceBooking.status", "ServiceBooking.scheduled_date", "ServiceBooking.scheduled_start_time"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Indicadores rápidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsSummaryWidget";
                        readonly purpose: "Apresentar resumo das métricas de vendas e pagamentos.";
                        readonly userActions: readonly ["Acessar métricas"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["salesOpsMetrics.totalRevenue", "salesOpsMetrics.orderCount", "salesOpsMetrics.approvedPayments", "salesOpsMetrics.canceledOrders"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAdminOverview";
                readonly purpose: "Carregar KPIs resumidos e filas operacionais.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly orderCountsByStatus: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly paymentStatusCounts: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly recentOrders: readonly [{
                        readonly orderId: "string";
                        readonly orderNumber: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                        readonly createdAt: "string";
                    }];
                    readonly upcomingBookings: readonly [{
                        readonly serviceBookingId: "string";
                        readonly serviceId: "string";
                        readonly status: "string";
                        readonly scheduledDate: "string";
                        readonly scheduledStartTime: "string";
                    }];
                };
                readonly readsEntities: readonly ["Order", "ServiceBooking"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "serviceBooking"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetOrderAdminList", "usecaseGetServiceBookings"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getMetricsSummary";
                readonly purpose: "Obter resumo das métricas de vendas para o painel.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly totalRevenue: "number";
                    readonly orderCount: "number";
                    readonly approvedPayments: "number";
                    readonly canceledOrders: "number";
                    readonly averageTicket: "number";
                };
                readonly readsEntities: readonly ["salesOpsMetrics"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetMetricsDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminDashboardPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminMetricsPage.defs" {
    export const adminMetricsPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    dateRange: {
                        from: string;
                        to: string;
                    };
                    filters: {
                        orderStatus: string[];
                        paymentStatus: string[];
                        itemType: string[];
                    };
                    granularity: string;
                };
                output: {
                    series: {
                        revenue: {
                            timestamp: string;
                            value: string;
                        }[];
                        orders: {
                            timestamp: string;
                            value: string;
                        }[];
                        averageTicket: {
                            timestamp: string;
                            value: string;
                        }[];
                        approvalRate: {
                            timestamp: string;
                            value: string;
                        }[];
                        canceledOrders: {
                            timestamp: string;
                            value: string;
                        }[];
                    };
                    aggregations: {
                        totalRevenue: string;
                        orderCount: string;
                        averageTicket: string;
                        approvedPayments: string;
                        canceledOrders: string;
                    };
                    dimensions: {
                        orderStatus: string[];
                        paymentStatus: string[];
                        itemType: string[];
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/adminOrdersPage.defs" {
    export const adminOrdersPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: string[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: ({
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef?: undefined;
                    fieldRef?: undefined;
                } | {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                })[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    statusFilter: string;
                    periodStart: string;
                    periodEnd: string;
                    orderNumber: string;
                    page: string;
                    pageSize: string;
                    orderId?: undefined;
                    newStatus?: undefined;
                    statusReason?: undefined;
                    serviceDate?: undefined;
                    serviceId?: undefined;
                    status?: undefined;
                };
                output: {
                    orders: {
                        orderId: string;
                        orderNumber: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                        createdAt: string;
                        updatedAt: string;
                    }[];
                    page: string;
                    pageSize: string;
                    total: string;
                    orderId?: undefined;
                    status?: undefined;
                    statusHistory?: undefined;
                    updatedAt?: undefined;
                    serviceBookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    orderId: string;
                    newStatus: string;
                    statusReason: string;
                    statusFilter?: undefined;
                    periodStart?: undefined;
                    periodEnd?: undefined;
                    orderNumber?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                    serviceDate?: undefined;
                    serviceId?: undefined;
                    status?: undefined;
                };
                output: {
                    orderId: string;
                    status: string;
                    statusHistory: {
                        fromStatus: string;
                        toStatus: string;
                        changedAt: string;
                        changedBy: string;
                    }[];
                    updatedAt: string;
                    orders?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                    total?: undefined;
                    serviceBookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    serviceDate: string;
                    serviceId: string;
                    status: string;
                    page: string;
                    pageSize: string;
                    statusFilter?: undefined;
                    periodStart?: undefined;
                    periodEnd?: undefined;
                    orderNumber?: undefined;
                    orderId?: undefined;
                    newStatus?: undefined;
                    statusReason?: undefined;
                };
                output: {
                    serviceBookings: {
                        serviceBookingId: string;
                        serviceId: string;
                        serviceName: string;
                        customerId: string;
                        customerName: string;
                        petId: string;
                        petName: string;
                        status: string;
                        scheduledDate: string;
                        scheduledStartTime: string;
                        scheduledEndTime: string;
                        orderId: string;
                    }[];
                    page: string;
                    pageSize: string;
                    total: string;
                    orders?: undefined;
                    orderId?: undefined;
                    status?: undefined;
                    statusHistory?: undefined;
                    updatedAt?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/cartPage.defs" {
    export const cartPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: any[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    include: {
                        items: string;
                        totals: string;
                    };
                    changes?: undefined;
                    "deliveryContact?"?: undefined;
                    "deliveryAddress?"?: undefined;
                };
                output: {
                    cart: {
                        cartId: string;
                        status: string;
                        currency: string;
                        itemsCount: string;
                        subtotalAmount: string;
                        discountAmount: string;
                        totalAmount: string;
                        items: {
                            itemId: string;
                            "productId?": string;
                            "serviceId?": string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                    };
                    order?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    changes: {
                        items: {
                            "itemId?": string;
                            "productId?": string;
                            "serviceId?": string;
                            "quantity?": string;
                            action: string;
                        }[];
                    };
                    include?: undefined;
                    "deliveryContact?"?: undefined;
                    "deliveryAddress?"?: undefined;
                };
                output: {
                    cart: {
                        cartId: string;
                        status: string;
                        itemsCount: string;
                        subtotalAmount: string;
                        discountAmount: string;
                        totalAmount: string;
                        items: {
                            itemId: string;
                            "productId?": string;
                            "serviceId?": string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                        currency?: undefined;
                    };
                    order?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    "deliveryContact?": {
                        "phone?": string;
                        "email?": string;
                    };
                    "deliveryAddress?": {
                        "addressId?": string;
                        "street?": string;
                        "number?": string;
                        "city?": string;
                        "state?": string;
                        "postalCode?": string;
                    };
                    include?: undefined;
                    changes?: undefined;
                };
                output: {
                    order: {
                        orderId: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                    };
                    cart: {
                        cartId: string;
                        status: string;
                        currency?: undefined;
                        itemsCount?: undefined;
                        subtotalAmount?: undefined;
                        discountAmount?: undefined;
                        totalAmount?: undefined;
                        items?: undefined;
                    };
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            })[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/catalogPage.defs" {
    export const catalogPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: ({
                    name: string;
                    type: string;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                } | {
                    name: string;
                    type: string;
                    sources: string[];
                    description: string;
                    entityRef?: undefined;
                    fieldRef?: undefined;
                })[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    categoria: {
                        type: string;
                        required: boolean;
                    };
                    tipo: {
                        type: string;
                        required: boolean;
                    };
                    precoMin: {
                        type: string;
                        required: boolean;
                    };
                    precoMax: {
                        type: string;
                        required: boolean;
                    };
                    page: {
                        type: string;
                        required: boolean;
                    };
                    pageSize: {
                        type: string;
                        required: boolean;
                    };
                };
                output: {
                    items: {
                        type: string;
                        items: {
                            type: string;
                            properties: {
                                itemId: {
                                    type: string;
                                };
                                itemType: {
                                    type: string;
                                    enum: string[];
                                };
                                title: {
                                    type: string;
                                };
                                summary: {
                                    type: string;
                                };
                                price: {
                                    type: string;
                                };
                                status: {
                                    type: string;
                                };
                                categoryTitle: {
                                    type: string;
                                };
                            };
                        };
                    };
                    pagination: {
                        type: string;
                        properties: {
                            page: {
                                type: string;
                            };
                            pageSize: {
                                type: string;
                            };
                            totalItems: {
                                type: string;
                            };
                        };
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: any[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/checkoutPage.defs" {
    export const checkoutPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: string[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                }[];
                navigationRefs: ({
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description?: undefined;
                } | {
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description: string;
                })[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartId: string;
                    deliveryAddress?: undefined;
                    contact?: undefined;
                    orderId?: undefined;
                    paymentIntentId?: undefined;
                    paymentMethod?: undefined;
                    confirmationData?: undefined;
                };
                output: {
                    cartId: string;
                    items: {
                        itemId: string;
                        itemType: string;
                        productId: string;
                        serviceId: string;
                        name: string;
                        quantity: string;
                        unitPrice: string;
                        totalPrice: string;
                    }[];
                    totals: {
                        subtotal: string;
                        discount: string;
                        shipping: string;
                        total: string;
                    };
                    currency: string;
                    orderId?: undefined;
                    orderNumber?: undefined;
                    status?: undefined;
                    paymentStatus?: undefined;
                    orderSummary?: undefined;
                    orderStatus?: undefined;
                    confirmation?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartId: string;
                    deliveryAddress: {
                        street: string;
                        number: string;
                        complement: string;
                        district: string;
                        city: string;
                        state: string;
                        postalCode: string;
                        country: string;
                    };
                    contact: {
                        name: string;
                        email: string;
                        phone: string;
                    };
                    orderId?: undefined;
                    paymentIntentId?: undefined;
                    paymentMethod?: undefined;
                    confirmationData?: undefined;
                };
                output: {
                    orderId: string;
                    orderNumber: string;
                    status: string;
                    paymentStatus: string;
                    orderSummary: {
                        items: {
                            itemId: string;
                            itemType: string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                        totals: {
                            subtotal: string;
                            discount: string;
                            shipping: string;
                            total: string;
                        };
                        currency: string;
                    };
                    cartId?: undefined;
                    items?: undefined;
                    totals?: undefined;
                    currency?: undefined;
                    orderStatus?: undefined;
                    confirmation?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    orderId: string;
                    paymentIntentId: string;
                    paymentMethod: string;
                    confirmationData: {
                        clientSecret: string;
                        returnUrl: string;
                    };
                    cartId?: undefined;
                    deliveryAddress?: undefined;
                    contact?: undefined;
                };
                output: {
                    paymentStatus: string;
                    orderStatus: string;
                    confirmation: {
                        orderId: string;
                        receiptUrl: string;
                        paidAt: string;
                    };
                    cartId?: undefined;
                    items?: undefined;
                    totals?: undefined;
                    currency?: undefined;
                    orderId?: undefined;
                    orderNumber?: undefined;
                    status?: undefined;
                    orderSummary?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            })[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102030_/l2/petShopStripe/homePage.defs" {
    export const homePagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: any[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    highlightLimits: {
                        type: string;
                        required: boolean;
                        fields: {
                            categories: {
                                type: string;
                            };
                            products: {
                                type: string;
                            };
                            services: {
                                type: string;
                            };
                        };
                    };
                    filters: {
                        type: string;
                        required: boolean;
                        fields: {
                            categoryIds: {
                                type: string;
                            };
                            availabilityStatus: {
                                type: string;
                            };
                            priceRange: {
                                type: string;
                                fields: {
                                    min: {
                                        type: string;
                                    };
                                    max: {
                                        type: string;
                                    };
                                };
                            };
                        };
                    };
                };
                output: {
                    categories: {
                        type: string;
                        items: {
                            categoryId: string;
                            name: string;
                            imageUrl: string;
                        };
                    };
                    items: {
                        type: string;
                        items: {
                            itemType: string;
                            itemId: string;
                            name: string;
                            price: {
                                amount: string;
                                currency: string;
                            };
                            availabilityStatus: string;
                            categoryIds: string;
                            imageUrl: string;
                        };
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: any[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
    export const materializeIndex: ({
        id: string;
        agent: string;
        defsPath: string;
        skillPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        agent: string;
        defsPath: string;
        moduleName: string;
        outputPath: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: AuraDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102029_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
        telemetryReceived?: number;
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102030_/l2/petShopStripe/web/contracts/cartPage" {
    export interface PetShopStripeGetCartInput {
        cartContext: {
            cartId?: string;
        };
        include: {
            items: boolean;
            totals: boolean;
        };
    }
    export interface PetShopStripeGetCartOutput {
        cart: {
            cartId: string;
            status: string;
            currency: string;
            itemsCount: number;
            subtotalAmount: number;
            discountAmount: number;
            totalAmount: number;
            items: Array<{
                itemId: string;
                productId?: string;
                serviceId?: string;
                name: string;
                quantity: number;
                unitPrice: number;
                totalPrice: number;
            }>;
        };
    }
    export interface PetShopStripeUpdateCartInput {
        cartContext: {
            cartId?: string;
        };
        changes: {
            items: Array<{
                itemId?: string;
                productId?: string;
                serviceId?: string;
                quantity?: number;
                action: 'updateQuantity' | 'remove';
            }>;
        };
    }
    export interface PetShopStripeUpdateCartOutput {
        cart: {
            cartId: string;
            status: string;
            itemsCount: number;
            subtotalAmount: number;
            discountAmount: number;
            totalAmount: number;
            items: Array<{
                itemId: string;
                productId?: string;
                serviceId?: string;
                name: string;
                quantity: number;
                unitPrice: number;
                totalPrice: number;
            }>;
        };
    }
    export interface PetShopStripeStartCheckoutInput {
        cartContext: {
            cartId?: string;
        };
        deliveryContact?: {
            phone?: string;
            email?: string;
        };
        deliveryAddress?: {
            addressId?: string;
            street?: string;
            number?: string;
            city?: string;
            state?: string;
            postalCode?: string;
        };
    }
    export interface PetShopStripeStartCheckoutOutput {
        order: {
            orderId: string;
            status: string;
            paymentStatus: string;
            totalAmount: number;
        };
        cart: {
            cartId: string;
            status: string;
        };
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/cartPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetCartInput, PetShopStripeGetCartOutput, PetShopStripeStartCheckoutInput, PetShopStripeUpdateCartInput } from "_102030_/l2/petShopStripe/web/contracts/cartPage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetCart: string;
        couldNotUpdateCart: string;
        updateCartLoading: string;
        couldNotStartCheckout: string;
        startCheckoutLoading: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeCartPageBase extends CollabLitElement {
        private readonly _stateKeys;
        cart: PetShopStripeGetCartOutput['cart'] | undefined;
        updateCartState: 'idle' | 'loading' | 'success' | 'error';
        startCheckoutState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetCart(params?: PetShopStripeGetCartInput, options?: BffClientOptions): Promise<void>;
        updateCart(params: PetShopStripeUpdateCartInput, signal?: AbortSignal): Promise<void>;
        handleUpdateCartClick(): void;
        startCheckout(params: PetShopStripeStartCheckoutInput, signal?: AbortSignal): Promise<void>;
        handleStartCheckoutClick(): void;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/cartPage" {
    import { PetShopStripeCartPageBase } from "_102030_/l2/petShopStripe/web/shared/cartPage";
    export class PetShopStripeDesktopPage11CartPagePage extends PetShopStripeCartPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/catalogPage" {
    export interface PetShopStripeGetCatalogListInput {
        categoria?: string;
        tipo?: string;
        precoMin?: number;
        precoMax?: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopStripeGetCatalogListOutput {
        items: Array<{
            itemId: string;
            itemType: 'Product' | 'Service';
            title: string;
            summary: string;
            price: number;
            status: string;
            categoryTitle: string;
        }>;
        pagination: {
            page: number;
            pageSize: number;
            totalItems: number;
        };
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/catalogPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetCatalogList: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeCatalogPageBase extends CollabLitElement {
        private readonly _stateKeys;
        items: Array<{
            itemId: string;
            itemType: 'Product' | 'Service';
            title: string;
            summary: string;
            price: number;
            status: string;
            categoryTitle: string;
        }>;
        pagination: {
            page: number;
            pageSize: number;
            totalItems: number;
        } | undefined;
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetCatalogList(params?: {
            categoria?: string;
            tipo?: string;
            precoMin?: number;
            precoMax?: number;
            page?: number;
            pageSize?: number;
        }, options?: BffClientOptions): Promise<void>;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/catalogPage" {
    import { PetShopStripeCatalogPageBase } from "_102030_/l2/petShopStripe/web/shared/catalogPage";
    export class PetShopStripeDesktopPageCatalogPagePage extends PetShopStripeCatalogPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/accountOrdersPage" {
    export interface PetShopStripeGetOrderHistoryInput {
        customerId: string;
        filters: {
            orderStatus: string;
            startDate: string;
            endDate: string;
        };
    }
    export interface PetShopStripeGetOrderHistoryOutput {
        orders: Array<{
            orderId: string;
            orderNumber: string;
            status: string;
            paymentStatus: string;
            totalAmount: number;
            createdAt: string;
            items: Array<{
                itemType: 'product' | 'service';
                itemId: string;
                name: string;
                quantity: number;
                unitPrice: number;
            }>;
        }>;
    }
    export interface PetShopStripeGetCustomerServiceBookingsInput {
        customerId: string;
        filters: {
            bookingStatus: string;
            startDate: string;
            endDate: string;
        };
    }
    export interface PetShopStripeGetCustomerServiceBookingsOutput {
        bookings: Array<{
            serviceBookingId: string;
            status: string;
            scheduledDate: string;
            scheduledStartTime: string;
            scheduledEndTime: string;
            timezone: string;
            service: {
                serviceId: string;
                name: string;
            };
            pet: {
                petId: string;
                name: string;
            };
        }>;
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/accountOrdersPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetOrderHistoryInput, PetShopStripeGetOrderHistoryOutput, PetShopStripeGetCustomerServiceBookingsInput, PetShopStripeGetCustomerServiceBookingsOutput } from "_102030_/l2/petShopStripe/web/contracts/accountOrdersPage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetOrderHistory: string;
        loadingGetCustomerServiceBookings: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeAccountOrdersPageBase extends CollabLitElement {
        private readonly _stateKeys;
        orders: PetShopStripeGetOrderHistoryOutput['orders'];
        bookings: PetShopStripeGetCustomerServiceBookingsOutput['bookings'];
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetOrderHistory(params?: PetShopStripeGetOrderHistoryInput, options?: BffClientOptions): Promise<void>;
        loadGetCustomerServiceBookings(params?: PetShopStripeGetCustomerServiceBookingsInput, options?: BffClientOptions): Promise<void>;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/accountOrdersPage" {
    import { PetShopStripeAccountOrdersPageBase } from "_102030_/l2/petShopStripe/web/shared/accountOrdersPage";
    export class PetShopStripeDesktopPage11AccountOrdersPagePage extends PetShopStripeAccountOrdersPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/adminCatalogPage" {
    export interface PetShopStripeGetCatalogAdminListInput {
        itemType: string;
        statusFilter: string;
        categoryId: string;
        searchText: string;
        page: number;
        pageSize: number;
    }
    export interface PetShopStripeGetCatalogAdminListOutput {
        items: Array<{
            itemId: string;
            itemType: string;
            name: string;
            categoryId: string;
            categoryName: string;
            price: number;
            status: string;
            updatedAt: string;
        }>;
        pagination: {
            page: number;
            pageSize: number;
            totalItems: number;
            totalPages: number;
        };
    }
    export interface PetShopStripeManageCatalogInput {
        action: string;
        itemType: string;
        itemId: string;
        payload: {
            name: string;
            description: string;
            price: number;
            duration: number;
            status: string;
            categoryId: string;
        };
    }
    export interface PetShopStripeManageCatalogOutput {
        itemId: string;
        itemType: string;
        status: string;
        updatedAt: string;
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/adminCatalogPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetCatalogAdminListInput, PetShopStripeGetCatalogAdminListOutput, PetShopStripeManageCatalogInput } from "_102030_/l2/petShopStripe/web/contracts/adminCatalogPage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetCatalogAdminList: string;
        couldNotManageCatalog: string;
        manageCatalogLoading: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeAdminCatalogPageBase extends CollabLitElement {
        private readonly _stateKeys;
        items: PetShopStripeGetCatalogAdminListOutput['items'];
        pagination: PetShopStripeGetCatalogAdminListOutput['pagination'] | undefined;
        manageCatalogState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetCatalogAdminList(params?: Partial<PetShopStripeGetCatalogAdminListInput>, options?: BffClientOptions): Promise<void>;
        manageCatalog(params: PetShopStripeManageCatalogInput, signal?: AbortSignal): Promise<void>;
        handleManageCatalogClick(): void;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/adminCatalogPage" {
    import { PetShopStripeAdminCatalogPageBase } from "_102030_/l2/petShopStripe/web/shared/adminCatalogPage";
    export class PetShopStripeDesktopPage11AdminCatalogPagePage extends PetShopStripeAdminCatalogPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/adminMetricsPage" {
    export interface PetShopStripeGetMetricsDashboardInput {
        dateRange: {
            from: string;
            to: string;
        };
        filters: {
            orderStatus: Array<string>;
            paymentStatus: Array<string>;
            itemType: Array<string>;
        };
        granularity: 'hour' | 'day' | 'week' | 'month';
    }
    export interface PetShopStripeGetMetricsDashboardOutput {
        series: {
            revenue: Array<{
                timestamp: string;
                value: number;
            }>;
            orders: Array<{
                timestamp: string;
                value: number;
            }>;
            averageTicket: Array<{
                timestamp: string;
                value: number;
            }>;
            approvalRate: Array<{
                timestamp: string;
                value: number;
            }>;
            canceledOrders: Array<{
                timestamp: string;
                value: number;
            }>;
        };
        aggregations: {
            totalRevenue: number;
            orderCount: number;
            averageTicket: number;
            approvedPayments: number;
            canceledOrders: number;
        };
        dimensions: {
            orderStatus: Array<string>;
            paymentStatus: Array<string>;
            itemType: Array<string>;
        };
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/adminMetricsPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetMetricsDashboardInput, PetShopStripeGetMetricsDashboardOutput } from "_102030_/l2/petShopStripe/web/contracts/adminMetricsPage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetMetricsDashboard: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeAdminMetricsPageBase extends CollabLitElement {
        private readonly _stateKeys;
        series: PetShopStripeGetMetricsDashboardOutput['series'] | undefined;
        aggregations: PetShopStripeGetMetricsDashboardOutput['aggregations'] | undefined;
        dimensions: PetShopStripeGetMetricsDashboardOutput['dimensions'] | undefined;
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetMetricsDashboard(params?: PetShopStripeGetMetricsDashboardInput, options?: BffClientOptions): Promise<void>;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/adminMetricsPage" {
    import { PetShopStripeAdminMetricsPageBase } from "_102030_/l2/petShopStripe/web/shared/adminMetricsPage";
    export class PetShopStripeDesktopPage11AdminMetricsPagePage extends PetShopStripeAdminMetricsPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/adminOrdersPage" {
    export interface PetShopStripeGetOrderAdminListInput {
        statusFilter: string;
        periodStart: string;
        periodEnd: string;
        orderNumber: string;
        page: number;
        pageSize: number;
    }
    export interface PetShopStripeGetOrderAdminListOutput {
        orders: Array<{
            orderId: string;
            orderNumber: string;
            status: string;
            paymentStatus: string;
            totalAmount: number;
            createdAt: string;
            updatedAt: string;
        }>;
        page: number;
        pageSize: number;
        total: number;
    }
    export interface PetShopStripeUpdateOrderStatusInput {
        orderId: string;
        newStatus: string;
        statusReason: string;
    }
    export interface PetShopStripeUpdateOrderStatusOutput {
        orderId: string;
        status: string;
        statusHistory: Array<{
            fromStatus: string;
            toStatus: string;
            changedAt: string;
            changedBy: string;
        }>;
        updatedAt: string;
    }
    export interface PetShopStripeGetServiceBookingsInput {
        serviceDate: string;
        serviceId: string;
        status: string;
        page: number;
        pageSize: number;
    }
    export interface PetShopStripeGetServiceBookingsOutput {
        serviceBookings: Array<{
            serviceBookingId: string;
            serviceId: string;
            serviceName: string;
            customerId: string;
            customerName: string;
            petId: string;
            petName: string;
            status: string;
            scheduledDate: string;
            scheduledStartTime: string;
            scheduledEndTime: string;
            orderId: string;
        }>;
        page: number;
        pageSize: number;
        total: number;
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/adminOrdersPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetOrderAdminListInput, PetShopStripeGetOrderAdminListOutput, PetShopStripeGetServiceBookingsInput, PetShopStripeGetServiceBookingsOutput, PetShopStripeUpdateOrderStatusInput } from "_102030_/l2/petShopStripe/web/contracts/adminOrdersPage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetOrderAdminList: string;
        loadingGetServiceBookings: string;
        couldNotUpdateOrderStatus: string;
        updateOrderStatusLoading: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeAdminOrdersPageBase extends CollabLitElement {
        private readonly _stateKeys;
        orders: PetShopStripeGetOrderAdminListOutput['orders'];
        page: PetShopStripeGetOrderAdminListOutput['page'] | undefined;
        pageSize: PetShopStripeGetOrderAdminListOutput['pageSize'] | undefined;
        total: PetShopStripeGetOrderAdminListOutput['total'] | undefined;
        serviceBookings: PetShopStripeGetServiceBookingsOutput['serviceBookings'];
        updateOrderStatusState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetOrderAdminList(params?: Partial<PetShopStripeGetOrderAdminListInput>, options?: BffClientOptions): Promise<void>;
        loadGetServiceBookings(params?: Partial<PetShopStripeGetServiceBookingsInput>, options?: BffClientOptions): Promise<void>;
        updateOrderStatus(params: PetShopStripeUpdateOrderStatusInput, signal?: AbortSignal): Promise<void>;
        handleUpdateOrderStatusClick(): void;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/adminOrdersPage" {
    import { PetShopStripeAdminOrdersPageBase } from "_102030_/l2/petShopStripe/web/shared/adminOrdersPage";
    export class PetShopStripeDesktopPage11AdminOrdersPagePage extends PetShopStripeAdminOrdersPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/homePage" {
    export interface PetShopStripeGetCatalogHighlightsInput {
        highlightLimits: {
            categories: number;
            products: number;
            services: number;
        };
        filters: {
            categoryIds: string;
            availabilityStatus: string;
            priceRange: {
                min: number;
                max: number;
            };
        };
    }
    export interface PetShopStripeGetCatalogHighlightsOutput {
        categories: Array<{
            categoryId: string;
            name: string;
            imageUrl: string;
        }>;
        items: Array<{
            itemType: string;
            itemId: string;
            name: string;
            price: {
                amount: number;
                currency: string;
            };
            availabilityStatus: string;
            categoryIds: string;
            imageUrl: string;
        }>;
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/homePage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetCatalogHighlightsInput, PetShopStripeGetCatalogHighlightsOutput } from "_102030_/l2/petShopStripe/web/contracts/homePage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetCatalogHighlights: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeHomePageBase extends CollabLitElement {
        private readonly _stateKeys;
        categories: PetShopStripeGetCatalogHighlightsOutput['categories'];
        items: PetShopStripeGetCatalogHighlightsOutput['items'];
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetCatalogHighlights(params?: PetShopStripeGetCatalogHighlightsInput, options?: BffClientOptions): Promise<void>;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/homePage" {
    import { PetShopStripeHomePageBase } from "_102030_/l2/petShopStripe/web/shared/homePage";
    export class PetShopStripeDesktopPage11HomePagePage extends PetShopStripeHomePageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/web/contracts/checkoutPage" {
    export interface PetShopStripeGetCheckoutCartSummaryInput {
        cartId: string;
    }
    export interface PetShopStripeGetCheckoutCartSummaryOutput {
        cartId: string;
        items: Array<{
            itemId: string;
            itemType: 'product' | 'service';
            productId: string;
            serviceId: string;
            name: string;
            quantity: number;
            unitPrice: number;
            totalPrice: number;
        }>;
        totals: {
            subtotal: number;
            discount: number;
            shipping: number;
            total: number;
        };
        currency: string;
    }
    export interface PetShopStripeCreateOrderFromCheckoutInput {
        cartId: string;
        deliveryAddress: {
            street: string;
            number: string;
            complement: string;
            district: string;
            city: string;
            state: string;
            postalCode: string;
            country: string;
        };
        contact: {
            name: string;
            email: string;
            phone: string;
        };
    }
    export interface PetShopStripeCreateOrderFromCheckoutOutput {
        orderId: string;
        orderNumber: string;
        status: string;
        paymentStatus: string;
        orderSummary: {
            items: Array<{
                itemId: string;
                itemType: 'product' | 'service';
                name: string;
                quantity: number;
                unitPrice: number;
                totalPrice: number;
            }>;
            totals: {
                subtotal: number;
                discount: number;
                shipping: number;
                total: number;
            };
            currency: string;
        };
    }
    export interface PetShopStripeConfirmStripePaymentInput {
        orderId: string;
        paymentIntentId: string;
        paymentMethod: string;
        confirmationData: {
            clientSecret: string;
            returnUrl: string;
        };
    }
    export interface PetShopStripeConfirmStripePaymentOutput {
        paymentStatus: string;
        orderStatus: string;
        confirmation: {
            orderId: string;
            receiptUrl: string;
            paidAt: string;
        };
    }
}
declare module "_102030_/l2/petShopStripe/web/shared/checkoutPage" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetShopStripeGetCheckoutCartSummaryInput, PetShopStripeGetCheckoutCartSummaryOutput, PetShopStripeCreateOrderFromCheckoutInput, PetShopStripeConfirmStripePaymentInput } from "_102030_/l2/petShopStripe/web/contracts/checkoutPage";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingGetCheckoutCartSummary: string;
        couldNotCreateOrderFromCheckout: string;
        createOrderFromCheckoutLoading: string;
        couldNotConfirmStripePayment: string;
        confirmStripePaymentLoading: string;
    };
    type MessageType = typeof message_en;
    export class PetShopStripeCheckoutPageBase extends CollabLitElement {
        private readonly _stateKeys;
        cartId: PetShopStripeGetCheckoutCartSummaryOutput['cartId'] | undefined;
        items: PetShopStripeGetCheckoutCartSummaryOutput['items'];
        totals: PetShopStripeGetCheckoutCartSummaryOutput['totals'] | undefined;
        currency: PetShopStripeGetCheckoutCartSummaryOutput['currency'] | undefined;
        createOrderFromCheckoutState: 'idle' | 'loading' | 'success' | 'error';
        confirmStripePaymentState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetCheckoutCartSummary(params?: PetShopStripeGetCheckoutCartSummaryInput, options?: BffClientOptions): Promise<void>;
        createOrderFromCheckout(params: PetShopStripeCreateOrderFromCheckoutInput, signal?: AbortSignal): Promise<void>;
        handleCreateOrderFromCheckoutClick(): void;
        confirmStripePayment(params: PetShopStripeConfirmStripePaymentInput, signal?: AbortSignal): Promise<void>;
        handleConfirmStripePaymentClick(): void;
    }
}
declare module "_102030_/l2/petShopStripe/web/desktop/page11/checkoutPage" {
    import { PetShopStripeCheckoutPageBase } from "_102030_/l2/petShopStripe/web/shared/checkoutPage";
    export class PetShopStripeDesktopPage11CheckoutPagePage extends PetShopStripeCheckoutPageBase {
        render(): any;
    }
}
declare module "_102030_/l2/petShopStripe/index" { }
declare module "_102030_/l2/petShopStripe/module" {
    import type { AuraModuleFrontendDefinition, IPaths, IGenomeConfig } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: Record<string, IGenomeConfig>;
    export const skills: IPaths;
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs" {
    export const pluginStripePagamentosPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginConnectionPlan;
}
declare module "_102030_/l2/petshop/shared/contracts/home" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult } from "_102030_/l1/petshop/module";
    export type PetshopHomeRequest = PetshopHomeLoadParams;
    export interface PetshopHomeResponse extends PetshopHomeLoadResult {
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
}
declare module "_102030_/l2/petshop/web/shared/home" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetshopHomeRequest, PetshopHomeResponse } from "_102030_/l2/petshop/shared/contracts/home";
    export function loadPetshopHome(params?: PetshopHomeRequest, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<PetshopHomeResponse>>;
}
declare module "_102030_/l2/petshop/web/shared/homeFormatters" {
    export function formatPrice(priceInCents: number): string;
}
declare module "_102030_/l2/petshop/shared/contracts/update-product" {
    export type { PetshopUpdateProductParams, PetshopCatalogProduct } from "_102030_/l1/petshop/module";
}
declare module "_102030_/l2/petshop/web/shared/updateProduct" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PetshopCatalogProduct, PetshopUpdateProductParams } from "_102030_/l2/petshop/shared/contracts/update-product";
    export function updatePetshopProduct(params: PetshopUpdateProductParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<PetshopCatalogProduct>>;
}
declare module "_102030_/l2/petshop/web/desktop/page11/home" {
    import { LitElement } from 'lit';
    import type { PetshopCatalogProduct } from "_102030_/l1/petshop/module";
    type PetshopSection = 'catalog' | 'edit-products';
    export class PetshopWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            items: {
                state: boolean;
            };
            topItems: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            editorAuthor: {
                state: boolean;
            };
        };
        currentSection: PetshopSection;
        items: PetshopCatalogProduct[];
        topItems: PetshopCatalogProduct[];
        status: string;
        editorAuthor: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handlePopState;
        private handleRouteChange;
        private navigateWithinModule;
        private loadHome;
        private handleSectionClick;
        private handleEditorSubmit;
        private retryUpdateProduct;
        private saveProduct;
        private renderCatalog;
        private renderEditor;
        render(): any;
    }
}
declare module "_102030_/l2/petshop/index" { }
declare module "_102030_/l2/petshop/module.defs" {
    export const skill: {
        readonly moduleId: "petshop";
        readonly purpose: "Petshop client module with desktop and mobile page variations.";
        readonly pages: readonly ["home", "edit-products"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.petshop.currentSection", "ui.petshop.selectedCategory", "ui.petshop.searchQuery", "ui.petshop.editorAuthor"];
    };
}
declare module "_102030_/l2/petshop/module" {
    import type { AuraModuleFrontendDefinition } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.petshop.currentSection";
        readonly selectedCategory: "ui.petshop.selectedCategory";
        readonly searchQuery: "ui.petshop.searchQuery";
        readonly editorAuthor: "ui.petshop.editorAuthor";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102030_/l2/petshop/web/routes/catalog" {
    export { PetshopWebDesktopHomePage } from "_102030_/l2/petshop/web/desktop/page11/home";
}
declare module "_102030_/l2/petshop/web/routes/edit-products" {
    export { PetshopWebDesktopHomePage } from "_102030_/l2/petshop/web/desktop/page11/home";
}
declare module "_102030_/l2/petshop/web/shared/home.defs" {
    export const skill = "\n# Petshop Home Page\n\n## Purpose\n\nRender the desktop home page for the petshop module using a single aggregated\nBFF request.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `petshop.home.load`\n- The routine must return only the data the page needs:\n  - `seed`\n  - `catalog`\n  - `topProducts`\n\n## Page Behavior\n\n- Load the page with one BFF call on connect\n- Render a compact toolbar with category filters\n- Show a status line with the current page state\n- Render a \"Top products\" section\n- Render a \"Catalog\" section\n- Reload the page when the user clicks reload\n- Re-run the page load with a category filter when the user clicks a category\n\n## Important Data\n\n- Catalog item fields:\n  - `name`\n  - `category`\n  - `priceInCents`\n  - `stockStatus`\n  - `description`\n- Top product fields:\n  - `name`\n  - `category`\n  - `highlightScore`\n  - `priceInCents`\n\n## Shared Files\n\n- `web/shared/home.ts` owns the page BFF call\n- `web/shared/homeFormatters.ts` owns display formatting helpers such as\n  `formatPrice`\n\n## Layout Intent\n\n- Dense but readable business UI\n- Fast visual scan for category, stock state, and price\n- Keep the page compatible with the master shell aside/header\n- Use light DOM compatible styling\n";
}
declare module "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs" {
    export const pluginStripePagamentosPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginPlan;
}
