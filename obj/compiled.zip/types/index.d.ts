declare module "_102030_/l1/petShopStripe/layer_1_external/cart.defs" {
    export const cartTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "cart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "plan-table-definition:cart";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "cart";
                readonly tableName: "cart";
                readonly moduleId: "petShopStripe";
                readonly title: "Carrinho";
                readonly purpose: "Persistir o carrinho ativo do cliente para checkout.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Cart";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "cart_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do carrinho.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente dono do carrinho.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do carrinho (ativo, convertido, abandonado, expirado).";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Moeda usada para preços do carrinho.";
                }, {
                    readonly name: "items_count";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens no carrinho.";
                }, {
                    readonly name: "subtotal_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Subtotal do carrinho antes de descontos.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Desconto aplicado ao carrinho.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total do carrinho após descontos.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do carrinho.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do carrinho.";
                }, {
                    readonly name: "expires_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data de expiração do carrinho.";
                }, {
                    readonly name: "last_activity_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Última interação no carrinho.";
                }];
                readonly primaryKey: readonly ["cart_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule.persistence.excludeMdmEntities";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_cart_customer_status";
                    readonly columns: readonly ["customer_id", "status"];
                    readonly reason: "rule.index.lookupByCustomerStatus";
                }, {
                    readonly indexName: "idx_cart_updated_at";
                    readonly columns: readonly ["updated_at"];
                    readonly reason: "rule.index.sortByRecentUpdate";
                }, {
                    readonly indexName: "idx_cart_expires_at";
                    readonly columns: readonly ["expires_at"];
                    readonly reason: "rule.index.expirationCleanup";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "CartDetails";
                    readonly reason: "rule.persistence.aggregateWithChildEntities";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/cart.defs.ts";
                readonly exportName: "cartTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default cartTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "plan-table-definition:order";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "petShopStripe";
                readonly title: "Pedido";
                readonly purpose: "Registrar pedidos gerados no checkout e seu ciclo de vida.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "order_number";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Número legível do pedido para referência do cliente e admin.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente responsável pelo pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do ciclo de vida do pedido.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do pagamento associado ao pedido.";
                }, {
                    readonly name: "payment_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao pagamento horizontal.";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "BRL";
                    readonly description: "Moeda do pedido.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Valor total do pedido.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de descontos aplicados.";
                }, {
                    readonly name: "shipping_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor de entrega, quando aplicável.";
                }, {
                    readonly name: "scheduled_service_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data e hora do serviço agendado, quando aplicável.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Última atualização do pedido.";
                }, {
                    readonly name: "paid_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora da confirmação de pagamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "ruleOrderRequiresCustomer";
                }, {
                    readonly fieldName: "payment_id";
                    readonly targetEntity: "Payment";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "rulePaymentRequiredToConfirmOrder";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_customer_id_created_at";
                    readonly columns: readonly ["customer_id", "created_at"];
                    readonly unique: false;
                    readonly reason: "Busca de pedidos do cliente por período.";
                }, {
                    readonly indexName: "idx_order_status_created_at";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar pedidos por status no admin.";
                }, {
                    readonly indexName: "idx_order_paid_at";
                    readonly columns: readonly ["paid_at"];
                    readonly unique: false;
                    readonly reason: "Apuração de métricas por data de pagamento.";
                }, {
                    readonly indexName: "idx_order_scheduled_service_at";
                    readonly columns: readonly ["scheduled_service_at"];
                    readonly unique: false;
                    readonly reason: "Agenda de serviços.";
                }, {
                    readonly indexName: "idx_order_order_number";
                    readonly columns: readonly ["order_number"];
                    readonly unique: true;
                    readonly reason: "Consulta rápida por número do pedido.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderDetails";
                    readonly reason: "Armazenar itens do pedido e dados auxiliares do checkout.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["metricTableSalesOps"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "ruleOrderStatusLifecycle", "rulePaymentRequiredToConfirmOrder"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/salesOpsMetrics.defs" {
    export const salesOpsMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "salesOpsMetrics";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 53;
            readonly planId: "plan-metric-table-definition:salesOpsMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "salesOpsMetrics";
                readonly tableName: "sales_ops_metrics";
                readonly moduleId: "petShopStripe";
                readonly title: "Métricas de vendas e pagamentos";
                readonly purpose: "Agregar dados de pedidos e pagamentos para análise de receita, ticket médio, volume de pedidos e taxa de aprovação.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento agregado.";
                }, {
                    readonly name: "order_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pedido no momento do evento.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pagamento associado.";
                }, {
                    readonly name: "item_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo do item vendido (produto ou serviço).";
                }, {
                    readonly name: "order_total";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total dos pedidos.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "approved_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pagamentos aprovados.";
                }, {
                    readonly name: "canceled_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos cancelados.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderStatus";
                    readonly column: "order_status";
                    readonly type: "text";
                    readonly description: "Status do pedido no momento do evento";
                }, {
                    readonly dimensionId: "paymentStatus";
                    readonly column: "payment_status";
                    readonly type: "text";
                    readonly description: "Status do pagamento associado";
                }, {
                    readonly dimensionId: "itemType";
                    readonly column: "item_type";
                    readonly type: "text";
                    readonly description: "Tipo do item vendido (produto ou serviço)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "order_total";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total dos pedidos";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "order_total";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio dos pedidos";
                }, {
                    readonly measureId: "approvedPayments";
                    readonly column: "approved_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pagamentos aprovados";
                }, {
                    readonly measureId: "canceledOrders";
                    readonly column: "canceled_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos cancelados";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderPaid", "orderCanceled", "serviceBookingCreated", "serviceBookingConfirmed"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "90 days";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_sales_ops_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consulta temporal de métricas.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_order_status_time";
                        readonly columns: readonly ["order_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pedido e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_payment_status_time";
                        readonly columns: readonly ["payment_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pagamento e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_item_type_time";
                        readonly columns: readonly ["item_type", "event_time"];
                        readonly purpose: "Filtrar métricas por tipo de item e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseUpdateMetricsOnOrderPaid"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesOpsMetrics.defs.ts";
                readonly exportName: "salesOpsMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesOpsMetricsMetricTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/serviceBooking.defs" {
    export const serviceBookingTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "serviceBooking";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "plan-table-definition:serviceBooking";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "serviceBooking";
                readonly tableName: "service_booking";
                readonly moduleId: "petShopStripe";
                readonly title: "Agendamento de serviço";
                readonly purpose: "Controlar reservas de data e horário para serviços do pet shop.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ServiceBooking";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "service_booking_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do agendamento de serviço.";
                }, {
                    readonly name: "service_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Serviço reservado no agendamento.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente que realizou o agendamento.";
                }, {
                    readonly name: "pet_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pet associado ao serviço.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido associado ao agendamento.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do agendamento (ex.: pendente, confirmado, concluído, cancelado).";
                }, {
                    readonly name: "scheduled_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data do agendamento.";
                }, {
                    readonly name: "scheduled_start_time";
                    readonly type: "time";
                    readonly nullable: false;
                    readonly description: "Horário de início do agendamento.";
                }, {
                    readonly name: "scheduled_end_time";
                    readonly type: "time";
                    readonly nullable: true;
                    readonly description: "Horário de término previsto do agendamento.";
                }, {
                    readonly name: "timezone";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Fuso horário do agendamento.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações do cliente ou do pet shop.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do agendamento.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora da última atualização do agendamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento do agendamento.";
                }];
                readonly primaryKey: readonly ["service_booking_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_id";
                    readonly targetEntity: "Service";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Serviço agendado.";
                }, {
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Cliente responsável pelo agendamento.";
                }, {
                    readonly fieldName: "pet_id";
                    readonly targetEntity: "Pet";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Pet atendido no agendamento.";
                }, {
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular o agendamento ao pedido.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_service_booking_customer";
                    readonly columns: readonly ["customer_id", "scheduled_date"];
                    readonly reason: "Listagem de agendamentos por cliente e data.";
                }, {
                    readonly indexName: "idx_service_booking_pet";
                    readonly columns: readonly ["pet_id", "scheduled_date"];
                    readonly reason: "Consultas de agendamentos por pet.";
                }, {
                    readonly indexName: "idx_service_booking_service_date";
                    readonly columns: readonly ["service_id", "scheduled_date"];
                    readonly reason: "Consulta de agendamentos por serviço e data.";
                }, {
                    readonly indexName: "idx_service_booking_order";
                    readonly columns: readonly ["order_id"];
                    readonly reason: "Localizar agendamento pelo pedido.";
                }, {
                    readonly indexName: "idx_service_booking_status_date";
                    readonly columns: readonly ["status", "scheduled_date"];
                    readonly reason: "Filtros de status e agenda.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceBooking.defs.ts";
                readonly exportName: "serviceBookingTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceBookingTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseAddToCart.defs" {
    export const usecaseAddToCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseAddToCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseAddToCart";
                readonly title: "Adicionar item ao carrinho";
                readonly purpose: "Adicionar produto ou serviço ao carrinho do cliente e recalcular totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["addToCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseAddToCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseConfirmStripePayment.defs" {
    export const usecaseConfirmStripePaymentUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseConfirmStripePayment";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseConfirmStripePayment";
                readonly title: "Confirmar pagamento Stripe";
                readonly purpose: "Atualizar status do pedido após confirmação de pagamento e registrar métricas.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "salesOpsMetrics"];
                readonly commands: readonly ["confirmStripePayment"];
                readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseConfirmStripePaymentUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseCreateOrder.defs" {
    export const usecaseCreateOrderUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseCreateOrder";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseCreateOrder";
                readonly title: "Criar pedido";
                readonly purpose: "Gerar pedido a partir do carrinho confirmado e marcar carrinho como convertido.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["order", "cart"];
                readonly commands: readonly ["startCheckout"];
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            };
        };
    };
    export default usecaseCreateOrderUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetCart.defs" {
    export const usecaseGetCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetCart";
                readonly title: "Consultar carrinho";
                readonly purpose: "Carregar o carrinho ativo do cliente com itens e totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetMetricsDashboard.defs" {
    export const usecaseGetMetricsDashboardUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetMetricsDashboard";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetMetricsDashboard";
                readonly title: "Consultar métricas de vendas";
                readonly purpose: "Obter séries temporais de métricas de vendas e pagamentos para dashboard.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetMetricsDashboardUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderAdminList.defs" {
    export const usecaseGetOrderAdminListUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderAdminList";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderAdminList";
                readonly title: "Listar pedidos administrativos";
                readonly purpose: "Listar pedidos por status e período para gestão administrativa.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderAdminListUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderHistory.defs" {
    export const usecaseGetOrderHistoryUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderHistory";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderHistory";
                readonly title: "Listar pedidos do cliente";
                readonly purpose: "Listar pedidos do cliente para acompanhamento de histórico.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderHistoryUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetServiceBookings.defs" {
    export const usecaseGetServiceBookingsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetServiceBookings";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetServiceBookings";
                readonly title: "Listar agendamentos";
                readonly purpose: "Consultar agendamentos por cliente, pet ou serviço.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate"];
                readonly readsTables: readonly ["serviceBooking"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetServiceBookingsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseManageCatalog.defs" {
    export const usecaseManageCatalogUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseManageCatalog";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseManageCatalog";
                readonly title: "Gerenciar catálogo";
                readonly purpose: "Cadastrar, editar ou desativar produtos e serviços, preços e disponibilidade.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["catalogAggregate"];
                readonly outputEntities: readonly ["catalogAggregate"];
                readonly readsTables: readonly ["product", "service", "catalogCategory"];
                readonly writesTables: readonly ["product", "service", "catalogCategory"];
                readonly commands: readonly ["manageCatalog"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseManageCatalogUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseReconcilePayments.defs" {
    export const usecaseReconcilePaymentsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseReconcilePayments";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseReconcilePayments";
                readonly title: "Conciliar recebíveis";
                readonly purpose: "Registrar conciliação de pagamentos aprovados e lançar recebíveis.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["receivableAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["receivableAggregate"];
                readonly readsTables: readonly ["order", "payment", "stripeTransaction"];
                readonly writesTables: readonly ["receivable", "financialEntry"];
                readonly commands: readonly ["reconcilePayments"];
                readonly rulesApplied: readonly ["ruleReceivableFromPayment"];
            };
        };
    };
    export default usecaseReconcilePaymentsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseScheduleService.defs" {
    export const usecaseScheduleServiceUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseScheduleService";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseScheduleService";
                readonly title: "Agendar serviço";
                readonly purpose: "Criar agendamento de serviço e vincular ao pedido quando aplicável.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["serviceBooking", "order"];
                readonly commands: readonly ["scheduleService"];
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
        };
    };
    export default usecaseScheduleServiceUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateCart.defs" {
    export const usecaseUpdateCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateCart";
                readonly title: "Atualizar carrinho";
                readonly purpose: "Alterar quantidades ou remover itens do carrinho e atualizar totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["updateCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseUpdateCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateMetricsOnOrderPaid.defs" {
    export const usecaseUpdateMetricsOnOrderPaidUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateMetricsOnOrderPaid";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateMetricsOnOrderPaid";
                readonly title: "Atualizar métricas de vendas";
                readonly purpose: "Atualizar métricas operacionais quando pedidos são pagos ou cancelados.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["salesOpsMetrics"];
                readonly commands: readonly [];
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseUpdateMetricsOnOrderPaidUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateOrderStatus.defs" {
    export const usecaseUpdateOrderStatusUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateOrderStatus";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateOrderStatus";
                readonly title: "Atualizar status do pedido";
                readonly purpose: "Alterar status do pedido conforme ciclo de vida.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly commands: readonly ["updateOrderStatus"];
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
            };
        };
    };
    export default usecaseUpdateOrderStatusUsecasePlan;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102030_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102030_/l2/project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
        layouts: {
            1: {
                name: string;
                skill: string;
            };
        };
        designSystems: {
            1: {
                name: string;
                skill: string;
            };
        };
    };
}
declare module "_102030_/l2/petShopStripe/accountOrdersPage.defs" {
    export const accountOrdersPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: string[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    customerId: string;
                    filters: {
                        orderStatus: string;
                        startDate: string;
                        endDate: string;
                        bookingStatus?: undefined;
                    };
                };
                output: {
                    orders: {
                        orderId: string;
                        orderNumber: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                        createdAt: string;
                        items: {
                            itemType: string;
                            itemId: string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                        }[];
                    }[];
                    bookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    customerId: string;
                    filters: {
                        bookingStatus: string;
                        startDate: string;
                        endDate: string;
                        orderStatus?: undefined;
                    };
                };
                output: {
                    bookings: {
                        serviceBookingId: string;
                        status: string;
                        scheduledDate: string;
                        scheduledStartTime: string;
                        scheduledEndTime: string;
                        timezone: string;
                        service: {
                            serviceId: string;
                            name: string;
                        };
                        pet: {
                            petId: string;
                            name: string;
                        };
                    }[];
                    orders?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/adminCatalogPage.defs" {
    export const adminCatalogPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    itemType: string;
                    statusFilter: string;
                    categoryId: string;
                    searchText: string;
                    page: string;
                    pageSize: string;
                    action?: undefined;
                    itemId?: undefined;
                    payload?: undefined;
                };
                output: {
                    items: {
                        itemId: string;
                        itemType: string;
                        name: string;
                        categoryId: string;
                        categoryName: string;
                        price: string;
                        status: string;
                        updatedAt: string;
                    }[];
                    pagination: {
                        page: string;
                        pageSize: string;
                        totalItems: string;
                        totalPages: string;
                    };
                    itemId?: undefined;
                    itemType?: undefined;
                    status?: undefined;
                    updatedAt?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    action: string;
                    itemType: string;
                    itemId: string;
                    payload: {
                        name: string;
                        description: string;
                        price: string;
                        duration: string;
                        status: string;
                        categoryId: string;
                    };
                    statusFilter?: undefined;
                    categoryId?: undefined;
                    searchText?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                };
                output: {
                    itemId: string;
                    itemType: string;
                    status: string;
                    updatedAt: string;
                    items?: undefined;
                    pagination?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/adminDashboardPage.defs" {
    export const adminDashboardPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminDashboardPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 90;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminDashboardPage";
                readonly pageName: "Dashboard administrativo";
                readonly actor: "adminPetShop";
                readonly purpose: "Fornecer visão geral de pedidos, agenda e indicadores rápidos.";
                readonly capabilities: readonly ["manageOrdersServices", "financialOverview", "metricsDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycleManagement"];
                    readonly taskWorkflows: readonly ["serviceBooking", "paymentReconciliation"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["organization"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Intervalo de datas para filtrar KPIs, pedidos e agenda.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminOrdersPage";
                    readonly trigger: "Gerenciar pedidos";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminFinancialPage";
                    readonly trigger: "Ver financeiro";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminMetricsPage";
                    readonly trigger: "Ver métricas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo operacional";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "kpiSummaryCards";
                        readonly purpose: "Exibir KPIs de pedidos e agenda no período.";
                        readonly userActions: readonly ["Ver resumo operacional"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.status", "ServiceBooking.scheduled_date"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "operationalQueues";
                        readonly purpose: "Mostrar filas de pedidos por status e próximos agendamentos.";
                        readonly userActions: readonly ["Ver resumo operacional", "Acessar gestão de pedidos"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.order_number", "Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.service_id", "ServiceBooking.status", "ServiceBooking.scheduled_date", "ServiceBooking.scheduled_start_time"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Indicadores rápidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsSummaryWidget";
                        readonly purpose: "Apresentar resumo das métricas de vendas e pagamentos.";
                        readonly userActions: readonly ["Acessar métricas"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["salesOpsMetrics.totalRevenue", "salesOpsMetrics.orderCount", "salesOpsMetrics.approvedPayments", "salesOpsMetrics.canceledOrders"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAdminOverview";
                readonly purpose: "Carregar KPIs resumidos e filas operacionais.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly orderCountsByStatus: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly paymentStatusCounts: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly recentOrders: readonly [{
                        readonly orderId: "string";
                        readonly orderNumber: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                        readonly createdAt: "string";
                    }];
                    readonly upcomingBookings: readonly [{
                        readonly serviceBookingId: "string";
                        readonly serviceId: "string";
                        readonly status: "string";
                        readonly scheduledDate: "string";
                        readonly scheduledStartTime: "string";
                    }];
                };
                readonly readsEntities: readonly ["Order", "ServiceBooking"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "serviceBooking"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetOrderAdminList", "usecaseGetServiceBookings"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getMetricsSummary";
                readonly purpose: "Obter resumo das métricas de vendas para o painel.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly totalRevenue: "number";
                    readonly orderCount: "number";
                    readonly approvedPayments: "number";
                    readonly canceledOrders: "number";
                    readonly averageTicket: "number";
                };
                readonly readsEntities: readonly ["salesOpsMetrics"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetMetricsDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminDashboardPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminMetricsPage.defs" {
    export const adminMetricsPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    dateRange: {
                        from: string;
                        to: string;
                    };
                    filters: {
                        orderStatus: string[];
                        paymentStatus: string[];
                        itemType: string[];
                    };
                    granularity: string;
                };
                output: {
                    series: {
                        revenue: {
                            timestamp: string;
                            value: string;
                        }[];
                        orders: {
                            timestamp: string;
                            value: string;
                        }[];
                        averageTicket: {
                            timestamp: string;
                            value: string;
                        }[];
                        approvalRate: {
                            timestamp: string;
                            value: string;
                        }[];
                        canceledOrders: {
                            timestamp: string;
                            value: string;
                        }[];
                    };
                    aggregations: {
                        totalRevenue: string;
                        orderCount: string;
                        averageTicket: string;
                        approvedPayments: string;
                        canceledOrders: string;
                    };
                    dimensions: {
                        orderStatus: string[];
                        paymentStatus: string[];
                        itemType: string[];
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/adminOrdersPage.defs" {
    export const adminOrdersPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: string[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: ({
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef?: undefined;
                    fieldRef?: undefined;
                } | {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                })[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    statusFilter: string;
                    periodStart: string;
                    periodEnd: string;
                    orderNumber: string;
                    page: string;
                    pageSize: string;
                    orderId?: undefined;
                    newStatus?: undefined;
                    statusReason?: undefined;
                    serviceDate?: undefined;
                    serviceId?: undefined;
                    status?: undefined;
                };
                output: {
                    orders: {
                        orderId: string;
                        orderNumber: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                        createdAt: string;
                        updatedAt: string;
                    }[];
                    page: string;
                    pageSize: string;
                    total: string;
                    orderId?: undefined;
                    status?: undefined;
                    statusHistory?: undefined;
                    updatedAt?: undefined;
                    serviceBookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    orderId: string;
                    newStatus: string;
                    statusReason: string;
                    statusFilter?: undefined;
                    periodStart?: undefined;
                    periodEnd?: undefined;
                    orderNumber?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                    serviceDate?: undefined;
                    serviceId?: undefined;
                    status?: undefined;
                };
                output: {
                    orderId: string;
                    status: string;
                    statusHistory: {
                        fromStatus: string;
                        toStatus: string;
                        changedAt: string;
                        changedBy: string;
                    }[];
                    updatedAt: string;
                    orders?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                    total?: undefined;
                    serviceBookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    serviceDate: string;
                    serviceId: string;
                    status: string;
                    page: string;
                    pageSize: string;
                    statusFilter?: undefined;
                    periodStart?: undefined;
                    periodEnd?: undefined;
                    orderNumber?: undefined;
                    orderId?: undefined;
                    newStatus?: undefined;
                    statusReason?: undefined;
                };
                output: {
                    serviceBookings: {
                        serviceBookingId: string;
                        serviceId: string;
                        serviceName: string;
                        customerId: string;
                        customerName: string;
                        petId: string;
                        petName: string;
                        status: string;
                        scheduledDate: string;
                        scheduledStartTime: string;
                        scheduledEndTime: string;
                        orderId: string;
                    }[];
                    page: string;
                    pageSize: string;
                    total: string;
                    orders?: undefined;
                    orderId?: undefined;
                    status?: undefined;
                    statusHistory?: undefined;
                    updatedAt?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/cartPage.defs" {
    export const cartPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: any[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    include: {
                        items: string;
                        totals: string;
                    };
                    changes?: undefined;
                    "deliveryContact?"?: undefined;
                    "deliveryAddress?"?: undefined;
                };
                output: {
                    cart: {
                        cartId: string;
                        status: string;
                        currency: string;
                        itemsCount: string;
                        subtotalAmount: string;
                        discountAmount: string;
                        totalAmount: string;
                        items: {
                            itemId: string;
                            "productId?": string;
                            "serviceId?": string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                    };
                    order?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    changes: {
                        items: {
                            "itemId?": string;
                            "productId?": string;
                            "serviceId?": string;
                            "quantity?": string;
                            action: string;
                        }[];
                    };
                    include?: undefined;
                    "deliveryContact?"?: undefined;
                    "deliveryAddress?"?: undefined;
                };
                output: {
                    cart: {
                        cartId: string;
                        status: string;
                        itemsCount: string;
                        subtotalAmount: string;
                        discountAmount: string;
                        totalAmount: string;
                        items: {
                            itemId: string;
                            "productId?": string;
                            "serviceId?": string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                        currency?: undefined;
                    };
                    order?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    "deliveryContact?": {
                        "phone?": string;
                        "email?": string;
                    };
                    "deliveryAddress?": {
                        "addressId?": string;
                        "street?": string;
                        "number?": string;
                        "city?": string;
                        "state?": string;
                        "postalCode?": string;
                    };
                    include?: undefined;
                    changes?: undefined;
                };
                output: {
                    order: {
                        orderId: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                    };
                    cart: {
                        cartId: string;
                        status: string;
                        currency?: undefined;
                        itemsCount?: undefined;
                        subtotalAmount?: undefined;
                        discountAmount?: undefined;
                        totalAmount?: undefined;
                        items?: undefined;
                    };
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/catalogPage.defs" {
    export const catalogPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: ({
                    name: string;
                    type: string;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                } | {
                    name: string;
                    type: string;
                    sources: string[];
                    description: string;
                    entityRef?: undefined;
                    fieldRef?: undefined;
                })[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    categoria: {
                        type: string;
                        required: boolean;
                    };
                    tipo: {
                        type: string;
                        required: boolean;
                    };
                    precoMin: {
                        type: string;
                        required: boolean;
                    };
                    precoMax: {
                        type: string;
                        required: boolean;
                    };
                    page: {
                        type: string;
                        required: boolean;
                    };
                    pageSize: {
                        type: string;
                        required: boolean;
                    };
                };
                output: {
                    items: {
                        type: string;
                        items: {
                            type: string;
                            properties: {
                                itemId: {
                                    type: string;
                                };
                                itemType: {
                                    type: string;
                                    enum: string[];
                                };
                                title: {
                                    type: string;
                                };
                                summary: {
                                    type: string;
                                };
                                price: {
                                    type: string;
                                };
                                status: {
                                    type: string;
                                };
                                categoryTitle: {
                                    type: string;
                                };
                            };
                        };
                    };
                    pagination: {
                        type: string;
                        properties: {
                            page: {
                                type: string;
                            };
                            pageSize: {
                                type: string;
                            };
                            totalItems: {
                                type: string;
                            };
                        };
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: any[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/checkoutPage.defs" {
    export const checkoutPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: string[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                }[];
                navigationRefs: ({
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description?: undefined;
                } | {
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description: string;
                })[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartId: string;
                    deliveryAddress?: undefined;
                    contact?: undefined;
                    orderId?: undefined;
                    paymentIntentId?: undefined;
                    paymentMethod?: undefined;
                    confirmationData?: undefined;
                };
                output: {
                    cartId: string;
                    items: {
                        itemId: string;
                        itemType: string;
                        productId: string;
                        serviceId: string;
                        name: string;
                        quantity: string;
                        unitPrice: string;
                        totalPrice: string;
                    }[];
                    totals: {
                        subtotal: string;
                        discount: string;
                        shipping: string;
                        total: string;
                    };
                    currency: string;
                    orderId?: undefined;
                    orderNumber?: undefined;
                    status?: undefined;
                    paymentStatus?: undefined;
                    orderSummary?: undefined;
                    orderStatus?: undefined;
                    confirmation?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartId: string;
                    deliveryAddress: {
                        street: string;
                        number: string;
                        complement: string;
                        district: string;
                        city: string;
                        state: string;
                        postalCode: string;
                        country: string;
                    };
                    contact: {
                        name: string;
                        email: string;
                        phone: string;
                    };
                    orderId?: undefined;
                    paymentIntentId?: undefined;
                    paymentMethod?: undefined;
                    confirmationData?: undefined;
                };
                output: {
                    orderId: string;
                    orderNumber: string;
                    status: string;
                    paymentStatus: string;
                    orderSummary: {
                        items: {
                            itemId: string;
                            itemType: string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                        totals: {
                            subtotal: string;
                            discount: string;
                            shipping: string;
                            total: string;
                        };
                        currency: string;
                    };
                    cartId?: undefined;
                    items?: undefined;
                    totals?: undefined;
                    currency?: undefined;
                    orderStatus?: undefined;
                    confirmation?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    orderId: string;
                    paymentIntentId: string;
                    paymentMethod: string;
                    confirmationData: {
                        clientSecret: string;
                        returnUrl: string;
                    };
                    cartId?: undefined;
                    deliveryAddress?: undefined;
                    contact?: undefined;
                };
                output: {
                    paymentStatus: string;
                    orderStatus: string;
                    confirmation: {
                        orderId: string;
                        receiptUrl: string;
                        paidAt: string;
                    };
                    cartId?: undefined;
                    items?: undefined;
                    totals?: undefined;
                    currency?: undefined;
                    orderId?: undefined;
                    orderNumber?: undefined;
                    status?: undefined;
                    orderSummary?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/homePage.defs" {
    export const homePagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: any[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    highlightLimits: {
                        type: string;
                        required: boolean;
                        fields: {
                            categories: {
                                type: string;
                            };
                            products: {
                                type: string;
                            };
                            services: {
                                type: string;
                            };
                        };
                    };
                    filters: {
                        type: string;
                        required: boolean;
                        fields: {
                            categoryIds: {
                                type: string;
                            };
                            availabilityStatus: {
                                type: string;
                            };
                            priceRange: {
                                type: string;
                                fields: {
                                    min: {
                                        type: string;
                                    };
                                    max: {
                                        type: string;
                                    };
                                };
                            };
                        };
                    };
                };
                output: {
                    categories: {
                        type: string;
                        items: {
                            categoryId: string;
                            name: string;
                            imageUrl: string;
                        };
                    };
                    items: {
                        type: string;
                        items: {
                            itemType: string;
                            itemId: string;
                            name: string;
                            price: {
                                amount: string;
                                currency: string;
                            };
                            availabilityStatus: string;
                            categoryIds: string;
                            imageUrl: string;
                        };
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: any[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: AuraDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type AuraRegionName = 'header' | 'aside' | 'content';
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface AuraDynamicRegionConfig {
        renderer: AuraRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface AuraShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, AuraDynamicRegionConfig>;
    }
    export interface AuraClientShellConfig {
        mode: AuraShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: AuraShellRegionProfiles;
            aside?: AuraShellRegionProfiles;
        };
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
        clientShell?: AuraClientShellConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: AuraRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: AuraRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102029_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        private dynamicRegionRenderers;
        private dynamicRegionProps;
        private activeAsideWidthPx?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly setHeaderRenderer;
        private readonly setAsideRenderer;
        private readonly setShellProfile;
        private setRegionProfile;
        private setRegionRenderer;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private initializeDynamicRegions;
        private getRegionProfile;
        private getRegionPropsFromProfile;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getAsideWidthPx;
        private getAsideDrawerWidthPx;
        private getRegionProps;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102030_/l2/petShopStripe/index" { }
declare module "_102030_/l2/petShopStripe/module" {
    import type { AuraModuleFrontendDefinition, IPaths, IGenomeConfig } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: Record<string, IGenomeConfig>;
    export const skills: IPaths;
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs" {
    export const pluginStripePagamentosPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginConnectionPlan;
}
declare module "_102030_/l2/petshop/index" { }
declare module "_102030_/l2/petshop/shared/contracts/home" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult } from '_102030_/l1/petshop/module';
    export type PetshopHomeRequest = PetshopHomeLoadParams;
    export interface PetshopHomeResponse extends PetshopHomeLoadResult {
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
}
declare module "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs" {
    export const pluginStripePagamentosPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginPlan;
}
