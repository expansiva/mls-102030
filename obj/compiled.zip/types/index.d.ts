declare module "_102030_/l1/petShopStripe/layer_1_external/cart.defs" {
    export const cartTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "cart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "plan-table-definition:cart";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "cart";
                readonly tableName: "cart";
                readonly moduleId: "petShopStripe";
                readonly title: "Carrinho";
                readonly purpose: "Persistir o carrinho ativo do cliente para checkout.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Cart";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "cart_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do carrinho.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente dono do carrinho.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do carrinho (ativo, convertido, abandonado, expirado).";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Moeda usada para preços do carrinho.";
                }, {
                    readonly name: "items_count";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens no carrinho.";
                }, {
                    readonly name: "subtotal_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Subtotal do carrinho antes de descontos.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Desconto aplicado ao carrinho.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total do carrinho após descontos.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do carrinho.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do carrinho.";
                }, {
                    readonly name: "expires_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data de expiração do carrinho.";
                }, {
                    readonly name: "last_activity_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Última interação no carrinho.";
                }];
                readonly primaryKey: readonly ["cart_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule.persistence.excludeMdmEntities";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_cart_customer_status";
                    readonly columns: readonly ["customer_id", "status"];
                    readonly reason: "rule.index.lookupByCustomerStatus";
                }, {
                    readonly indexName: "idx_cart_updated_at";
                    readonly columns: readonly ["updated_at"];
                    readonly reason: "rule.index.sortByRecentUpdate";
                }, {
                    readonly indexName: "idx_cart_expires_at";
                    readonly columns: readonly ["expires_at"];
                    readonly reason: "rule.index.expirationCleanup";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "CartDetails";
                    readonly reason: "rule.persistence.aggregateWithChildEntities";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/cart.defs.ts";
                readonly exportName: "cartTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default cartTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "plan-table-definition:order";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "petShopStripe";
                readonly title: "Pedido";
                readonly purpose: "Registrar pedidos gerados no checkout e seu ciclo de vida.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "order_number";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Número legível do pedido para referência do cliente e admin.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente responsável pelo pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do ciclo de vida do pedido.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do pagamento associado ao pedido.";
                }, {
                    readonly name: "payment_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao pagamento horizontal.";
                }, {
                    readonly name: "currency";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "BRL";
                    readonly description: "Moeda do pedido.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Valor total do pedido.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de descontos aplicados.";
                }, {
                    readonly name: "shipping_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor de entrega, quando aplicável.";
                }, {
                    readonly name: "scheduled_service_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data e hora do serviço agendado, quando aplicável.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Última atualização do pedido.";
                }, {
                    readonly name: "paid_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora da confirmação de pagamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "ruleOrderRequiresCustomer";
                }, {
                    readonly fieldName: "payment_id";
                    readonly targetEntity: "Payment";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "rulePaymentRequiredToConfirmOrder";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_customer_id_created_at";
                    readonly columns: readonly ["customer_id", "created_at"];
                    readonly unique: false;
                    readonly reason: "Busca de pedidos do cliente por período.";
                }, {
                    readonly indexName: "idx_order_status_created_at";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar pedidos por status no admin.";
                }, {
                    readonly indexName: "idx_order_paid_at";
                    readonly columns: readonly ["paid_at"];
                    readonly unique: false;
                    readonly reason: "Apuração de métricas por data de pagamento.";
                }, {
                    readonly indexName: "idx_order_scheduled_service_at";
                    readonly columns: readonly ["scheduled_service_at"];
                    readonly unique: false;
                    readonly reason: "Agenda de serviços.";
                }, {
                    readonly indexName: "idx_order_order_number";
                    readonly columns: readonly ["order_number"];
                    readonly unique: true;
                    readonly reason: "Consulta rápida por número do pedido.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderDetails";
                    readonly reason: "Armazenar itens do pedido e dados auxiliares do checkout.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["metricTableSalesOps"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "ruleOrderStatusLifecycle", "rulePaymentRequiredToConfirmOrder"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/salesOpsMetrics.defs" {
    export const salesOpsMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "salesOpsMetrics";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 53;
            readonly planId: "plan-metric-table-definition:salesOpsMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "salesOpsMetrics";
                readonly tableName: "sales_ops_metrics";
                readonly moduleId: "petShopStripe";
                readonly title: "Métricas de vendas e pagamentos";
                readonly purpose: "Agregar dados de pedidos e pagamentos para análise de receita, ticket médio, volume de pedidos e taxa de aprovação.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento agregado.";
                }, {
                    readonly name: "order_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pedido no momento do evento.";
                }, {
                    readonly name: "payment_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status do pagamento associado.";
                }, {
                    readonly name: "item_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo do item vendido (produto ou serviço).";
                }, {
                    readonly name: "order_total";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total dos pedidos.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "approved_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pagamentos aprovados.";
                }, {
                    readonly name: "canceled_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos cancelados.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderStatus";
                    readonly column: "order_status";
                    readonly type: "text";
                    readonly description: "Status do pedido no momento do evento";
                }, {
                    readonly dimensionId: "paymentStatus";
                    readonly column: "payment_status";
                    readonly type: "text";
                    readonly description: "Status do pagamento associado";
                }, {
                    readonly dimensionId: "itemType";
                    readonly column: "item_type";
                    readonly type: "text";
                    readonly description: "Tipo do item vendido (produto ou serviço)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "order_total";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total dos pedidos";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "order_total";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio dos pedidos";
                }, {
                    readonly measureId: "approvedPayments";
                    readonly column: "approved_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pagamentos aprovados";
                }, {
                    readonly measureId: "canceledOrders";
                    readonly column: "canceled_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos cancelados";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderPaid", "orderCanceled", "serviceBookingCreated", "serviceBookingConfirmed"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "90 days";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_sales_ops_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consulta temporal de métricas.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_order_status_time";
                        readonly columns: readonly ["order_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pedido e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_payment_status_time";
                        readonly columns: readonly ["payment_status", "event_time"];
                        readonly purpose: "Filtrar métricas por status do pagamento e período.";
                    }, {
                        readonly indexName: "idx_sales_ops_metrics_item_type_time";
                        readonly columns: readonly ["item_type", "event_time"];
                        readonly purpose: "Filtrar métricas por tipo de item e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseUpdateMetricsOnOrderPaid"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesOpsMetrics.defs.ts";
                readonly exportName: "salesOpsMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesOpsMetricsMetricTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_1_external/serviceBooking.defs" {
    export const serviceBookingTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "serviceBooking";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "plan-table-definition:serviceBooking";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "serviceBooking";
                readonly tableName: "service_booking";
                readonly moduleId: "petShopStripe";
                readonly title: "Agendamento de serviço";
                readonly purpose: "Controlar reservas de data e horário para serviços do pet shop.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ServiceBooking";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "service_booking_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do agendamento de serviço.";
                }, {
                    readonly name: "service_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Serviço reservado no agendamento.";
                }, {
                    readonly name: "customer_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Cliente que realizou o agendamento.";
                }, {
                    readonly name: "pet_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pet associado ao serviço.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido associado ao agendamento.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do agendamento (ex.: pendente, confirmado, concluído, cancelado).";
                }, {
                    readonly name: "scheduled_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data do agendamento.";
                }, {
                    readonly name: "scheduled_start_time";
                    readonly type: "time";
                    readonly nullable: false;
                    readonly description: "Horário de início do agendamento.";
                }, {
                    readonly name: "scheduled_end_time";
                    readonly type: "time";
                    readonly nullable: true;
                    readonly description: "Horário de término previsto do agendamento.";
                }, {
                    readonly name: "timezone";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Fuso horário do agendamento.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações do cliente ou do pet shop.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do agendamento.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora da última atualização do agendamento.";
                }, {
                    readonly name: "canceled_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data/hora de cancelamento do agendamento.";
                }];
                readonly primaryKey: readonly ["service_booking_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_id";
                    readonly targetEntity: "Service";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Serviço agendado.";
                }, {
                    readonly fieldName: "customer_id";
                    readonly targetEntity: "Customer";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Cliente responsável pelo agendamento.";
                }, {
                    readonly fieldName: "pet_id";
                    readonly targetEntity: "Pet";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Pet atendido no agendamento.";
                }, {
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular o agendamento ao pedido.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_service_booking_customer";
                    readonly columns: readonly ["customer_id", "scheduled_date"];
                    readonly reason: "Listagem de agendamentos por cliente e data.";
                }, {
                    readonly indexName: "idx_service_booking_pet";
                    readonly columns: readonly ["pet_id", "scheduled_date"];
                    readonly reason: "Consultas de agendamentos por pet.";
                }, {
                    readonly indexName: "idx_service_booking_service_date";
                    readonly columns: readonly ["service_id", "scheduled_date"];
                    readonly reason: "Consulta de agendamentos por serviço e data.";
                }, {
                    readonly indexName: "idx_service_booking_order";
                    readonly columns: readonly ["order_id"];
                    readonly reason: "Localizar agendamento pelo pedido.";
                }, {
                    readonly indexName: "idx_service_booking_status_date";
                    readonly columns: readonly ["status", "scheduled_date"];
                    readonly reason: "Filtros de status e agenda.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceBooking.defs.ts";
                readonly exportName: "serviceBookingTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceBookingTableDefinition;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseAddToCart.defs" {
    export const usecaseAddToCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseAddToCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseAddToCart";
                readonly title: "Adicionar item ao carrinho";
                readonly purpose: "Adicionar produto ou serviço ao carrinho do cliente e recalcular totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["addToCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseAddToCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseConfirmStripePayment.defs" {
    export const usecaseConfirmStripePaymentUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseConfirmStripePayment";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseConfirmStripePayment";
                readonly title: "Confirmar pagamento Stripe";
                readonly purpose: "Atualizar status do pedido após confirmação de pagamento e registrar métricas.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "salesOpsMetrics"];
                readonly commands: readonly ["confirmStripePayment"];
                readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseConfirmStripePaymentUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseCreateOrder.defs" {
    export const usecaseCreateOrderUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseCreateOrder";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseCreateOrder";
                readonly title: "Criar pedido";
                readonly purpose: "Gerar pedido a partir do carrinho confirmado e marcar carrinho como convertido.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["order", "cart"];
                readonly commands: readonly ["startCheckout"];
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            };
        };
    };
    export default usecaseCreateOrderUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetCart.defs" {
    export const usecaseGetCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetCart";
                readonly title: "Consultar carrinho";
                readonly purpose: "Carregar o carrinho ativo do cliente com itens e totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetMetricsDashboard.defs" {
    export const usecaseGetMetricsDashboardUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetMetricsDashboard";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetMetricsDashboard";
                readonly title: "Consultar métricas de vendas";
                readonly purpose: "Obter séries temporais de métricas de vendas e pagamentos para dashboard.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetMetricsDashboardUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderAdminList.defs" {
    export const usecaseGetOrderAdminListUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderAdminList";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderAdminList";
                readonly title: "Listar pedidos administrativos";
                readonly purpose: "Listar pedidos por status e período para gestão administrativa.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderAdminListUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetOrderHistory.defs" {
    export const usecaseGetOrderHistoryUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetOrderHistory";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetOrderHistory";
                readonly title: "Listar pedidos do cliente";
                readonly purpose: "Listar pedidos do cliente para acompanhamento de histórico.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetOrderHistoryUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseGetServiceBookings.defs" {
    export const usecaseGetServiceBookingsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGetServiceBookings";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGetServiceBookings";
                readonly title: "Listar agendamentos";
                readonly purpose: "Consultar agendamentos por cliente, pet ou serviço.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate"];
                readonly readsTables: readonly ["serviceBooking"];
                readonly writesTables: readonly [];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseGetServiceBookingsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseManageCatalog.defs" {
    export const usecaseManageCatalogUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseManageCatalog";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseManageCatalog";
                readonly title: "Gerenciar catálogo";
                readonly purpose: "Cadastrar, editar ou desativar produtos e serviços, preços e disponibilidade.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["catalogAggregate"];
                readonly outputEntities: readonly ["catalogAggregate"];
                readonly readsTables: readonly ["product", "service", "catalogCategory"];
                readonly writesTables: readonly ["product", "service", "catalogCategory"];
                readonly commands: readonly ["manageCatalog"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseManageCatalogUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseReconcilePayments.defs" {
    export const usecaseReconcilePaymentsUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseReconcilePayments";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseReconcilePayments";
                readonly title: "Conciliar recebíveis";
                readonly purpose: "Registrar conciliação de pagamentos aprovados e lançar recebíveis.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["receivableAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["receivableAggregate"];
                readonly readsTables: readonly ["order", "payment", "stripeTransaction"];
                readonly writesTables: readonly ["receivable", "financialEntry"];
                readonly commands: readonly ["reconcilePayments"];
                readonly rulesApplied: readonly ["ruleReceivableFromPayment"];
            };
        };
    };
    export default usecaseReconcilePaymentsUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseScheduleService.defs" {
    export const usecaseScheduleServiceUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseScheduleService";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseScheduleService";
                readonly title: "Agendar serviço";
                readonly purpose: "Criar agendamento de serviço e vincular ao pedido quando aplicável.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly outputEntities: readonly ["serviceBookingAggregate", "orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["serviceBooking", "order"];
                readonly commands: readonly ["scheduleService"];
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            };
        };
    };
    export default usecaseScheduleServiceUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateCart.defs" {
    export const usecaseUpdateCartUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateCart";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateCart";
                readonly title: "Atualizar carrinho";
                readonly purpose: "Alterar quantidades ou remover itens do carrinho e atualizar totais.";
                readonly actor: "cliente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["cartAggregate"];
                readonly outputEntities: readonly ["cartAggregate"];
                readonly readsTables: readonly ["cart"];
                readonly writesTables: readonly ["cart"];
                readonly commands: readonly ["updateCart"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default usecaseUpdateCartUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateMetricsOnOrderPaid.defs" {
    export const usecaseUpdateMetricsOnOrderPaidUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateMetricsOnOrderPaid";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateMetricsOnOrderPaid";
                readonly title: "Atualizar métricas de vendas";
                readonly purpose: "Atualizar métricas operacionais quando pedidos são pagos ou cancelados.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate", "salesOpsMetricsAggregate"];
                readonly outputEntities: readonly ["salesOpsMetricsAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["salesOpsMetrics"];
                readonly commands: readonly [];
                readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
            };
        };
    };
    export default usecaseUpdateMetricsOnOrderPaidUsecasePlan;
}
declare module "_102030_/l1/petShopStripe/layer_3_usecases/usecaseUpdateOrderStatus.defs" {
    export const usecaseUpdateOrderStatusUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseUpdateOrderStatus";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 61;
            readonly planId: "plan-index-critic:usecasePlan:2";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "cleanArchitecture";
                readonly layer2Responsibility: "Orquestrar requisições dos BFF/controllers e chamar casos de uso sem acesso direto a tabelas.";
                readonly layer3Responsibility: "Executar regras de negócio, ler/escrever tabelas layer_1_external e atualizar métricas.";
                readonly layer1Responsibility: "Persistência de dados transacionais e métricas acessíveis apenas por casos de uso.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseUpdateOrderStatus";
                readonly title: "Atualizar status do pedido";
                readonly purpose: "Alterar status do pedido conforme ciclo de vida.";
                readonly actor: "adminPetShop";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregate"];
                readonly outputEntities: readonly ["orderAggregate"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly commands: readonly ["updateOrderStatus"];
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
            };
        };
    };
    export default usecaseUpdateOrderStatusUsecasePlan;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102030_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102030_/l2/project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
        layouts: {
            1: {
                name: string;
                skill: string;
            };
        };
        designSystems: {
            1: {
                name: string;
                skill: string;
            };
        };
    };
}
declare module "_102030_/l2/petShopStripe/accountOrdersPage.defs" {
    export const accountOrdersPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: string[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    customerId: string;
                    filters: {
                        orderStatus: string;
                        startDate: string;
                        endDate: string;
                        bookingStatus?: undefined;
                    };
                };
                output: {
                    orders: {
                        orderId: string;
                        orderNumber: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                        createdAt: string;
                        items: {
                            itemType: string;
                            itemId: string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                        }[];
                    }[];
                    bookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    customerId: string;
                    filters: {
                        bookingStatus: string;
                        startDate: string;
                        endDate: string;
                        orderStatus?: undefined;
                    };
                };
                output: {
                    bookings: {
                        serviceBookingId: string;
                        status: string;
                        scheduledDate: string;
                        scheduledStartTime: string;
                        scheduledEndTime: string;
                        timezone: string;
                        service: {
                            serviceId: string;
                            name: string;
                        };
                        pet: {
                            petId: string;
                            name: string;
                        };
                    }[];
                    orders?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/adminCatalogPage.defs" {
    export const adminCatalogPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    itemType: string;
                    statusFilter: string;
                    categoryId: string;
                    searchText: string;
                    page: string;
                    pageSize: string;
                    action?: undefined;
                    itemId?: undefined;
                    payload?: undefined;
                };
                output: {
                    items: {
                        itemId: string;
                        itemType: string;
                        name: string;
                        categoryId: string;
                        categoryName: string;
                        price: string;
                        status: string;
                        updatedAt: string;
                    }[];
                    pagination: {
                        page: string;
                        pageSize: string;
                        totalItems: string;
                        totalPages: string;
                    };
                    itemId?: undefined;
                    itemType?: undefined;
                    status?: undefined;
                    updatedAt?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    action: string;
                    itemType: string;
                    itemId: string;
                    payload: {
                        name: string;
                        description: string;
                        price: string;
                        duration: string;
                        status: string;
                        categoryId: string;
                    };
                    statusFilter?: undefined;
                    categoryId?: undefined;
                    searchText?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                };
                output: {
                    itemId: string;
                    itemType: string;
                    status: string;
                    updatedAt: string;
                    items?: undefined;
                    pagination?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/adminDashboardPage.defs" {
    export const adminDashboardPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminDashboardPage";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 90;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminDashboardPage";
                readonly pageName: "Dashboard administrativo";
                readonly actor: "adminPetShop";
                readonly purpose: "Fornecer visão geral de pedidos, agenda e indicadores rápidos.";
                readonly capabilities: readonly ["manageOrdersServices", "financialOverview", "metricsDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycleManagement"];
                    readonly taskWorkflows: readonly ["serviceBooking", "paymentReconciliation"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["organization"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Intervalo de datas para filtrar KPIs, pedidos e agenda.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminOrdersPage";
                    readonly trigger: "Gerenciar pedidos";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminFinancialPage";
                    readonly trigger: "Ver financeiro";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "adminMetricsPage";
                    readonly trigger: "Ver métricas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo operacional";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "kpiSummaryCards";
                        readonly purpose: "Exibir KPIs de pedidos e agenda no período.";
                        readonly userActions: readonly ["Ver resumo operacional"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.status", "ServiceBooking.scheduled_date"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "operationalQueues";
                        readonly purpose: "Mostrar filas de pedidos por status e próximos agendamentos.";
                        readonly userActions: readonly ["Ver resumo operacional", "Acessar gestão de pedidos"];
                        readonly requiredEntities: readonly ["Order", "ServiceBooking"];
                        readonly readsFields: readonly ["Order.order_number", "Order.status", "Order.payment_status", "Order.total_amount", "Order.created_at", "ServiceBooking.service_id", "ServiceBooking.status", "ServiceBooking.scheduled_date", "ServiceBooking.scheduled_start_time"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Indicadores rápidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsSummaryWidget";
                        readonly purpose: "Apresentar resumo das métricas de vendas e pagamentos.";
                        readonly userActions: readonly ["Acessar métricas"];
                        readonly requiredEntities: readonly ["salesOpsMetrics"];
                        readonly readsFields: readonly ["salesOpsMetrics.totalRevenue", "salesOpsMetrics.orderCount", "salesOpsMetrics.approvedPayments", "salesOpsMetrics.canceledOrders"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAdminOverview";
                readonly purpose: "Carregar KPIs resumidos e filas operacionais.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly orderCountsByStatus: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly paymentStatusCounts: readonly [{
                        readonly status: "string";
                        readonly count: "number";
                    }];
                    readonly recentOrders: readonly [{
                        readonly orderId: "string";
                        readonly orderNumber: "string";
                        readonly status: "string";
                        readonly paymentStatus: "string";
                        readonly totalAmount: "number";
                        readonly createdAt: "string";
                    }];
                    readonly upcomingBookings: readonly [{
                        readonly serviceBookingId: "string";
                        readonly serviceId: "string";
                        readonly status: "string";
                        readonly scheduledDate: "string";
                        readonly scheduledStartTime: "string";
                    }];
                };
                readonly readsEntities: readonly ["Order", "ServiceBooking"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "serviceBooking"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetOrderAdminList", "usecaseGetServiceBookings"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getMetricsSummary";
                readonly purpose: "Obter resumo das métricas de vendas para o painel.";
                readonly kind: "query";
                readonly input: {
                    readonly dateFrom: "string";
                    readonly dateTo: "string";
                };
                readonly output: {
                    readonly totalRevenue: "number";
                    readonly orderCount: "number";
                    readonly approvedPayments: "number";
                    readonly canceledOrders: "number";
                    readonly averageTicket: "number";
                };
                readonly readsEntities: readonly ["salesOpsMetrics"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["salesOpsMetrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGetMetricsDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default adminDashboardPagePagePlan;
}
declare module "_102030_/l2/petShopStripe/adminMetricsPage.defs" {
    export const adminMetricsPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                }[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    dateRange: {
                        from: string;
                        to: string;
                    };
                    filters: {
                        orderStatus: string[];
                        paymentStatus: string[];
                        itemType: string[];
                    };
                    granularity: string;
                };
                output: {
                    series: {
                        revenue: {
                            timestamp: string;
                            value: string;
                        }[];
                        orders: {
                            timestamp: string;
                            value: string;
                        }[];
                        averageTicket: {
                            timestamp: string;
                            value: string;
                        }[];
                        approvalRate: {
                            timestamp: string;
                            value: string;
                        }[];
                        canceledOrders: {
                            timestamp: string;
                            value: string;
                        }[];
                    };
                    aggregations: {
                        totalRevenue: string;
                        orderCount: string;
                        averageTicket: string;
                        approvedPayments: string;
                        canceledOrders: string;
                    };
                    dimensions: {
                        orderStatus: string[];
                        paymentStatus: string[];
                        itemType: string[];
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/adminOrdersPage.defs" {
    export const adminOrdersPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: string[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: ({
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef?: undefined;
                    fieldRef?: undefined;
                } | {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                })[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    statusFilter: string;
                    periodStart: string;
                    periodEnd: string;
                    orderNumber: string;
                    page: string;
                    pageSize: string;
                    orderId?: undefined;
                    newStatus?: undefined;
                    statusReason?: undefined;
                    serviceDate?: undefined;
                    serviceId?: undefined;
                    status?: undefined;
                };
                output: {
                    orders: {
                        orderId: string;
                        orderNumber: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                        createdAt: string;
                        updatedAt: string;
                    }[];
                    page: string;
                    pageSize: string;
                    total: string;
                    orderId?: undefined;
                    status?: undefined;
                    statusHistory?: undefined;
                    updatedAt?: undefined;
                    serviceBookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    orderId: string;
                    newStatus: string;
                    statusReason: string;
                    statusFilter?: undefined;
                    periodStart?: undefined;
                    periodEnd?: undefined;
                    orderNumber?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                    serviceDate?: undefined;
                    serviceId?: undefined;
                    status?: undefined;
                };
                output: {
                    orderId: string;
                    status: string;
                    statusHistory: {
                        fromStatus: string;
                        toStatus: string;
                        changedAt: string;
                        changedBy: string;
                    }[];
                    updatedAt: string;
                    orders?: undefined;
                    page?: undefined;
                    pageSize?: undefined;
                    total?: undefined;
                    serviceBookings?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    serviceDate: string;
                    serviceId: string;
                    status: string;
                    page: string;
                    pageSize: string;
                    statusFilter?: undefined;
                    periodStart?: undefined;
                    periodEnd?: undefined;
                    orderNumber?: undefined;
                    orderId?: undefined;
                    newStatus?: undefined;
                    statusReason?: undefined;
                };
                output: {
                    serviceBookings: {
                        serviceBookingId: string;
                        serviceId: string;
                        serviceName: string;
                        customerId: string;
                        customerName: string;
                        petId: string;
                        petName: string;
                        status: string;
                        scheduledDate: string;
                        scheduledStartTime: string;
                        scheduledEndTime: string;
                        orderId: string;
                    }[];
                    page: string;
                    pageSize: string;
                    total: string;
                    orders?: undefined;
                    orderId?: undefined;
                    status?: undefined;
                    statusHistory?: undefined;
                    updatedAt?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/cartPage.defs" {
    export const cartPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: any[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    include: {
                        items: string;
                        totals: string;
                    };
                    changes?: undefined;
                    "deliveryContact?"?: undefined;
                    "deliveryAddress?"?: undefined;
                };
                output: {
                    cart: {
                        cartId: string;
                        status: string;
                        currency: string;
                        itemsCount: string;
                        subtotalAmount: string;
                        discountAmount: string;
                        totalAmount: string;
                        items: {
                            itemId: string;
                            "productId?": string;
                            "serviceId?": string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                    };
                    order?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    changes: {
                        items: {
                            "itemId?": string;
                            "productId?": string;
                            "serviceId?": string;
                            "quantity?": string;
                            action: string;
                        }[];
                    };
                    include?: undefined;
                    "deliveryContact?"?: undefined;
                    "deliveryAddress?"?: undefined;
                };
                output: {
                    cart: {
                        cartId: string;
                        status: string;
                        itemsCount: string;
                        subtotalAmount: string;
                        discountAmount: string;
                        totalAmount: string;
                        items: {
                            itemId: string;
                            "productId?": string;
                            "serviceId?": string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                        currency?: undefined;
                    };
                    order?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartContext: {
                        "cartId?": string;
                    };
                    "deliveryContact?": {
                        "phone?": string;
                        "email?": string;
                    };
                    "deliveryAddress?": {
                        "addressId?": string;
                        "street?": string;
                        "number?": string;
                        "city?": string;
                        "state?": string;
                        "postalCode?": string;
                    };
                    include?: undefined;
                    changes?: undefined;
                };
                output: {
                    order: {
                        orderId: string;
                        status: string;
                        paymentStatus: string;
                        totalAmount: string;
                    };
                    cart: {
                        cartId: string;
                        status: string;
                        currency?: undefined;
                        itemsCount?: undefined;
                        subtotalAmount?: undefined;
                        discountAmount?: undefined;
                        totalAmount?: undefined;
                        items?: undefined;
                    };
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/catalogPage.defs" {
    export const catalogPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: ({
                    name: string;
                    type: string;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                } | {
                    name: string;
                    type: string;
                    sources: string[];
                    description: string;
                    entityRef?: undefined;
                    fieldRef?: undefined;
                })[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    categoria: {
                        type: string;
                        required: boolean;
                    };
                    tipo: {
                        type: string;
                        required: boolean;
                    };
                    precoMin: {
                        type: string;
                        required: boolean;
                    };
                    precoMax: {
                        type: string;
                        required: boolean;
                    };
                    page: {
                        type: string;
                        required: boolean;
                    };
                    pageSize: {
                        type: string;
                        required: boolean;
                    };
                };
                output: {
                    items: {
                        type: string;
                        items: {
                            type: string;
                            properties: {
                                itemId: {
                                    type: string;
                                };
                                itemType: {
                                    type: string;
                                    enum: string[];
                                };
                                title: {
                                    type: string;
                                };
                                summary: {
                                    type: string;
                                };
                                price: {
                                    type: string;
                                };
                                status: {
                                    type: string;
                                };
                                categoryTitle: {
                                    type: string;
                                };
                            };
                        };
                    };
                    pagination: {
                        type: string;
                        properties: {
                            page: {
                                type: string;
                            };
                            pageSize: {
                                type: string;
                            };
                            totalItems: {
                                type: string;
                            };
                        };
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: any[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/checkoutPage.defs" {
    export const checkoutPagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: string[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: string[];
                mdmRefs: string[];
                pageInputs: {
                    name: string;
                    type: string;
                    required: boolean;
                    sources: string[];
                    description: string;
                    entityRef: string;
                    fieldRef: string;
                }[];
                navigationRefs: ({
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description?: undefined;
                } | {
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description: string;
                })[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: string[];
                        rulesApplied: string[];
                    }[];
                }[];
            };
            bffCommands: ({
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartId: string;
                    deliveryAddress?: undefined;
                    contact?: undefined;
                    orderId?: undefined;
                    paymentIntentId?: undefined;
                    paymentMethod?: undefined;
                    confirmationData?: undefined;
                };
                output: {
                    cartId: string;
                    items: {
                        itemId: string;
                        itemType: string;
                        productId: string;
                        serviceId: string;
                        name: string;
                        quantity: string;
                        unitPrice: string;
                        totalPrice: string;
                    }[];
                    totals: {
                        subtotal: string;
                        discount: string;
                        shipping: string;
                        total: string;
                    };
                    currency: string;
                    orderId?: undefined;
                    orderNumber?: undefined;
                    status?: undefined;
                    paymentStatus?: undefined;
                    orderSummary?: undefined;
                    orderStatus?: undefined;
                    confirmation?: undefined;
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: string[];
                writesTables: any[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    cartId: string;
                    deliveryAddress: {
                        street: string;
                        number: string;
                        complement: string;
                        district: string;
                        city: string;
                        state: string;
                        postalCode: string;
                        country: string;
                    };
                    contact: {
                        name: string;
                        email: string;
                        phone: string;
                    };
                    orderId?: undefined;
                    paymentIntentId?: undefined;
                    paymentMethod?: undefined;
                    confirmationData?: undefined;
                };
                output: {
                    orderId: string;
                    orderNumber: string;
                    status: string;
                    paymentStatus: string;
                    orderSummary: {
                        items: {
                            itemId: string;
                            itemType: string;
                            name: string;
                            quantity: string;
                            unitPrice: string;
                            totalPrice: string;
                        }[];
                        totals: {
                            subtotal: string;
                            discount: string;
                            shipping: string;
                            total: string;
                        };
                        currency: string;
                    };
                    cartId?: undefined;
                    items?: undefined;
                    totals?: undefined;
                    currency?: undefined;
                    orderStatus?: undefined;
                    confirmation?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            } | {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    orderId: string;
                    paymentIntentId: string;
                    paymentMethod: string;
                    confirmationData: {
                        clientSecret: string;
                        returnUrl: string;
                    };
                    cartId?: undefined;
                    deliveryAddress?: undefined;
                    contact?: undefined;
                };
                output: {
                    paymentStatus: string;
                    orderStatus: string;
                    confirmation: {
                        orderId: string;
                        receiptUrl: string;
                        paidAt: string;
                    };
                    cartId?: undefined;
                    items?: undefined;
                    totals?: undefined;
                    currency?: undefined;
                    orderId?: undefined;
                    orderNumber?: undefined;
                    status?: undefined;
                    orderSummary?: undefined;
                };
                readsEntities: string[];
                writesEntities: string[];
                readsTables: string[];
                writesTables: string[];
                usecaseRefs: string[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: string[];
            })[];
        };
    };
}
declare module "_102030_/l2/petShopStripe/homePage.defs" {
    export const homePagePagePlan: {
        schemaVersion: string;
        artifactType: string;
        artifactId: string;
        moduleName: string;
        status: string;
        source: {
            agentName: string;
            stepId: number;
            planId: string;
        };
        data: {
            pageDefinition: {
                pageId: string;
                pageName: string;
                actor: string;
                purpose: string;
                capabilities: string[];
                flowRefs: {
                    experienceFlows: any[];
                    entityLifecycles: any[];
                    taskWorkflows: any[];
                    automations: any[];
                };
                pluginRefs: any[];
                mdmRefs: string[];
                pageInputs: any[];
                navigationRefs: {
                    direction: string;
                    pageId: string;
                    trigger: string;
                    description: string;
                }[];
                sections: {
                    sectionName: string;
                    mode: string;
                    organisms: {
                        organismName: string;
                        purpose: string;
                        userActions: string[];
                        requiredEntities: string[];
                        readsFields: string[];
                        writesFields: any[];
                        rulesApplied: any[];
                    }[];
                }[];
            };
            bffCommands: {
                commandName: string;
                purpose: string;
                kind: string;
                input: {
                    highlightLimits: {
                        type: string;
                        required: boolean;
                        fields: {
                            categories: {
                                type: string;
                            };
                            products: {
                                type: string;
                            };
                            services: {
                                type: string;
                            };
                        };
                    };
                    filters: {
                        type: string;
                        required: boolean;
                        fields: {
                            categoryIds: {
                                type: string;
                            };
                            availabilityStatus: {
                                type: string;
                            };
                            priceRange: {
                                type: string;
                                fields: {
                                    min: {
                                        type: string;
                                    };
                                    max: {
                                        type: string;
                                    };
                                };
                            };
                        };
                    };
                };
                output: {
                    categories: {
                        type: string;
                        items: {
                            categoryId: string;
                            name: string;
                            imageUrl: string;
                        };
                    };
                    items: {
                        type: string;
                        items: {
                            itemType: string;
                            itemId: string;
                            name: string;
                            price: {
                                amount: string;
                                currency: string;
                            };
                            availabilityStatus: string;
                            categoryIds: string;
                            imageUrl: string;
                        };
                    };
                };
                readsEntities: string[];
                writesEntities: any[];
                readsTables: any[];
                writesTables: any[];
                usecaseRefs: any[];
                layerContract: {
                    controllerLayer: string;
                    mustCallLayer: string;
                    directTableAccessForbidden: boolean;
                };
                rulesApplied: any[];
            }[];
        };
    };
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102033_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102033_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: MasterFrontendRouteDefinition[], pathname: string): MasterFrontendRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { MasterFrontendBootConfig, MasterFrontendDeviceKind, MasterFrontendInteractionState, MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: MasterFrontendInteractionState;
        resolvedDevice: MasterFrontendDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: MasterFrontendRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        private dynamicRegionRenderers;
        private dynamicRegionProps;
        private activeAsideWidthPx?;
        private contentVariantRenderer?;
        private sitesRetryTimer?;
        private sitesRetriesLeft;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly setHeaderRenderer;
        private readonly setAsideRenderer;
        private readonly setShellProfile;
        private setRegionProfile;
        private setRegionRenderer;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private initializeDynamicRegions;
        private getRegionProfile;
        private getRegionPropsFromProfile;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getAsideWidthPx;
        private getAsideDrawerWidthPx;
        private getRegionProps;
        private getActiveContentRenderer;
        private getAvailableUxLayouts;
        private rotateContentVariant;
        private readonly registerSitesControls;
        private getRegionProfileNames;
        private getRegionIndex;
        private setRegionByIndex;
        private getContentPageGenome;
        private setContentPage;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102030_/l2/petShopStripe/index" { }
declare module "_102030_/l2/petShopStripe/module" {
    import type { AuraModuleFrontendDefinition, IPaths, IGenomeConfig } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: Record<string, IGenomeConfig>;
    export const skills: IPaths;
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs" {
    export const pluginStripePagamentosPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginConnectionPlan;
}
declare module "_102030_/l2/petshop/index" { }
declare module "_102030_/l2/petshop/shared/contracts/home" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult } from '_102030_/l1/petshop/module';
    export type PetshopHomeRequest = PetshopHomeLoadParams;
    export interface PetshopHomeResponse extends PetshopHomeLoadResult {
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
}
declare module "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs" {
    export const pluginStripePagamentosPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "pluginStripePagamentos";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginStripePagamentos";
                readonly provider: "Plugin Stripe Pagamentos";
                readonly priority: "now";
                readonly reason: "Pagamento online é requisito do MVP com checkout via Stripe no Brasil.";
                readonly events: readonly ["checkout.payment_created", "checkout.payment_confirmed", "checkout.payment_failed", "payout.reconciled"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["pedido", "valor", "moeda", "metodoPagamento", "dadosCliente"];
                readonly outputData: readonly ["paymentIntentId", "statusPagamento", "taxas", "recebiveis"];
                readonly webhooks: readonly ["payment_intent.succeeded", "payment_intent.payment_failed", "charge.refunded", "payout.paid"];
                readonly risks: readonly ["Dependência de configuração correta de métodos de pagamento brasileiros (PIX/boleto) para evitar falhas no checkout."];
                readonly questions: readonly ["Quais métodos de pagamento Stripe devem ser habilitados no MVP (cartão, PIX, boleto)?", "Precisamos registrar webhooks Stripe em um endpoint específico já definido?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102030_/l2/plugins/pluginStripePagamentos/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102030_/l2/petShopStripe/plugins/pluginStripePagamentos.defs.ts";
            };
        };
    };
    export default pluginStripePagamentosPluginPlan;
}
declare module "_102030_/l4/workflows/cancelamentoReembolso.defs" {
    export const cancelamentoReembolsoDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "cancelamentoReembolso";
        readonly moduleName: "petShopBrasil";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "cancelamentoReembolso";
                readonly title: "Cancelamento e reembolso";
                readonly purpose: "Processar solicitações de cancelamento e reembolso de pedidos pagos, integrando com Stripe para devolução e atualizando status do pedido e métricas financeiras.";
                readonly executionMode: "taskWorkflow";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Processar cancelamento e reembolso do pedido {{pedidoId}}";
                    readonly assigneeRules: readonly ["rule-acesso-admin"];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["administrador"];
                readonly states: readonly [{
                    readonly stateId: "requestLogged";
                    readonly description: "Solicitação de cancelamento registrada e aguardando análise administrativa.";
                }, {
                    readonly stateId: "refundInitiated";
                    readonly description: "Cancelamento aprovado e reembolso iniciado na Stripe.";
                }, {
                    readonly stateId: "refundCompleted";
                    readonly description: "Reembolso confirmado e pedido marcado como reembolsado.";
                }, {
                    readonly stateId: "refundFailed";
                    readonly description: "Falha no reembolso; precisa de intervenção administrativa.";
                }];
                readonly transitions: readonly [{
                    readonly from: "requestLogged";
                    readonly to: "refundInitiated";
                    readonly trigger: "approveCancellation";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["rule-acesso-admin", "rule-status-pedido"];
                    readonly actions: readonly ["pedido.status=cancelado", "pedido.canceledAt=now", "pedido.updatedAt=now"];
                    readonly rulesApplied: readonly ["rule-acesso-admin", "rule-status-pedido"];
                }, {
                    readonly from: "refundInitiated";
                    readonly to: "refundCompleted";
                    readonly trigger: "confirmStripeRefund";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["rule-confirmacao-stripe", "rule-status-pedido"];
                    readonly actions: readonly ["pedido.status=reembolsado", "pedido.refundedAt=now", "pedido.updatedAt=now"];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-status-pedido", "rule-acesso-admin"];
                }, {
                    readonly from: "refundInitiated";
                    readonly to: "refundFailed";
                    readonly trigger: "stripeRefundFailed";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["rule-confirmacao-stripe"];
                    readonly actions: readonly ["pedido.updatedAt=now"];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }];
                readonly requiredEntities: readonly ["Pedido", "Pagamento", "TransacaoFinanceira"];
                readonly persistenceRefs: readonly ["pedido"];
                readonly usecaseRefs: readonly ["reembolsarPagamento", "atualizarStatusPedido"];
                readonly metricRefs: readonly ["dailySalesMetrics"];
                readonly userActions: readonly ["atualizarStatusPedido"];
                readonly relatedPages: readonly ["adminPedidos", "adminFinanceiro"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly ["stripePagamentos"];
                readonly rulesApplied: readonly ["rule-status-pedido", "rule-confirmacao-stripe", "rule-acesso-admin"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "sugReembolsoParcial";
                    readonly title: "Suporte a reembolso parcial futuro";
                    readonly priority: "later";
                    readonly description: "Começar com reembolso total, mas estruturar dados e UI para permitir reembolso parcial de itens no futuro.";
                    readonly tradeoff: "Aumenta a complexidade de cálculo e validações quando for implementado.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/cancelamentoReembolso.defs.ts";
                readonly exportName: "cancelamentoReembolsoDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default cancelamentoReembolsoDef;
}
declare module "_102030_/l4/workflows/carrinhoLifecycle.defs" {
    export const carrinhoLifecycleDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "carrinhoLifecycle";
        readonly moduleName: "petShopBrasil";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "carrinhoLifecycle";
                readonly title: "Ciclo de vida do carrinho";
                readonly purpose: "Gerenciar estados do carrinho do cliente desde a criação até a conversão em pedido, abandono ou expiração automática.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["cliente"];
                readonly states: readonly [{
                    readonly stateId: "ativo";
                    readonly description: "Carrinho ativo e editável pelo cliente.";
                }, {
                    readonly stateId: "abandonado";
                    readonly description: "Carrinho sem atividade por período relevante, aguardando expiração.";
                }, {
                    readonly stateId: "expirado";
                    readonly description: "Carrinho expirado por inatividade e não mais editável.";
                }, {
                    readonly stateId: "convertido";
                    readonly description: "Carrinho convertido em pedido no checkout.";
                }];
                readonly transitions: readonly [{
                    readonly from: "ativo";
                    readonly to: "ativo";
                    readonly trigger: "adicionarItem";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["carrinho.status=ativo", "carrinho.atualizado_em=now()"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "ativo";
                    readonly to: "ativo";
                    readonly trigger: "atualizarItem";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["carrinho.status=ativo", "carrinho.atualizado_em=now()"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "ativo";
                    readonly to: "convertido";
                    readonly trigger: "iniciarCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["carrinho.status=convertido", "carrinho.atualizado_em=now()"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "ativo";
                    readonly to: "abandonado";
                    readonly trigger: "marcarAbandono";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["inatividadeAtingida"];
                    readonly actions: readonly ["carrinho.status=abandonado"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "abandonado";
                    readonly to: "expirado";
                    readonly trigger: "expirarCarrinho";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["prazoExpiracaoAtingido"];
                    readonly actions: readonly ["carrinho.status=expirado", "carrinho.expira_em=now()"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "abandonado";
                    readonly to: "convertido";
                    readonly trigger: "retomarCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["carrinho.status=convertido", "carrinho.atualizado_em=now()"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }];
                readonly requiredEntities: readonly ["Carrinho", "ItemPedido", "Cliente"];
                readonly persistenceRefs: readonly ["carrinho"];
                readonly usecaseRefs: readonly ["adicionarAoCarrinho", "atualizarCarrinho", "manterCarrinho"];
                readonly metricRefs: readonly [];
                readonly userActions: readonly ["adicionarAoCarrinho", "atualizarCarrinho", "iniciarCheckout"];
                readonly relatedPages: readonly ["carrinho", "checkout"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["rule-brl-localidade"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "sug-carrinho-expiracao";
                    readonly title: "Job de expiração de carrinhos abandonados";
                    readonly priority: "soon";
                    readonly description: "Implementar job periódico que marque carrinhos abandonados como expirados após o prazo configurável.";
                    readonly tradeoff: "Requer agendamento em infraestrutura e pode adicionar carga periódica no banco.";
                }, {
                    readonly suggestionId: "sug-carrinho-sem-tarefa";
                    readonly title: "Sem tarefas para fluxo de carrinho";
                    readonly priority: "now";
                    readonly description: "Manter o ciclo de vida do carrinho automático e controlado por eventos do cliente e jobs, sem criar tarefas administrativas.";
                    readonly tradeoff: "Sem visibilidade operacional via tarefas; exige métricas ou logs para monitorar abandono.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/carrinhoLifecycle.defs.ts";
                readonly exportName: "carrinhoLifecycleDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default carrinhoLifecycleDef;
}
declare module "_102030_/l4/workflows/catalogManagement.defs" {
    export const catalogManagementDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "catalogManagement";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 76;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "catalogManagement";
                readonly title: "Gestão de catálogo";
                readonly purpose: "Fluxo administrativo para criação, edição, ativação e desativação de produtos, serviços e categorias no catálogo do pet shop.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["adminPetShop"];
                readonly states: readonly [{
                    readonly stateId: "catalogNew";
                    readonly description: "Item ainda não persistido no catálogo.";
                }, {
                    readonly stateId: "catalogDraft";
                    readonly description: "Item criado e em edição interna antes de disponibilizar ao público.";
                }, {
                    readonly stateId: "catalogActive";
                    readonly description: "Item disponível para venda no catálogo.";
                }, {
                    readonly stateId: "catalogInactive";
                    readonly description: "Item desativado e oculto do catálogo.";
                }];
                readonly transitions: readonly [{
                    readonly from: "catalogNew";
                    readonly to: "catalogDraft";
                    readonly trigger: "createCatalogItem";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["gravar novo registro de Product", "gravar novo registro de Service", "gravar novo registro de CatalogCategory"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "catalogDraft";
                    readonly to: "catalogDraft";
                    readonly trigger: "saveDraftChanges";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["atualizar registro de Product", "atualizar registro de Service", "atualizar registro de CatalogCategory"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "catalogDraft";
                    readonly to: "catalogActive";
                    readonly trigger: "publishCatalogItem";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["definir item como ativo no catálogo"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "catalogActive";
                    readonly to: "catalogActive";
                    readonly trigger: "updateActiveItem";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["atualizar registro de Product", "atualizar registro de Service", "atualizar registro de CatalogCategory"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "catalogActive";
                    readonly to: "catalogInactive";
                    readonly trigger: "deactivateCatalogItem";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["definir item como inativo no catálogo"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "catalogInactive";
                    readonly to: "catalogActive";
                    readonly trigger: "reactivateCatalogItem";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["definir item como ativo no catálogo"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "catalogInactive";
                    readonly to: "catalogInactive";
                    readonly trigger: "updateInactiveItem";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["atualizar registro de Product", "atualizar registro de Service", "atualizar registro de CatalogCategory"];
                    readonly rulesApplied: readonly [];
                }];
                readonly requiredEntities: readonly ["Product", "Service", "CatalogCategory"];
                readonly persistenceRefs: readonly ["product", "service", "catalogCategory"];
                readonly usecaseRefs: readonly ["usecaseManageCatalog"];
                readonly metricRefs: readonly [];
                readonly userActions: readonly ["manageCatalog"];
                readonly relatedPages: readonly ["adminCatalogPage"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly [];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "suggestCatalogAuditLog";
                    readonly title: "Manter histórico de alterações de preço e disponibilidade do catálogo";
                    readonly priority: "soon";
                    readonly description: "Registrar mudanças de catálogo para auditoria e rollback administrativo.";
                    readonly tradeoff: "Aumenta volume de dados e exige telas de histórico.";
                }, {
                    readonly suggestionId: "suggestBulkCatalogEdit";
                    readonly title: "Suportar edição em lote de produtos e serviços";
                    readonly priority: "later";
                    readonly description: "Permitir alterações em massa para campanhas sazonais e promoções.";
                    readonly tradeoff: "Complexidade maior na validação e possibilidade de erros em massa.";
                }, {
                    readonly suggestionId: "suggestNoCatalogTasks";
                    readonly title: "Operar gestão de catálogo sem criação automática de tarefas";
                    readonly priority: "now";
                    readonly description: "Manter o fluxo direto no painel administrativo, sem filas de tarefas.";
                    readonly tradeoff: "Menos rastreio formal de responsáveis e SLAs internos.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/catalogManagement.defs.ts";
                readonly exportName: "catalogManagementDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default catalogManagementDef;
}
declare module "_102030_/l4/workflows/checkoutAndPayment.defs" {
    export const checkoutAndPaymentDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "checkoutAndPayment";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 72;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "checkoutAndPayment";
                readonly title: "Checkout e pagamento";
                readonly purpose: "Fluxo de compra do cliente desde o carrinho até a confirmação de pagamento via Stripe, incluindo criação do pedido e atualização de métricas.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["cliente"];
                readonly states: readonly [{
                    readonly stateId: "cartReady";
                    readonly description: "Carrinho ativo com itens selecionados e pronto para iniciar checkout.";
                }, {
                    readonly stateId: "orderCreated";
                    readonly description: "Pedido criado e aguardando confirmação de pagamento.";
                }, {
                    readonly stateId: "orderPaid";
                    readonly description: "Pedido com pagamento confirmado e métricas atualizadas.";
                }];
                readonly transitions: readonly [{
                    readonly from: "cartReady";
                    readonly to: "orderCreated";
                    readonly trigger: "startCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["cart.status == ativo", "ruleOrderRequiresCustomer"];
                    readonly actions: readonly ["set cart.status = convertido", "set order.status = aguardandoPagamento", "set order.payment_status = pendente", "set order.created_at = now", "set order.updated_at = now"];
                    readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "ruleOrderStatusLifecycle"];
                }, {
                    readonly from: "orderCreated";
                    readonly to: "orderPaid";
                    readonly trigger: "confirmStripePayment";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink"];
                    readonly actions: readonly ["set order.status = pago", "set order.payment_status = aprovado", "set order.paid_at = now", "set order.updated_at = now"];
                    readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
                }];
                readonly requiredEntities: readonly ["Cart", "CartItem", "Order", "OrderItem", "Payment", "StripeTransaction"];
                readonly persistenceRefs: readonly ["cart", "order"];
                readonly usecaseRefs: readonly ["usecaseCreateOrder", "usecaseConfirmStripePayment", "usecaseUpdateMetricsOnOrderPaid"];
                readonly metricRefs: readonly ["salesOpsMetrics"];
                readonly userActions: readonly ["startCheckout", "confirmStripePayment"];
                readonly relatedPages: readonly ["cartPage", "checkoutPage"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly ["stripePaymentsPlugin"];
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "ruleOrderStatusLifecycle", "rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "suggestStripeWebhookHandler";
                    readonly title: "Processar confirmações de pagamento via webhook Stripe de forma assíncrona";
                    readonly priority: "now";
                    readonly description: "Garantir idempotência e confiabilidade na transição de status do pedido quando o Stripe confirmar o pagamento.";
                    readonly tradeoff: "Requer infraestrutura de filas e verificação de assinatura do webhook.";
                }, {
                    readonly suggestionId: "suggestCartExpirationJob";
                    readonly title: "Expirar carrinhos abandonados automaticamente após período de inatividade";
                    readonly priority: "soon";
                    readonly description: "Manter consistência de estoque e evitar carrinhos obsoletos antes do checkout.";
                    readonly tradeoff: "Pode encerrar carrinhos legítimos se o período for curto.";
                }, {
                    readonly suggestionId: "suggestNoTaskFlow";
                    readonly title: "Evitar criação de tarefas manuais no checkout";
                    readonly priority: "now";
                    readonly description: "Manter o fluxo 100% automatizado para o cliente sem geração de tarefas administrativas.";
                    readonly tradeoff: "Dependência maior de automações e monitoramento de falhas de pagamento.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/checkoutAndPayment.defs.ts";
                readonly exportName: "checkoutAndPaymentDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default checkoutAndPaymentDef;
}
declare module "_102030_/l4/workflows/checkoutStripe.defs" {
    export const checkoutStripeDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "checkoutStripe";
        readonly moduleName: "petShopBrasil";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "checkoutStripe";
                readonly title: "Checkout com Stripe";
                readonly purpose: "Fluxo de compra multi-etapa onde o cliente revisa o carrinho, informa dados, seleciona método de pagamento (cartão ou PIX) e gera o pedido com intenção de pagamento Stripe.";
                readonly executionMode: "taskWorkflow";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["cliente"];
                readonly states: readonly [{
                    readonly stateId: "cartReview";
                    readonly description: "Cliente revisa itens do carrinho antes de avançar.";
                }, {
                    readonly stateId: "buyerDetails";
                    readonly description: "Cliente informa dados básicos do comprador para o pedido.";
                }, {
                    readonly stateId: "paymentMethod";
                    readonly description: "Cliente escolhe método de pagamento (cartão ou PIX).";
                }, {
                    readonly stateId: "orderCreated";
                    readonly description: "Pedido criado a partir do carrinho com status inicial.";
                }, {
                    readonly stateId: "paymentIntentCreated";
                    readonly description: "Intenção de pagamento Stripe associada ao pedido.";
                }, {
                    readonly stateId: "checkoutComplete";
                    readonly description: "Checkout concluído com instruções de pagamento exibidas.";
                }, {
                    readonly stateId: "checkoutCancelled";
                    readonly description: "Checkout cancelado pelo cliente.";
                }];
                readonly transitions: readonly [{
                    readonly from: "cartReview";
                    readonly to: "buyerDetails";
                    readonly trigger: "proceedToCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["rule-brl-localidade"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "buyerDetails";
                    readonly to: "orderCreated";
                    readonly trigger: "iniciarCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["rule-status-pedido", "rule-brl-localidade"];
                    readonly actions: readonly ["pedido.status=criado", "carrinho.status=convertido", "pedido.createdAt=now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-brl-localidade"];
                }, {
                    readonly from: "orderCreated";
                    readonly to: "paymentMethod";
                    readonly trigger: "openPaymentSelection";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["rule-metodos-stripe"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["rule-metodos-stripe"];
                }, {
                    readonly from: "paymentMethod";
                    readonly to: "paymentIntentCreated";
                    readonly trigger: "selecionarMetodoPagamento";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["rule-metodos-stripe", "rule-brl-localidade"];
                    readonly actions: readonly ["pedido.status=aguardandoPagamento", "pedido.stripePaymentIntentId=set"];
                    readonly rulesApplied: readonly ["rule-metodos-stripe", "rule-brl-localidade", "rule-status-pedido"];
                }, {
                    readonly from: "paymentIntentCreated";
                    readonly to: "checkoutComplete";
                    readonly trigger: "displayStripeInstructions";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "cartReview";
                    readonly to: "checkoutCancelled";
                    readonly trigger: "cancelCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["carrinho.status=abandonado"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "buyerDetails";
                    readonly to: "checkoutCancelled";
                    readonly trigger: "cancelCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["carrinho.status=abandonado"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "paymentMethod";
                    readonly to: "checkoutCancelled";
                    readonly trigger: "cancelCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["pedido.status=cancelado", "pedido.canceledAt=now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido"];
                }, {
                    readonly from: "orderCreated";
                    readonly to: "checkoutCancelled";
                    readonly trigger: "cancelCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["pedido.status=cancelado", "pedido.canceledAt=now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido"];
                }, {
                    readonly from: "paymentIntentCreated";
                    readonly to: "checkoutCancelled";
                    readonly trigger: "cancelCheckout";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["pedido.status=cancelado", "pedido.canceledAt=now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido"];
                }];
                readonly requiredEntities: readonly ["Carrinho", "Pedido", "Pagamento", "ItemPedido"];
                readonly persistenceRefs: readonly ["carrinho", "pedido"];
                readonly usecaseRefs: readonly ["iniciarCheckout", "selecionarMetodoPagamento"];
                readonly metricRefs: readonly [];
                readonly userActions: readonly ["iniciarCheckout", "selecionarMetodoPagamento"];
                readonly relatedPages: readonly ["carrinho", "checkout"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly ["stripePagamentos"];
                readonly rulesApplied: readonly ["rule-metodos-stripe", "rule-status-pedido", "rule-brl-localidade"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "sugCheckoutIdempotencia";
                    readonly title: "Chave de idempotência no checkout";
                    readonly priority: "now";
                    readonly description: "Gerar e enviar chave de idempotência ao criar pedido e intenção de pagamento para evitar duplicações em recargas ou cliques repetidos.";
                    readonly tradeoff: "Exige armazenamento temporário da chave e validação adicional no backend.";
                }, {
                    readonly suggestionId: "sugCheckoutSemTarefa";
                    readonly title: "Sem criação de tarefa no checkout";
                    readonly priority: "now";
                    readonly description: "Manter o checkout como fluxo do cliente sem tarefas administrativas; qualquer falha deve ser tratada por mensagens no checkout e re-tentativa do pagamento.";
                    readonly tradeoff: "Menor rastreabilidade operacional no admin para problemas de checkout em tempo real.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/checkoutStripe.defs.ts";
                readonly exportName: "checkoutStripeDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default checkoutStripeDef;
}
declare module "_102030_/l4/workflows/conciliacaoFinanceira.defs" {
    export const conciliacaoFinanceiraDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "conciliacaoFinanceira";
        readonly moduleName: "petShopBrasil";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "conciliacaoFinanceira";
                readonly title: "Conciliação financeira";
                readonly purpose: "Comparar periodicamente pedidos pagos com transações recebidas na Stripe, identificar divergências e gerar tarefas administrativas para correção.";
                readonly executionMode: "automation";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Investigar divergência de conciliação {dataReferencia}";
                    readonly assigneeRules: readonly ["administrador"];
                    readonly slaRules: readonly ["resolverEm:2d"];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["administrador"];
                readonly states: readonly [{
                    readonly stateId: "idle";
                    readonly description: "Aguardando execução da conciliação.";
                }, {
                    readonly stateId: "executing";
                    readonly description: "Conciliando pedidos pagos com transações Stripe.";
                }, {
                    readonly stateId: "conciliado";
                    readonly description: "Conciliação concluída sem divergências pendentes.";
                }, {
                    readonly stateId: "divergenciasEncontradas";
                    readonly description: "Divergências identificadas e aguardando análise administrativa.";
                }, {
                    readonly stateId: "falha";
                    readonly description: "Falha na execução da conciliação.";
                }];
                readonly transitions: readonly [{
                    readonly from: "idle";
                    readonly to: "executing";
                    readonly trigger: "scheduledRun";
                    readonly actor: "administrador";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }, {
                    readonly from: "idle";
                    readonly to: "executing";
                    readonly trigger: "manualRun";
                    readonly actor: "administrador";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }, {
                    readonly from: "executing";
                    readonly to: "conciliado";
                    readonly trigger: "reconciliationCompleted";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["semDivergencias"];
                    readonly actions: readonly ["Pedido.updatedAt=now"];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }, {
                    readonly from: "executing";
                    readonly to: "divergenciasEncontradas";
                    readonly trigger: "divergenceDetected";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["comDivergencias"];
                    readonly actions: readonly ["Pedido.updatedAt=now"];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }, {
                    readonly from: "divergenciasEncontradas";
                    readonly to: "conciliado";
                    readonly trigger: "divergenceResolved";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["divergenciasCorrigidas"];
                    readonly actions: readonly ["Pedido.updatedAt=now"];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }, {
                    readonly from: "executing";
                    readonly to: "falha";
                    readonly trigger: "reconciliationFailed";
                    readonly actor: "administrador";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }, {
                    readonly from: "falha";
                    readonly to: "executing";
                    readonly trigger: "retryRun";
                    readonly actor: "administrador";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                }];
                readonly requiredEntities: readonly ["Pedido", "Pagamento", "TransacaoFinanceira"];
                readonly persistenceRefs: readonly ["pedido"];
                readonly usecaseRefs: readonly ["conciliarTransacoes", "conciliarTransacoesStripe"];
                readonly metricRefs: readonly [];
                readonly userActions: readonly ["conciliarTransacoes"];
                readonly relatedPages: readonly ["adminFinanceiro"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly ["stripePagamentos"];
                readonly rulesApplied: readonly ["rule-confirmacao-stripe", "rule-acesso-admin"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "sugConciliacaoAgendada";
                    readonly title: "Execução agendada da conciliação";
                    readonly priority: "soon";
                    readonly description: "Executar a conciliação automaticamente diariamente (ex: 03h) para identificar divergências sem intervenção manual.";
                    readonly tradeoff: "Requer infraestrutura de agendamento e monitoramento de falhas.";
                }, {
                    readonly suggestionId: "sugConciliacaoDivergencia";
                    readonly title: "Tarefa administrativa para divergências";
                    readonly priority: "soon";
                    readonly description: "Criar tarefa administrativa ao detectar divergências para investigação e correção pelo administrador.";
                    readonly tradeoff: "Pode aumentar volume de tarefas em períodos de instabilidade da Stripe.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/conciliacaoFinanceira.defs.ts";
                readonly exportName: "conciliacaoFinanceiraDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default conciliacaoFinanceiraDef;
}
declare module "_102030_/l4/workflows/expiracaoCarrinho.defs" {
    export const expiracaoCarrinhoDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "expiracaoCarrinho";
        readonly moduleName: "petShopBrasil";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 68;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "expiracaoCarrinho";
                readonly title: "Expiração de carrinhos";
                readonly purpose: "Automatizar a marcação de carrinhos como expirados ou abandonados após período de inatividade, liberando recursos e alimentando métricas de abandono.";
                readonly executionMode: "automation";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["cliente"];
                readonly states: readonly [{
                    readonly stateId: "ativo";
                    readonly description: "Carrinho em uso pelo cliente.";
                }, {
                    readonly stateId: "abandonado";
                    readonly description: "Carrinho sem atividade por período de inatividade.";
                }, {
                    readonly stateId: "expirado";
                    readonly description: "Carrinho expirado e indisponível para checkout.";
                }, {
                    readonly stateId: "convertido";
                    readonly description: "Carrinho convertido em pedido durante o checkout.";
                }];
                readonly transitions: readonly [{
                    readonly from: "ativo";
                    readonly to: "abandonado";
                    readonly trigger: "jobInatividadeDetectada";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["set status=abandonado", "set atualizado_em=now"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "abandonado";
                    readonly to: "expirado";
                    readonly trigger: "jobExpiracaoCarrinho";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["set status=expirado", "set atualizado_em=now"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }, {
                    readonly from: "ativo";
                    readonly to: "expirado";
                    readonly trigger: "jobExpiracaoCarrinho";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["set status=expirado", "set atualizado_em=now"];
                    readonly rulesApplied: readonly ["rule-brl-localidade"];
                }];
                readonly requiredEntities: readonly ["Carrinho"];
                readonly persistenceRefs: readonly ["carrinho"];
                readonly usecaseRefs: readonly [];
                readonly metricRefs: readonly [];
                readonly userActions: readonly [];
                readonly relatedPages: readonly [];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["rule-brl-localidade"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "carrinhoJobSchedule";
                    readonly title: "Job periódico de expiração";
                    readonly priority: "soon";
                    readonly description: "Executar job de expiração a cada 1 hora para marcar carrinhos inativos além do prazo configurado.";
                    readonly tradeoff: "Aumenta carga de processamento periódico, mas mantém carrinhos limpos e atualizados.";
                }, {
                    readonly suggestionId: "noTaskForExpiration";
                    readonly title: "Sem tarefas humanas para expiração";
                    readonly priority: "now";
                    readonly description: "Manter expiração totalmente automática, sem criação de tarefas, pois é rotina operacional de limpeza.";
                    readonly tradeoff: "Não há revisão humana de casos limítrofes; exige monitoramento por logs.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/expiracaoCarrinho.defs.ts";
                readonly exportName: "expiracaoCarrinhoDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default expiracaoCarrinhoDef;
}
declare module "_102030_/l4/workflows/orderLifecycleManagement.defs" {
    export const orderLifecycleManagementDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "orderLifecycleManagement";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 74;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "orderLifecycleManagement";
                readonly title: "Gestão do ciclo de vida do pedido";
                readonly purpose: "Acompanhar e atualizar os status dos pedidos e serviços agendados, da criação até a separação, conclusão ou cancelamento, com atualização de métricas.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["adminPetShop"];
                readonly states: readonly [{
                    readonly stateId: "created";
                    readonly description: "Pedido criado e aguardando confirmação administrativa inicial.";
                }, {
                    readonly stateId: "awaitingPayment";
                    readonly description: "Pedido aguardando confirmação de pagamento.";
                }, {
                    readonly stateId: "paid";
                    readonly description: "Pedido pago e pronto para separação.";
                }, {
                    readonly stateId: "inSeparation";
                    readonly description: "Pedido em separação/preparação.";
                }, {
                    readonly stateId: "completed";
                    readonly description: "Pedido concluído e entregue/serviço finalizado.";
                }, {
                    readonly stateId: "canceled";
                    readonly description: "Pedido cancelado.";
                }];
                readonly transitions: readonly [{
                    readonly from: "created";
                    readonly to: "awaitingPayment";
                    readonly trigger: "markAwaitingPayment";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["order.status=aguardandoPagamento", "order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                }, {
                    readonly from: "awaitingPayment";
                    readonly to: "paid";
                    readonly trigger: "markPaid";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["order.status=pago", "order.payment_status=pago", "order.paid_at=now", "order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle", "ruleMetricsUpdateOnOrderPaid"];
                }, {
                    readonly from: "paid";
                    readonly to: "inSeparation";
                    readonly trigger: "startSeparation";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["order.status=emSeparacao", "order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                }, {
                    readonly from: "inSeparation";
                    readonly to: "completed";
                    readonly trigger: "completeOrder";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["order.status=concluido", "order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                }, {
                    readonly from: "awaitingPayment";
                    readonly to: "canceled";
                    readonly trigger: "cancelOrder";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["order.status=cancelado", "order.canceled_at=now", "order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                }, {
                    readonly from: "paid";
                    readonly to: "canceled";
                    readonly trigger: "cancelPaidOrder";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["order.status=cancelado", "order.canceled_at=now", "order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                }];
                readonly requiredEntities: readonly ["Order", "OrderItem", "ServiceBooking"];
                readonly persistenceRefs: readonly ["order", "serviceBooking"];
                readonly usecaseRefs: readonly ["usecaseUpdateOrderStatus"];
                readonly metricRefs: readonly ["salesOpsMetrics"];
                readonly userActions: readonly ["updateOrderStatus"];
                readonly relatedPages: readonly ["adminOrdersPage", "adminDashboardPage", "adminMetricsPage"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle", "ruleMetricsUpdateOnOrderPaid"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "suggestStatusTransitionValidation";
                    readonly title: "Validar transições de status do pedido exclusivamente no backend";
                    readonly priority: "now";
                    readonly description: "Centralizar a validação no caso de uso de atualização de status para impedir mudanças inválidas no ciclo de vida.";
                    readonly tradeoff: "Pode reduzir flexibilidade em ajustes manuais fora do fluxo padrão.";
                }, {
                    readonly suggestionId: "suggestServiceFulfillmentTask";
                    readonly title: "Criar tarefa de cumprimento para serviços agendados na agenda da equipe";
                    readonly priority: "soon";
                    readonly description: "Adicionar workflow de tarefas para execução de banho/tosa quando o pedido tiver agendamento.";
                    readonly tradeoff: "Exige modelagem de tarefas e integrações adicionais com a agenda da equipe.";
                }, {
                    readonly suggestionId: "suggestNoTasksInLifecycle";
                    readonly title: "Manter o fluxo sem criação automática de tarefas";
                    readonly priority: "now";
                    readonly description: "Como o workflow é de entityLifecycle, concentrar a operação na atualização de status via casos de uso, sem gerar tarefas dedicadas.";
                    readonly tradeoff: "A equipe pode precisar de controles adicionais fora do sistema para lembrar etapas operacionais.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/orderLifecycleManagement.defs.ts";
                readonly exportName: "orderLifecycleManagementDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderLifecycleManagementDef;
}
declare module "_102030_/l4/workflows/paymentReconciliation.defs" {
    export const paymentReconciliationDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "paymentReconciliation";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 75;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "paymentReconciliation";
                readonly title: "Conciliação de recebíveis";
                readonly purpose: "Registrar recebíveis a partir de pagamentos aprovados e conciliar transações Stripe com lançamentos financeiros do pet shop.";
                readonly executionMode: "taskWorkflow";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Conciliar recebível do pedido {{orderNumber}}";
                    readonly assigneeRules: readonly ["ruleAssignAdminPetShopFinance"];
                    readonly slaRules: readonly ["ruleSlaReconcilePayments48h"];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["adminPetShop"];
                readonly states: readonly [{
                    readonly stateId: "taskOpen";
                    readonly description: "Tarefa de conciliação criada e aguardando início.";
                }, {
                    readonly stateId: "taskInReview";
                    readonly description: "Administrador revisando pagamentos Stripe e lançamentos financeiros.";
                }, {
                    readonly stateId: "taskReconciled";
                    readonly description: "Conciliação concluída e recebíveis registrados.";
                }, {
                    readonly stateId: "taskNeedsAttention";
                    readonly description: "Conciliação pendente por divergência ou dados incompletos.";
                }, {
                    readonly stateId: "taskCanceled";
                    readonly description: "Tarefa cancelada sem conciliação.";
                }];
                readonly transitions: readonly [{
                    readonly from: "taskOpen";
                    readonly to: "taskInReview";
                    readonly trigger: "startReview";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleStripeTransactionLink"];
                }, {
                    readonly from: "taskInReview";
                    readonly to: "taskReconciled";
                    readonly trigger: "confirmReconciliation";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleReceivableFromPayment", "ruleStripeTransactionLink"];
                }, {
                    readonly from: "taskInReview";
                    readonly to: "taskNeedsAttention";
                    readonly trigger: "markMismatch";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleStripeTransactionLink"];
                }, {
                    readonly from: "taskNeedsAttention";
                    readonly to: "taskInReview";
                    readonly trigger: "resumeReview";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleStripeTransactionLink"];
                }, {
                    readonly from: "taskOpen";
                    readonly to: "taskCanceled";
                    readonly trigger: "cancelTask";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "taskInReview";
                    readonly to: "taskCanceled";
                    readonly trigger: "cancelTask";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "taskNeedsAttention";
                    readonly to: "taskCanceled";
                    readonly trigger: "cancelTask";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly [];
                }];
                readonly requiredEntities: readonly ["Payment", "StripeTransaction", "Receivable", "FinancialEntry", "Order"];
                readonly persistenceRefs: readonly ["order", "receivable", "financialEntry"];
                readonly usecaseRefs: readonly ["usecaseReconcilePayments"];
                readonly metricRefs: readonly ["salesOpsMetrics"];
                readonly userActions: readonly ["reconcilePayments"];
                readonly relatedPages: readonly ["adminFinancialPage"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly ["stripePaymentsPlugin"];
                readonly rulesApplied: readonly ["ruleReceivableFromPayment", "ruleStripeTransactionLink"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "suggestStripePayoutAutoSync";
                    readonly title: "Sincronizar payouts e extratos Stripe automaticamente";
                    readonly priority: "soon";
                    readonly description: "Manter recebíveis atualizados sem intervenção manual.";
                    readonly tradeoff: "Requer integração assíncrona adicional e monitoramento de falhas.";
                }, {
                    readonly suggestionId: "suggestReconciliationPendingAlert";
                    readonly title: "Alertar administrador sobre transações pendentes de conciliação";
                    readonly priority: "soon";
                    readonly description: "Evitar atraso no fechamento financeiro e garantir rastreabilidade.";
                    readonly tradeoff: "Pode gerar ruído se alertas não forem bem calibrados.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/paymentReconciliation.defs.ts";
                readonly exportName: "paymentReconciliationDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default paymentReconciliationDef;
}
declare module "_102030_/l4/workflows/pedidoLifecycle.defs" {
    export const pedidoLifecycleDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "pedidoLifecycle";
        readonly moduleName: "petShopBrasil";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "pedidoLifecycle";
                readonly title: "Ciclo de vida do pedido";
                readonly purpose: "Controlar transições de status do pedido desde a criação até pagamento, cancelamento ou reembolso, garantindo consistência com transações Stripe.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["cliente", "administrador"];
                readonly states: readonly [{
                    readonly stateId: "inicio";
                    readonly description: "Estado inicial antes da criação do pedido.";
                }, {
                    readonly stateId: "criado";
                    readonly description: "Pedido registrado e pronto para iniciar pagamento.";
                }, {
                    readonly stateId: "aguardandoPagamento";
                    readonly description: "Pedido com pagamento iniciado e aguardando confirmação da Stripe.";
                }, {
                    readonly stateId: "pago";
                    readonly description: "Pagamento confirmado pela Stripe.";
                }, {
                    readonly stateId: "cancelado";
                    readonly description: "Pedido cancelado antes do pagamento.";
                }, {
                    readonly stateId: "reembolsado";
                    readonly description: "Pedido pago com reembolso confirmado.";
                }];
                readonly transitions: readonly [{
                    readonly from: "inicio";
                    readonly to: "criado";
                    readonly trigger: "criarPedido";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["pedido.status = \"criado\"", "pedido.createdAt = now()", "pedido.updatedAt = now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-brl-localidade"];
                }, {
                    readonly from: "criado";
                    readonly to: "aguardandoPagamento";
                    readonly trigger: "selecionarMetodoPagamento";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["pedido.status = \"aguardandoPagamento\"", "pedido.updatedAt = now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-brl-localidade", "rule-confirmacao-stripe"];
                }, {
                    readonly from: "aguardandoPagamento";
                    readonly to: "pago";
                    readonly trigger: "confirmarPagamentoStripe";
                    readonly actor: "administrador";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["pedido.status = \"pago\"", "pedido.paidAt = now()", "pedido.updatedAt = now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-confirmacao-stripe", "rule-brl-localidade"];
                }, {
                    readonly from: "criado";
                    readonly to: "cancelado";
                    readonly trigger: "atualizarStatusPedido";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["pedido.status = \"criado\""];
                    readonly actions: readonly ["pedido.status = \"cancelado\"", "pedido.canceledAt = now()", "pedido.updatedAt = now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-acesso-admin", "rule-brl-localidade"];
                }, {
                    readonly from: "aguardandoPagamento";
                    readonly to: "cancelado";
                    readonly trigger: "atualizarStatusPedido";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["pedido.status = \"aguardandoPagamento\""];
                    readonly actions: readonly ["pedido.status = \"cancelado\"", "pedido.canceledAt = now()", "pedido.updatedAt = now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-acesso-admin", "rule-brl-localidade"];
                }, {
                    readonly from: "pago";
                    readonly to: "reembolsado";
                    readonly trigger: "reembolsarPagamento";
                    readonly actor: "administrador";
                    readonly conditions: readonly ["pedido.status = \"pago\""];
                    readonly actions: readonly ["pedido.status = \"reembolsado\"", "pedido.refundedAt = now()", "pedido.updatedAt = now()"];
                    readonly rulesApplied: readonly ["rule-status-pedido", "rule-confirmacao-stripe", "rule-acesso-admin", "rule-brl-localidade"];
                }];
                readonly requiredEntities: readonly ["Pedido", "Pagamento", "TransacaoFinanceira", "ItemPedido"];
                readonly persistenceRefs: readonly ["pedido"];
                readonly usecaseRefs: readonly ["criarPedido", "confirmarPagamentoStripe", "atualizarStatusPedido", "reembolsarPagamento"];
                readonly metricRefs: readonly ["dailySalesMetrics"];
                readonly userActions: readonly ["iniciarCheckout", "selecionarMetodoPagamento", "confirmarPagamentoStripe", "atualizarStatusPedido", "reembolsarPagamento", "consultarMeusPedidos"];
                readonly relatedPages: readonly ["checkout", "meusPedidos", "adminPedidos", "adminFinanceiro"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly ["stripePagamentos"];
                readonly rulesApplied: readonly ["rule-status-pedido", "rule-brl-localidade", "rule-confirmacao-stripe"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "sugPedidoWebhook";
                    readonly title: "Transições automáticas via webhook Stripe";
                    readonly priority: "now";
                    readonly description: "Disparar a transição aguardandoPagamento → pago somente pelo webhook de confirmação Stripe para evitar inconsistências manuais.";
                    readonly tradeoff: "A confirmação depende da disponibilidade do webhook e exige tratamento de idempotência.";
                }, {
                    readonly suggestionId: "sugPedidoSemTarefas";
                    readonly title: "Sem criação de tarefas no ciclo de vida do pedido";
                    readonly priority: "now";
                    readonly description: "Este workflow é de lifecycle e todas as transições são automatizadas ou operacionais; tarefas administrativas ficam nos workflows de confirmação, cancelamento ou conciliação.";
                    readonly tradeoff: "Incidentes fora do fluxo exigirão workflows auxiliares para abrir tarefas manuais.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/pedidoLifecycle.defs.ts";
                readonly exportName: "pedidoLifecycleDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default pedidoLifecycleDef;
}
declare module "_102030_/l4/workflows/serviceBooking.defs" {
    export const serviceBookingDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "serviceBooking";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 73;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "serviceBooking";
                readonly title: "Agendamento de serviço";
                readonly purpose: "Permitir ao cliente selecionar data e horário disponíveis para serviços como banho e tosa, vinculando o agendamento ao pedido e gerando entrada na agenda administrativa.";
                readonly executionMode: "taskWorkflow";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Confirmar agendamento de serviço {{service_booking_id}}";
                    readonly assigneeRules: readonly ["assignToRole:adminPetShop"];
                    readonly slaRules: readonly ["sla:confirmBooking24h"];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["cliente", "adminPetShop"];
                readonly states: readonly [{
                    readonly stateId: "notScheduled";
                    readonly description: "Cliente ainda não solicitou agendamento para o serviço.";
                }, {
                    readonly stateId: "bookingPending";
                    readonly description: "Agendamento criado e aguardando confirmação administrativa.";
                }, {
                    readonly stateId: "bookingConfirmed";
                    readonly description: "Agendamento confirmado e reservado na agenda.";
                }, {
                    readonly stateId: "bookingCanceled";
                    readonly description: "Agendamento cancelado pelo cliente ou admin.";
                }];
                readonly transitions: readonly [{
                    readonly from: "notScheduled";
                    readonly to: "bookingPending";
                    readonly trigger: "scheduleService";
                    readonly actor: "cliente";
                    readonly conditions: readonly ["ruleServiceBookingRequiresSlot"];
                    readonly actions: readonly ["ServiceBooking.status=pendente", "ServiceBooking.service_id=selectedServiceId", "ServiceBooking.customer_id=currentCustomerId", "ServiceBooking.pet_id=selectedPetId", "ServiceBooking.order_id=orderId", "ServiceBooking.scheduled_date=selectedDate", "ServiceBooking.scheduled_start_time=selectedStartTime", "ServiceBooking.scheduled_end_time=selectedEndTime", "ServiceBooking.timezone=selectedTimezone", "ServiceBooking.created_at=now", "ServiceBooking.updated_at=now", "Order.scheduled_service_at=selectedDateTime", "Order.updated_at=now"];
                    readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
                }, {
                    readonly from: "bookingPending";
                    readonly to: "bookingConfirmed";
                    readonly trigger: "confirmBooking";
                    readonly actor: "adminPetShop";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["ServiceBooking.status=confirmado", "ServiceBooking.updated_at=now"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "bookingPending";
                    readonly to: "bookingCanceled";
                    readonly trigger: "cancelBooking";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["ServiceBooking.status=cancelado", "ServiceBooking.canceled_at=now", "ServiceBooking.updated_at=now"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "bookingConfirmed";
                    readonly to: "bookingCanceled";
                    readonly trigger: "cancelBooking";
                    readonly actor: "cliente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["ServiceBooking.status=cancelado", "ServiceBooking.canceled_at=now", "ServiceBooking.updated_at=now"];
                    readonly rulesApplied: readonly [];
                }];
                readonly requiredEntities: readonly ["ServiceBooking", "Service", "Pet", "Order"];
                readonly persistenceRefs: readonly ["serviceBooking", "order"];
                readonly usecaseRefs: readonly ["usecaseScheduleService"];
                readonly metricRefs: readonly ["salesOpsMetrics"];
                readonly userActions: readonly ["scheduleService"];
                readonly relatedPages: readonly ["productServiceDetailPage", "accountOrdersPage", "adminOrdersPage", "adminDashboardPage"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "suggestRealTimeSlotCheck";
                    readonly title: "Verificar disponibilidade de horários em tempo real durante a seleção";
                    readonly priority: "now";
                    readonly description: "Consultar disponibilidade antes de confirmar o agendamento para evitar conflito de agenda.";
                    readonly tradeoff: "Aumenta complexidade de consultas e requer cache/lock de slots.";
                }, {
                    readonly suggestionId: "suggestBookingReminderNotification";
                    readonly title: "Enviar lembrete automático de agendamento ao cliente";
                    readonly priority: "soon";
                    readonly description: "Disparar notificações antes do horário agendado para reduzir no-show.";
                    readonly tradeoff: "Depende de integração com módulo de notificações.";
                }, {
                    readonly suggestionId: "suggestAdminTaskSlaMonitor";
                    readonly title: "Monitorar SLA de confirmação de agendamento";
                    readonly priority: "soon";
                    readonly description: "Criar alertas quando tarefas de confirmação ultrapassarem 24h.";
                    readonly tradeoff: "Exige configuração de alertas e acompanhamento operacional.";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/serviceBooking.defs.ts";
                readonly exportName: "serviceBookingDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceBookingDef;
}
declare module "_102030_/l5/petShopStripe/module.defs" {
    export const modulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "module";
        readonly artifactId: "petShopStripe";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentFinalizeSolutionPlan";
            readonly stepId: 11;
            readonly planId: "plan-finalize-solution-plan";
        };
        readonly data: {
            readonly module: {
                readonly moduleName: "petShopStripe";
                readonly purpose: "Criar um site de pet shop no Brasil com vendas de produtos e serviços, checkout e pagamentos via Stripe, além de gestão administrativa e financeiro.";
                readonly businessDomain: "petShopCommerce";
                readonly languages: readonly ["pt-BR"];
                readonly visualStyle: {
                    readonly tone: "Moderno e amigável";
                    readonly layout: "Vitrine clara com navegação simples e foco em conversão";
                    readonly palette: readonly ["#F6F3FF", "#8BC7B5", "#F5A6C6", "#FFD48A", "#4C6A92"];
                };
            };
            readonly actors: readonly [{
                readonly actorId: "cliente";
                readonly title: "Cliente";
                readonly description: "Tutores de pets que compram produtos e serviços.";
            }, {
                readonly actorId: "adminPetShop";
                readonly title: "Administrador";
                readonly description: "Responsável por catálogo, pedidos, serviços, pagamentos, financeiro e métricas.";
            }];
            readonly capabilities: readonly [{
                readonly capabilityId: "browseCatalog";
                readonly title: "Explorar catálogo";
                readonly description: "Permitir ao cliente navegar por produtos e serviços do pet shop.";
                readonly actor: "cliente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "manageCartCheckout";
                readonly title: "Carrinho e checkout";
                readonly description: "Adicionar itens ao carrinho e finalizar compra.";
                readonly actor: "cliente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "payWithStripe";
                readonly title: "Pagamento via Stripe";
                readonly description: "Realizar pagamento com Stripe para produtos e serviços.";
                readonly actor: "cliente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "bookService";
                readonly title: "Agendar serviço";
                readonly description: "Selecionar data/horário para serviços como banho e tosa.";
                readonly actor: "cliente";
                readonly priority: "soon";
            }, {
                readonly capabilityId: "manageCatalog";
                readonly title: "Gerenciar catálogo";
                readonly description: "Cadastrar/editar produtos e serviços, preços e disponibilidade.";
                readonly actor: "adminPetShop";
                readonly priority: "now";
            }, {
                readonly capabilityId: "manageOrdersServices";
                readonly title: "Gerenciar pedidos e serviços";
                readonly description: "Acompanhar pedidos, status de pagamento e agenda de serviços.";
                readonly actor: "adminPetShop";
                readonly priority: "now";
            }, {
                readonly capabilityId: "financialOverview";
                readonly title: "Visão financeira";
                readonly description: "Acompanhar recebíveis e transações de pagamento.";
                readonly actor: "adminPetShop";
                readonly priority: "now";
            }, {
                readonly capabilityId: "metricsDashboard";
                readonly title: "Métricas e dashboard";
                readonly description: "Visualizar métricas básicas de vendas e serviços.";
                readonly actor: "adminPetShop";
                readonly priority: "now";
            }];
            readonly ontology: {
                readonly entities: {
                    readonly Customer: {
                        readonly title: "Cliente";
                        readonly description: "Tutor de pet que compra produtos ou serviços.";
                    };
                    readonly Pet: {
                        readonly title: "Pet";
                        readonly description: "Animal de estimação associado ao cliente para serviços.";
                    };
                    readonly Product: {
                        readonly title: "Produto";
                        readonly description: "Item físico vendido pelo pet shop.";
                    };
                    readonly Service: {
                        readonly title: "Serviço";
                        readonly description: "Serviço oferecido pelo pet shop, como banho e tosa.";
                    };
                    readonly Cart: {
                        readonly title: "Carrinho";
                        readonly description: "Seleção temporária de produtos e serviços antes do checkout.";
                    };
                    readonly CartItem: {
                        readonly title: "Item do carrinho";
                        readonly description: "Item individual no carrinho com quantidade e preço.";
                    };
                    readonly Order: {
                        readonly title: "Pedido";
                        readonly description: "Compromisso de compra gerado no checkout.";
                    };
                    readonly OrderItem: {
                        readonly title: "Item do pedido";
                        readonly description: "Itens do pedido, podendo ser produtos ou serviços.";
                    };
                    readonly ServiceBooking: {
                        readonly title: "Agendamento de serviço";
                        readonly description: "Reserva de data/horário para prestação de serviço.";
                    };
                    readonly Payment: {
                        readonly title: "Pagamento";
                        readonly description: "Registro do pagamento associado ao pedido.";
                    };
                    readonly StripeTransaction: {
                        readonly title: "Transação Stripe";
                        readonly description: "Evento de cobrança e confirmação retornado pela Stripe.";
                    };
                    readonly FinancialEntry: {
                        readonly title: "Lançamento financeiro";
                        readonly description: "Registro financeiro associado a recebíveis e conciliações.";
                    };
                    readonly Receivable: {
                        readonly title: "Recebível";
                        readonly description: "Valor a receber proveniente de pagamentos aprovados.";
                    };
                    readonly AdminUser: {
                        readonly title: "Administrador";
                        readonly description: "Usuário administrativo do pet shop.";
                    };
                    readonly Address: {
                        readonly title: "Endereço";
                        readonly description: "Endereço de entrega ou cadastro do cliente.";
                    };
                    readonly CatalogCategory: {
                        readonly title: "Categoria";
                        readonly description: "Classificação de produtos e serviços no catálogo.";
                    };
                };
            };
            readonly rules: readonly [{
                readonly ruleId: "ruleOrderRequiresCustomer";
                readonly title: "Pedido requer cliente";
                readonly description: "Todo pedido deve estar associado a um cliente válido.";
                readonly appliesTo: readonly ["Order"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleOrderStatusLifecycle";
                readonly title: "Ciclo de vida do pedido";
                readonly description: "O pedido deve seguir estados padrão: criado, aguardandoPagamento, pago, emSeparacao, concluido, cancelado.";
                readonly appliesTo: readonly ["Order"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "rulePaymentRequiredToConfirmOrder";
                readonly title: "Pagamento confirma pedido";
                readonly description: "Pedido só pode ser confirmado como pago após transação Stripe aprovada.";
                readonly appliesTo: readonly ["Order", "Payment", "StripeTransaction"];
                readonly layer: "layer_2";
            }, {
                readonly ruleId: "ruleStripeTransactionLink";
                readonly title: "Transação Stripe vinculada";
                readonly description: "Toda transação Stripe deve estar vinculada a um pagamento e pedido.";
                readonly appliesTo: readonly ["StripeTransaction", "Payment", "Order"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleServiceBookingRequiresSlot";
                readonly title: "Agendamento requer horário";
                readonly description: "Agendamento de serviço exige data e horário disponíveis.";
                readonly appliesTo: readonly ["ServiceBooking"];
                readonly layer: "layer_2";
            }, {
                readonly ruleId: "ruleReceivableFromPayment";
                readonly title: "Recebível a partir do pagamento";
                readonly description: "Recebível é criado quando pagamento aprovado e conciliação registrada.";
                readonly appliesTo: readonly ["Receivable", "Payment", "FinancialEntry"];
                readonly layer: "layer_3";
            }, {
                readonly ruleId: "ruleMetricsUpdateOnOrderPaid";
                readonly title: "Atualização de métricas";
                readonly description: "Métricas de vendas e pagamentos são atualizadas quando pedido é pago.";
                readonly appliesTo: readonly ["Order", "Payment"];
                readonly layer: "layer_3";
            }];
            readonly relationships: readonly [{
                readonly relationshipId: "relCustomerOwnsPet";
                readonly fromEntity: "Customer";
                readonly toEntity: "Pet";
                readonly type: "owns";
                readonly description: "Cliente pode possuir um ou mais pets.";
            }, {
                readonly relationshipId: "relCustomerHasCart";
                readonly fromEntity: "Customer";
                readonly toEntity: "Cart";
                readonly type: "has";
                readonly description: "Cliente possui um carrinho ativo.";
            }, {
                readonly relationshipId: "relCartHasItems";
                readonly fromEntity: "Cart";
                readonly toEntity: "CartItem";
                readonly type: "contains";
                readonly description: "Carrinho contém itens.";
            }, {
                readonly relationshipId: "relOrderHasItems";
                readonly fromEntity: "Order";
                readonly toEntity: "OrderItem";
                readonly type: "contains";
                readonly description: "Pedido contém itens.";
            }, {
                readonly relationshipId: "relOrderHasPayment";
                readonly fromEntity: "Order";
                readonly toEntity: "Payment";
                readonly type: "has";
                readonly description: "Pedido possui um pagamento associado.";
            }, {
                readonly relationshipId: "relPaymentHasStripeTx";
                readonly fromEntity: "Payment";
                readonly toEntity: "StripeTransaction";
                readonly type: "has";
                readonly description: "Pagamento possui uma transação Stripe.";
            }, {
                readonly relationshipId: "relOrderHasBooking";
                readonly fromEntity: "Order";
                readonly toEntity: "ServiceBooking";
                readonly type: "mayHave";
                readonly description: "Pedido pode incluir agendamento de serviço.";
            }, {
                readonly relationshipId: "relOrderCreatesReceivable";
                readonly fromEntity: "Order";
                readonly toEntity: "Receivable";
                readonly type: "generates";
                readonly description: "Pedido pago gera recebível.";
            }, {
                readonly relationshipId: "relReceivableHasEntry";
                readonly fromEntity: "Receivable";
                readonly toEntity: "FinancialEntry";
                readonly type: "records";
                readonly description: "Recebível registra lançamentos financeiros.";
            }, {
                readonly relationshipId: "relProductCategory";
                readonly fromEntity: "CatalogCategory";
                readonly toEntity: "Product";
                readonly type: "categorizes";
                readonly description: "Categoria classifica produto.";
            }, {
                readonly relationshipId: "relServiceCategory";
                readonly fromEntity: "CatalogCategory";
                readonly toEntity: "Service";
                readonly type: "categorizes";
                readonly description: "Categoria classifica serviço.";
            }, {
                readonly relationshipId: "relCustomerAddress";
                readonly fromEntity: "Customer";
                readonly toEntity: "Address";
                readonly type: "has";
                readonly description: "Cliente possui endereços.";
            }, {
                readonly relationshipId: "relOrderBelongsCustomer";
                readonly fromEntity: "Order";
                readonly toEntity: "Customer";
                readonly type: "belongsTo";
                readonly description: "Pedido pertence a um cliente.";
            }, {
                readonly relationshipId: "relOrderItemProduct";
                readonly fromEntity: "OrderItem";
                readonly toEntity: "Product";
                readonly type: "mayReference";
                readonly description: "Item de pedido pode referenciar um produto.";
            }, {
                readonly relationshipId: "relOrderItemService";
                readonly fromEntity: "OrderItem";
                readonly toEntity: "Service";
                readonly type: "mayReference";
                readonly description: "Item de pedido pode referenciar um serviço.";
            }, {
                readonly relationshipId: "relCartItemProduct";
                readonly fromEntity: "CartItem";
                readonly toEntity: "Product";
                readonly type: "mayReference";
                readonly description: "Item do carrinho pode referenciar um produto.";
            }, {
                readonly relationshipId: "relCartItemService";
                readonly fromEntity: "CartItem";
                readonly toEntity: "Service";
                readonly type: "mayReference";
                readonly description: "Item do carrinho pode referenciar um serviço.";
            }, {
                readonly relationshipId: "relServiceBookingService";
                readonly fromEntity: "ServiceBooking";
                readonly toEntity: "Service";
                readonly type: "books";
                readonly description: "Agendamento refere-se a um serviço.";
            }, {
                readonly relationshipId: "relServiceBookingPet";
                readonly fromEntity: "ServiceBooking";
                readonly toEntity: "Pet";
                readonly type: "for";
                readonly description: "Agendamento é feito para um pet específico.";
            }];
            readonly userActions: readonly [{
                readonly actionId: "browseCatalog";
                readonly title: "Navegar no catálogo";
                readonly actor: "cliente";
                readonly capabilityId: "browseCatalog";
                readonly description: "Explorar categorias e listar produtos/serviços disponíveis.";
                readonly commandType: "query";
                readonly affectedEntities: readonly ["Product", "Service", "CatalogCategory"];
            }, {
                readonly actionId: "viewProductService";
                readonly title: "Ver detalhes de produto/serviço";
                readonly actor: "cliente";
                readonly capabilityId: "browseCatalog";
                readonly description: "Abrir página de detalhes com descrição, preço e opções.";
                readonly commandType: "query";
                readonly affectedEntities: readonly ["Product", "Service"];
            }, {
                readonly actionId: "addToCart";
                readonly title: "Adicionar ao carrinho";
                readonly actor: "cliente";
                readonly capabilityId: "manageCartCheckout";
                readonly description: "Adicionar produto ou serviço ao carrinho com quantidade.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Cart", "CartItem"];
            }, {
                readonly actionId: "updateCart";
                readonly title: "Atualizar carrinho";
                readonly actor: "cliente";
                readonly capabilityId: "manageCartCheckout";
                readonly description: "Alterar quantidade ou remover itens do carrinho.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Cart", "CartItem"];
            }, {
                readonly actionId: "startCheckout";
                readonly title: "Iniciar checkout";
                readonly actor: "cliente";
                readonly capabilityId: "manageCartCheckout";
                readonly description: "Confirmar itens e dados para criação do pedido.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Order", "OrderItem"];
                readonly rulesApplied: readonly ["ruleOrderRequiresCustomer"];
            }, {
                readonly actionId: "confirmStripePayment";
                readonly title: "Confirmar pagamento Stripe";
                readonly actor: "cliente";
                readonly capabilityId: "payWithStripe";
                readonly description: "Autorizar e confirmar pagamento via Stripe.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Payment", "StripeTransaction", "Order"];
                readonly rulesApplied: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink", "ruleMetricsUpdateOnOrderPaid"];
            }, {
                readonly actionId: "scheduleService";
                readonly title: "Agendar serviço";
                readonly actor: "cliente";
                readonly capabilityId: "bookService";
                readonly description: "Selecionar data e horário disponíveis para serviço.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["ServiceBooking", "Order"];
                readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
            }, {
                readonly actionId: "manageCatalog";
                readonly title: "Gerenciar catálogo";
                readonly actor: "adminPetShop";
                readonly capabilityId: "manageCatalog";
                readonly description: "Cadastrar, editar ou desativar produtos e serviços.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Product", "Service", "CatalogCategory"];
            }, {
                readonly actionId: "updateOrderStatus";
                readonly title: "Atualizar status do pedido";
                readonly actor: "adminPetShop";
                readonly capabilityId: "manageOrdersServices";
                readonly description: "Alterar status do pedido e acompanhar execução.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Order"];
                readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
            }, {
                readonly actionId: "viewFinancial";
                readonly title: "Visualizar financeiro";
                readonly actor: "adminPetShop";
                readonly capabilityId: "financialOverview";
                readonly description: "Consultar recebíveis, transações e lançamentos.";
                readonly commandType: "query";
                readonly affectedEntities: readonly ["Receivable", "StripeTransaction", "FinancialEntry"];
            }, {
                readonly actionId: "reconcilePayments";
                readonly title: "Conciliar recebíveis";
                readonly actor: "adminPetShop";
                readonly capabilityId: "financialOverview";
                readonly description: "Registrar conciliação e lançar recebíveis aprovados.";
                readonly commandType: "command";
                readonly affectedEntities: readonly ["Receivable", "FinancialEntry", "Payment"];
                readonly rulesApplied: readonly ["ruleReceivableFromPayment"];
            }, {
                readonly actionId: "viewMetricsDashboard";
                readonly title: "Visualizar métricas";
                readonly actor: "adminPetShop";
                readonly capabilityId: "metricsDashboard";
                readonly description: "Acompanhar indicadores de vendas e pagamentos.";
                readonly commandType: "query";
                readonly affectedEntities: readonly ["Order", "Payment"];
            }];
            readonly approvedArtifacts: {
                readonly pages: readonly [{
                    readonly signal: "homePage";
                    readonly title: "Página inicial";
                    readonly reason: "Apresentar o pet shop e acesso ao catálogo.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "page";
                }, {
                    readonly signal: "catalogPage";
                    readonly title: "Catálogo";
                    readonly reason: "Listar produtos e serviços disponíveis.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "page";
                }, {
                    readonly signal: "productServiceDetailPage";
                    readonly title: "Detalhe de produto/serviço";
                    readonly reason: "Exibir descrição, preço e opções de compra/agendamento.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "page";
                    readonly rulesApplied: readonly ["ruleServiceBookingRequiresSlot"];
                }, {
                    readonly signal: "cartPage";
                    readonly title: "Carrinho";
                    readonly reason: "Revisar itens antes do checkout.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "page";
                }, {
                    readonly signal: "checkoutPage";
                    readonly title: "Checkout";
                    readonly reason: "Coletar dados e iniciar pagamento Stripe.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "page";
                    readonly references: readonly ["checkoutWorkflow"];
                    readonly rulesApplied: readonly ["ruleOrderRequiresCustomer", "rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink"];
                }, {
                    readonly signal: "accountOrdersPage";
                    readonly title: "Minha conta e pedidos";
                    readonly reason: "Acompanhar histórico de compras e serviços.";
                    readonly priority: "soon";
                    readonly actor: "cliente";
                    readonly artifactType: "page";
                }, {
                    readonly signal: "adminDashboardPage";
                    readonly title: "Dashboard administrativo";
                    readonly reason: "Acesso rápido a vendas, agenda e financeiro.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "page";
                    readonly references: readonly ["metricTableSalesOps"];
                }, {
                    readonly signal: "adminCatalogPage";
                    readonly title: "Administração de catálogo";
                    readonly reason: "Gerenciar produtos e serviços.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "page";
                    readonly references: readonly ["manageCatalogWorkflow"];
                }, {
                    readonly signal: "adminOrdersPage";
                    readonly title: "Administração de pedidos/serviços";
                    readonly reason: "Gerenciar pedidos e status de serviços.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "page";
                    readonly rulesApplied: readonly ["ruleOrderStatusLifecycle"];
                }, {
                    readonly signal: "adminFinancialPage";
                    readonly title: "Financeiro";
                    readonly reason: "Visualizar recebíveis e transações Stripe.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "page";
                    readonly references: readonly ["payoutReconciliationWorkflow"];
                    readonly rulesApplied: readonly ["ruleReceivableFromPayment"];
                }, {
                    readonly signal: "adminMetricsPage";
                    readonly title: "Métricas";
                    readonly reason: "Exibir métricas básicas e gráficos.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "page";
                    readonly references: readonly ["metricTableSalesOps"];
                    readonly rulesApplied: readonly ["ruleMetricsUpdateOnOrderPaid"];
                }];
                readonly workflows: readonly [{
                    readonly signal: "checkoutWorkflow";
                    readonly title: "Fluxo de checkout";
                    readonly reason: "Processo de compra até confirmação de pagamento.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["stripePaymentsPlugin", "usecaseCreateOrder", "usecaseConfirmStripePayment", "usecaseUpdateMetricsOnOrderPaid"];
                }, {
                    readonly signal: "serviceBookingWorkflow";
                    readonly title: "Agendamento de serviço";
                    readonly reason: "Selecionar data/horário para banho e tosa e confirmar pagamento.";
                    readonly priority: "soon";
                    readonly actor: "cliente";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["usecaseScheduleService"];
                }, {
                    readonly signal: "orderManagementWorkflow";
                    readonly title: "Gestão de pedidos/serviços";
                    readonly reason: "Atualizar status de pedidos e serviços.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["usecaseUpdateOrderStatus"];
                }, {
                    readonly signal: "payoutReconciliationWorkflow";
                    readonly title: "Conciliação de pagamentos";
                    readonly reason: "Registrar recebíveis e conciliar transações Stripe.";
                    readonly priority: "soon";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["usecaseReconcilePayments"];
                }, {
                    readonly signal: "manageCatalogWorkflow";
                    readonly title: "Gestão de catálogo";
                    readonly reason: "Fluxo para criar, editar e desativar produtos, serviços e categorias.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["usecaseManageCatalog"];
                }];
                readonly plugins: readonly [{
                    readonly signal: "stripePaymentsPlugin";
                    readonly title: "Plugin Stripe Brasil";
                    readonly reason: "Integração de pagamento Stripe para o Brasil.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "plugin";
                    readonly references: readonly ["rulePaymentRequiredToConfirmOrder", "ruleStripeTransactionLink"];
                }];
                readonly agents: readonly [];
                readonly horizontalModules: readonly [{
                    readonly signal: "authModule";
                    readonly title: "Autenticação e perfis";
                    readonly reason: "Cadastro/login para clientes e administradores.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "horizontalModule";
                }, {
                    readonly signal: "financeModule";
                    readonly title: "Módulo financeiro";
                    readonly reason: "Recebíveis, conciliação e relatórios financeiros básicos.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "horizontalModule";
                    readonly references: readonly ["ruleReceivableFromPayment"];
                }, {
                    readonly signal: "notificationsModule";
                    readonly title: "Notificações";
                    readonly reason: "Confirmações de pedidos e status de pagamento.";
                    readonly priority: "soon";
                    readonly actor: "cliente";
                    readonly artifactType: "horizontalModule";
                }];
                readonly mdm: readonly [{
                    readonly signal: "petShopMasterData";
                    readonly title: "MDM do pet shop";
                    readonly reason: "Centralizar dados mestres de cliente, pet, produto, serviço, pedido e transação.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "mdm";
                    readonly references: readonly ["Customer", "Pet", "Product", "Service", "Order", "Payment", "StripeTransaction"];
                }];
                readonly metricTables: readonly [{
                    readonly signal: "metricTableSalesOps";
                    readonly title: "Tabela de métricas de vendas e pagamentos";
                    readonly reason: "Agregação de pedidos, ticket médio, receita e taxa de aprovação.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "metricTable";
                    readonly references: readonly ["Order", "Payment"];
                }];
                readonly metricDashboards: readonly [{
                    readonly signal: "adminMetricsDashboard";
                    readonly title: "Dashboard administrativo de métricas";
                    readonly reason: "Painel com indicadores de vendas e pagamentos.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "metricDashboard";
                    readonly references: readonly ["metricTableSalesOps"];
                }];
                readonly usecaseEntities: readonly [{
                    readonly signal: "usecaseCreateOrder";
                    readonly title: "Caso de uso: criar pedido";
                    readonly reason: "Registrar pedido a partir do carrinho.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["Order", "OrderItem", "Cart", "CartItem"];
                }, {
                    readonly signal: "usecaseConfirmStripePayment";
                    readonly title: "Caso de uso: confirmar pagamento Stripe";
                    readonly reason: "Atualizar status do pedido após confirmação do Stripe.";
                    readonly priority: "now";
                    readonly actor: "cliente";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["Payment", "StripeTransaction", "Order"];
                }, {
                    readonly signal: "usecaseScheduleService";
                    readonly title: "Caso de uso: agendar serviço";
                    readonly reason: "Criar agendamento para banho e tosa.";
                    readonly priority: "soon";
                    readonly actor: "cliente";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["ServiceBooking", "Service", "Order"];
                }, {
                    readonly signal: "usecaseUpdateOrderStatus";
                    readonly title: "Caso de uso: atualizar status do pedido";
                    readonly reason: "Gerenciar ciclo de vida do pedido.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["Order"];
                }, {
                    readonly signal: "usecaseReconcilePayments";
                    readonly title: "Caso de uso: conciliar recebíveis";
                    readonly reason: "Atualizar financeiro com transações confirmadas.";
                    readonly priority: "soon";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["Receivable", "FinancialEntry", "Payment"];
                }, {
                    readonly signal: "usecaseManageCatalog";
                    readonly title: "Caso de uso: gerenciar catálogo";
                    readonly reason: "Criar, editar e desativar produtos, serviços e categorias.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["Product", "Service", "CatalogCategory"];
                }, {
                    readonly signal: "usecaseUpdateMetricsOnOrderPaid";
                    readonly title: "Caso de uso: atualizar métricas de vendas";
                    readonly reason: "Atualizar agregações de métricas quando o pedido é pago.";
                    readonly priority: "now";
                    readonly actor: "adminPetShop";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["Order", "Payment", "metricTableSalesOps"];
                }];
            };
            readonly decisions: readonly [{
                readonly decisionId: "fixArtifactReferences";
                readonly title: "Correção de referências entre artefatos";
                readonly decision: "Ajustar referências para sinais existentes (checkoutWorkflow, payoutReconciliationWorkflow, stripePaymentsPlugin).";
                readonly reason: "Evitar referências quebradas entre páginas, workflows e plugins.";
                readonly affectedArtifacts: readonly ["checkoutPage", "adminFinancialPage", "checkoutWorkflow"];
            }, {
                readonly decisionId: "addCoreRelationships";
                readonly title: "Relacionamentos centrais de pedidos e agendamentos";
                readonly decision: "Adicionar vínculos de Order com Customer e itens com Product/Service, além de ServiceBooking com Service e Pet.";
                readonly reason: "Garantir integridade do domínio de pedidos e agendamento.";
                readonly affectedArtifacts: readonly ["relationships"];
            }, {
                readonly decisionId: "addMetricsUsecase";
                readonly title: "Caso de uso de atualização de métricas";
                readonly decision: "Criar usecaseUpdateMetricsOnOrderPaid e referenciar no checkoutWorkflow.";
                readonly reason: "Cobrir regra layer_3 de atualização de métricas e planejamento de BFF/atualizações.";
                readonly affectedArtifacts: readonly ["usecaseUpdateMetricsOnOrderPaid", "checkoutWorkflow"];
            }, {
                readonly decisionId: "addCatalogWorkflow";
                readonly title: "Workflow e caso de uso para gestão de catálogo";
                readonly decision: "Criar manageCatalogWorkflow e usecaseManageCatalog para operações administrativas no catálogo.";
                readonly reason: "Cobrir comandos de gestão de catálogo por workflow dedicado.";
                readonly affectedArtifacts: readonly ["manageCatalogWorkflow", "usecaseManageCatalog", "adminCatalogPage"];
            }];
            readonly deferredItems: readonly [];
        };
    };
    export default modulePlan;
}
declare module "_102030_/l5/petShopStripe/rules.defs" {
    export const rulesPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "rules";
        readonly artifactId: "petShopStripeRules";
        readonly moduleName: "petShopStripe";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentFinalizeSolutionPlan";
            readonly stepId: 11;
            readonly planId: "plan-finalize-solution-plan";
        };
        readonly data: {
            readonly moduleName: "petShopStripe";
            readonly rules: readonly [{
                readonly ruleId: "ruleOrderRequiresCustomer";
                readonly title: "Pedido requer cliente";
                readonly description: "Todo pedido deve estar associado a um cliente válido.";
                readonly appliesTo: readonly ["Order"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleOrderStatusLifecycle";
                readonly title: "Ciclo de vida do pedido";
                readonly description: "O pedido deve seguir estados padrão: criado, aguardandoPagamento, pago, emSeparacao, concluido, cancelado.";
                readonly appliesTo: readonly ["Order"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "rulePaymentRequiredToConfirmOrder";
                readonly title: "Pagamento confirma pedido";
                readonly description: "Pedido só pode ser confirmado como pago após transação Stripe aprovada.";
                readonly appliesTo: readonly ["Order", "Payment", "StripeTransaction"];
                readonly layer: "layer_2";
            }, {
                readonly ruleId: "ruleStripeTransactionLink";
                readonly title: "Transação Stripe vinculada";
                readonly description: "Toda transação Stripe deve estar vinculada a um pagamento e pedido.";
                readonly appliesTo: readonly ["StripeTransaction", "Payment", "Order"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleServiceBookingRequiresSlot";
                readonly title: "Agendamento requer horário";
                readonly description: "Agendamento de serviço exige data e horário disponíveis.";
                readonly appliesTo: readonly ["ServiceBooking"];
                readonly layer: "layer_2";
            }, {
                readonly ruleId: "ruleReceivableFromPayment";
                readonly title: "Recebível a partir do pagamento";
                readonly description: "Recebível é criado quando pagamento aprovado e conciliação registrada.";
                readonly appliesTo: readonly ["Receivable", "Payment", "FinancialEntry"];
                readonly layer: "layer_3";
            }, {
                readonly ruleId: "ruleMetricsUpdateOnOrderPaid";
                readonly title: "Atualização de métricas";
                readonly description: "Métricas de vendas e pagamentos são atualizadas quando pedido é pago.";
                readonly appliesTo: readonly ["Order", "Payment"];
                readonly layer: "layer_3";
            }];
        };
    };
    export default rulesPlan;
}
