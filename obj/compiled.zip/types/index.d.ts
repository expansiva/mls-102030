declare module "_102030_/l1/petshop/module" {
    export interface PetshopCatalogProduct {
        productId: string;
        name: string;
        category: string;
        priceInCents: number;
        currency: 'BRL';
        highlightScore: number;
        stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
        description: string;
        updatedAt: string;
    }
    export interface PetshopSeedResult {
        insertedCount: number;
        totalCount: number;
        seededAt: string;
    }
    export interface PetshopHomeLoadParams {
        category?: string;
        query?: string;
        topLimit?: number;
        forceSeed?: boolean;
    }
    export interface PetshopHomeLoadResult {
        seed: PetshopSeedResult;
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
    export interface PetshopUpdateProductParams {
        productId: string;
        author?: string;
        name?: string;
        category?: string;
        priceInCents?: number;
        highlightScore?: number;
        stockStatus?: PetshopCatalogProduct['stockStatus'];
        description?: string;
    }
}
declare module "_102030_/l1/petshop/persistence" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
}
declare module "_102030_/l2/petshop/shared/mock/products" {
    import type { PetshopCatalogProduct } from "_102030_/l1/petshop/module";
    export function buildPetshopMockProducts(): PetshopCatalogProduct[];
}
declare module "_102030_/l2/petshop/shared/mock/adminMock" {
    export function getPetshopMockProducts(): import("_102030_/l1/petshop/module").PetshopCatalogProduct[];
}
declare module "_102030_/l1/petshop/layer_3_usecases/catalogUsecases" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult, PetshopSeedResult, PetshopUpdateProductParams } from "_102030_/l1/petshop/module";
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function resetPetshopCatalogForTests(): void;
    export function seedPetshopMockData(ctx: RequestContext, force?: boolean): Promise<PetshopSeedResult>;
    export function listPetshopCatalog(ctx: RequestContext, input?: {
        category?: string;
        query?: string;
    }): Promise<any>;
    export function getPetshopTopProducts(ctx: RequestContext, limit?: number): Promise<any[]>;
    export function loadPetshopHome(ctx: RequestContext, input?: PetshopHomeLoadParams): Promise<PetshopHomeLoadResult>;
    export function updatePetshopProduct(ctx: RequestContext, input: PetshopUpdateProductParams): Promise<PetshopCatalogProduct>;
}
declare module "_102030_/l1/petshop/layer_2_controllers/catalogHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petshopListCatalogHandler: BffHandler;
    export const petshopGetTopProductsHandler: BffHandler;
    export const petshopSeedMockDataHandler: BffHandler;
    export const petshopHomeLoadHandler: BffHandler;
    export const petshopUpdateProductHandler: BffHandler;
}
declare module "_102030_/l1/petshop/layer_2_controllers/router.test" { }
declare module "_102030_/l1/petshop/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createPetshopRouter(): Map<string, BffHandler>;
}
declare module "_102030_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102030_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102030_/l2/petshop/shared/contracts/home" {
    import type { PetshopCatalogProduct, PetshopHomeLoadParams, PetshopHomeLoadResult } from "_102030_/l1/petshop/module";
    export type PetshopHomeRequest = PetshopHomeLoadParams;
    export interface PetshopHomeResponse extends PetshopHomeLoadResult {
        catalog: PetshopCatalogProduct[];
        topProducts: PetshopCatalogProduct[];
    }
}
declare module "_102030_/l2/petshop/web/shared/home" {
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { PetshopHomeRequest } from "_102030_/l2/petshop/shared/contracts/home";
    export function loadPetshopHome(params?: PetshopHomeRequest, options?: BffClientOptions): Promise<any>;
}
declare module "_102030_/l2/petshop/web/shared/homeFormatters" {
    export function formatPrice(priceInCents: number): string;
}
declare module "_102030_/l2/petshop/shared/contracts/update-product" {
    export type { PetshopUpdateProductParams, PetshopCatalogProduct } from "_102030_/l1/petshop/module";
}
declare module "_102030_/l2/petshop/web/shared/updateProduct" {
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { PetshopUpdateProductParams } from "_102030_/l2/petshop/shared/contracts/update-product";
    export function updatePetshopProduct(params: PetshopUpdateProductParams, options?: BffClientOptions): Promise<any>;
}
declare module "_102030_/l2/petshop/web/desktop/page11/home" {
    import { LitElement } from 'lit';
    import type { PetshopCatalogProduct } from "_102030_/l1/petshop/module";
    type PetshopSection = 'catalog' | 'edit-products';
    export class PetshopWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            items: {
                state: boolean;
            };
            topItems: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            editorAuthor: {
                state: boolean;
            };
        };
        currentSection: PetshopSection;
        items: PetshopCatalogProduct[];
        topItems: PetshopCatalogProduct[];
        status: string;
        editorAuthor: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handlePopState;
        private handleRouteChange;
        private navigateWithinModule;
        private loadHome;
        private handleSectionClick;
        private handleEditorSubmit;
        private retryUpdateProduct;
        private saveProduct;
        private renderCatalog;
        private renderEditor;
        render(): any;
    }
}
declare module "_102030_/l2/petshop/index" { }
declare module "_102030_/l2/petshop/module.defs" {
    export const skill: {
        readonly moduleId: "petshop";
        readonly purpose: "Petshop client module with desktop and mobile page variations.";
        readonly pages: readonly ["home", "edit-products"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.petshop.currentSection", "ui.petshop.selectedCategory", "ui.petshop.searchQuery", "ui.petshop.editorAuthor"];
    };
}
declare module "_102030_/l2/petshop/module" {
    import type { AuraModuleFrontendDefinition } from '_102029_/l2/contracts/bootstrap';
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.petshop.currentSection";
        readonly selectedCategory: "ui.petshop.selectedCategory";
        readonly searchQuery: "ui.petshop.searchQuery";
        readonly editorAuthor: "ui.petshop.editorAuthor";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102030_/l2/petshop/web/routes/catalog" {
    export { PetshopWebDesktopHomePage } from "_102030_/l2/petshop/web/desktop/page11/home";
}
declare module "_102030_/l2/petshop/web/routes/edit-products" {
    export { PetshopWebDesktopHomePage } from "_102030_/l2/petshop/web/desktop/page11/home";
}
declare module "_102030_/l2/petshop/web/shared/home.defs" {
    export const skill = "\n# Petshop Home Page\n\n## Purpose\n\nRender the desktop home page for the petshop module using a single aggregated\nBFF request.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `petshop.home.load`\n- The routine must return only the data the page needs:\n  - `seed`\n  - `catalog`\n  - `topProducts`\n\n## Page Behavior\n\n- Load the page with one BFF call on connect\n- Render a compact toolbar with category filters\n- Show a status line with the current page state\n- Render a \"Top products\" section\n- Render a \"Catalog\" section\n- Reload the page when the user clicks reload\n- Re-run the page load with a category filter when the user clicks a category\n\n## Important Data\n\n- Catalog item fields:\n  - `name`\n  - `category`\n  - `priceInCents`\n  - `stockStatus`\n  - `description`\n- Top product fields:\n  - `name`\n  - `category`\n  - `highlightScore`\n  - `priceInCents`\n\n## Shared Files\n\n- `web/shared/home.ts` owns the page BFF call\n- `web/shared/homeFormatters.ts` owns display formatting helpers such as\n  `formatPrice`\n\n## Layout Intent\n\n- Dense but readable business UI\n- Fast visual scan for category, stock state, and price\n- Keep the page compatible with the master shell aside/header\n- Use light DOM compatible styling\n";
}
